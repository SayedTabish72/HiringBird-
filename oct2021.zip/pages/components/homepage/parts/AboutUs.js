import React from 'react'
import { Aboutuscard } from './styles/Aboutus.styled'


const AboutUs = () => {
    return (
        <Aboutuscard>
            <div>
                <h2>About Us</h2>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc odio in et, lectus sit lorem id integer dolor sit amet, consectetur adipiscing elit. Nunc odio in et. id integer dolor sit amet, consectetur adipiscing elit. Net.
                </p>
            </div>
            <div>
                <img src = '../../../../aboutus.png'></img>
            </div>
        </Aboutuscard>
    )
}

export default AboutUs