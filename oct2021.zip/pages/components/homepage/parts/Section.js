import React from "react";
import Image from "next/image";
import { Bottom, Container, Top, Wrap } from "./styles/Section.styled";
import { Button } from "./styles/CommonComponents/Button.styled";
import { Heading } from "./styles/CommonComponents/Heading.styled";
import {Card} from "./styles/CommonComponents/Card.styled"

const Section = () => {
  return (
    <Container>
      <Top>
        <div className="left">
          <Heading>How does it work?</Heading>
        </div>
        <div className="right">
          <h5>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed atque
            nihil labore repudiandae eligendi, animi accusamus facere.
            Perferendis et quaerat eos magni veritatis, itaque unde, quis quas a
            maiores facere.
          </h5>
          <Button>Apply Now</Button>
        </div>
      </Top>
      <Bottom>
        <Card>
          <Image src="/images/1.png" alt="universe" width={400} height={400} />
          <h3>Sign In</h3>
          <p>Create an account to get started</p>
        </Card>

        <Card>
          <Image src="/images/2.png" alt="universe" width={350} height={350} />
          <h3>Search for internships</h3>
          <p>Look thorugh our carefully handpicked bunch of internships</p>
        </Card>

        <Card>
          <Image src="/images/3.png" alt="universe" width={350} height={350} />
          <h3>Apply and follow procedure</h3>
          <p>Now sit back and wait for the call back and follow simple steps</p>
        </Card>
      </Bottom>
    </Container>
  );
};

export default Section;
