import React from "react";
import Login from "./components/Login/Login";

const login = () => {
  return <Login />;
};

export default login;
