(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.default = Image1;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../shared/lib/head */ "../shared/lib/head"));

var _toBase64 = __webpack_require__(/*! ../shared/lib/to-base-64 */ "../shared/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../server/image-config */ "../server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};
    var ownKeys = Object.keys(source);

    if (typeof Object.getOwnPropertySymbols === "function") {
      ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) {
        return Object.getOwnPropertyDescriptor(source, sym).enumerable;
      }));
    }

    ownKeys.forEach(function (key) {
      _defineProperty(target, key, source[key]);
    });
  }

  return target;
}

function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = _objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

const loadedImageURLs = new Set();

if (true) {
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['default', defaultLoader], ['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['custom', customLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];

function isStaticRequire(src) {
  return src.default !== undefined;
}

function isStaticImageData(src) {
  return src.src !== undefined;
}

function isStaticImport(src) {
  return typeof src === 'object' && (isStaticRequire(src) || isStaticImageData(src));
}

const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const viewportWidthRe = /(^|\s)(1?\d?\d)vw/g;
    const percentSizes = [];

    for (let match; match = viewportWidthRe.exec(sizes); match) {
      percentSizes.push(parseInt(match[2]));
    }

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load(_objectSpread({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
} // See https://stackoverflow.com/q/39777833/266535 for why we use this ref
// handler instead of the img's onLoad attribute.


function handleLoading(img, src, layout, placeholder, onLoadingComplete) {
  if (!img) {
    return;
  }

  const handleLoad = () => {
    if (!img.src.startsWith('data:')) {
      const p = 'decode' in img ? img.decode() : Promise.resolve();
      p.catch(() => {}).then(() => {
        if (placeholder === 'blur') {
          img.style.filter = 'none';
          img.style.backgroundSize = 'none';
          img.style.backgroundImage = 'none';
        }

        loadedImageURLs.add(src);

        if (onLoadingComplete) {
          const {
            naturalWidth,
            naturalHeight
          } = img; // Pass back read-only primitive values but not the
          // underlying DOM element because it could be misused.

          onLoadingComplete({
            naturalWidth,
            naturalHeight
          });
        }

        if (true) {
          var ref;

          if ((ref = img.parentElement) === null || ref === void 0 ? void 0 : ref.parentElement) {
            const parent = getComputedStyle(img.parentElement.parentElement);

            if (layout === 'responsive' && parent.display === 'flex') {
              console.warn(`Image with src "${src}" may not render properly as a child of a flex container. Consider wrapping the image with a div to configure the width.`);
            } else if (layout === 'fill' && parent.position !== 'relative') {
              console.warn(`Image with src "${src}" may not render properly with a parent using position:"${parent.position}". Consider changing the parent style to position:"relative" with a width and height.`);
            }
          }
        }
      });
    }
  };

  if (img.complete) {
    // If the real image fails to load, this will still remove the placeholder.
    // This is the desired behavior for now, and will be revisited when error
    // handling is worked on for the image component itself.
    handleLoad();
  } else {
    img.onload = handleLoad;
  }
}

function Image1(_param) {
  var {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    lazyBoundary = '200px',
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    onLoadingComplete,
    loader = defaultImageLoader,
    placeholder = 'empty',
    blurDataURL
  } = _param,
      all = _objectWithoutProperties(_param, ["src", "sizes", "unoptimized", "priority", "loading", "lazyBoundary", "className", "quality", "width", "height", "objectFit", "objectPosition", "onLoadingComplete", "loader", "placeholder", "blurDataURL"]);

  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';

  if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  let staticSrc = '';

  if (isStaticImport(src)) {
    const staticImageData = isStaticRequire(src) ? src.default : src;

    if (!staticImageData.src) {
      throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ${JSON.stringify(staticImageData)}`);
    }

    blurDataURL = blurDataURL || staticImageData.blurDataURL;
    staticSrc = staticImageData.src;

    if (!layout || layout !== 'fill') {
      height = height || staticImageData.height;
      width = width || staticImageData.width;

      if (!staticImageData.height || !staticImageData.width) {
        throw new Error(`An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ${JSON.stringify(staticImageData)}`);
      }
    }
  }

  src = typeof src === 'string' ? src : staticSrc;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src.startsWith('data:') || src.startsWith('blob:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  if (false) {}

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (typeof widthInt !== 'undefined' && isNaN(widthInt) || typeof heightInt !== 'undefined' && isNaN(heightInt)) {
      throw new Error(`Image with src "${src}" has invalid "width" or "height" property. These should be numeric values.`);
    }

    if (layout === 'fill' && (width || height)) {
      console.warn(`Image with src "${src}" and "layout='fill'" has unused properties assigned. Please remove "width" and "height".`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (placeholder === 'blur') {
      if (layout !== 'fill' && (widthInt || 0) * (heightInt || 0) < 1600) {
        console.warn(`Image with src "${src}" is smaller than 40x40. Consider removing the "placeholder='blur'" property to improve performance.`);
      }

      if (!blurDataURL) {
        const VALID_BLUR_EXT = ['jpeg', 'png', 'webp'] // should match next-image-loader
        ;
        throw new Error(`Image with src "${src}" has "placeholder='blur'" property but is missing the "blurDataURL" property.
          Possible solutions:
            - Add a "blurDataURL" property, the contents should be a small Data URL to represent the image
            - Change the "src" property to a static import with one of the supported file types: ${VALID_BLUR_EXT.join(',')}
            - Remove the "placeholder" property, effectively no blur effect
          Read more: https://nextjs.org/docs/messages/placeholder-blur-data-url`);
      }
    }

    if ('ref' in rest) {
      console.warn(`Image with src "${src}" is using unsupported "ref" property. Consider using the "onLoadingComplete" property instead.`);
    }

    if ('style' in rest) {
      console.warn(`Image with src "${src}" is using unsupported "style" property. Please use the "className" property instead.`);
    }

    const rand = Math.floor(Math.random() * 1000) + 100;

    if (!unoptimized && !loader({
      src,
      width: rand,
      quality: 75
    }).includes(rand.toString())) {
      console.warn(`Image with src "${src}" has a "loader" property that does not implement width. Please implement it or use the "unoptimized" property instead.` + `\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader-width`);
    }
  }

  const [setRef, isIntersected] = (0, _useIntersection).useIntersection({
    rootMargin: lazyBoundary,
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };
  const blurStyle = placeholder === 'blur' ? {
    filter: 'blur(20px)',
    backgroundSize: objectFit || 'cover',
    backgroundImage: `url("${blurDataURL}")`,
    backgroundPosition: objectPosition || '0% 0%'
  } : {};

  if (layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  let srcString = src;
  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    src: `data:image/svg+xml;base64,${(0, _toBase64).toBase64(sizerSvg)}`
  }) : null) : null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    "data-nimg": layout,
    className: className,
    ref: img => {
      setRef(img);
      handleLoading(img, srcString, layout, placeholder, onLoadingComplete);
    },
    style: _objectSpread({}, imgStyle, blurStyle)
  })), /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    decoding: "async",
    "data-nimg": layout,
    style: imgStyle,
    className: className,
    loading: loading || 'lazy'
  }))), priority ? // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset

  /*#__PURE__*/
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src,
    // @ts-ignore: imagesrcset is not yet in the link element type.
    imagesrcset: imgAttributes.srcSet,
    // @ts-ignore: imagesizes is not yet in the link element type.
    imagesizes: imgAttributes.sizes
  })) : null);
}

function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?auto=format&fit=max&w=300
  const url = new URL(`${root}${normalizeSrc(src)}`);
  const params = url.searchParams;
  params.set('auto', params.get('auto') || 'format');
  params.set('fit', params.get('fit') || 'max');
  params.set('w', params.get('w') || width.toString());

  if (quality) {
    params.set('q', quality.toString());
  }

  return url.href;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function customLoader({
  src
}) {
  throw new Error(`Image with src "${src}" is missing "loader" prop.` + `\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader`);
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if ( true && !configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.requestIdleCallback = exports.cancelIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";


Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react).useRef();
  const [visible, setVisible] = (0, _react).useState(false);
  const setRef = (0, _react).useCallback(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react).useEffect(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback).requestIdleCallback(() => setVisible(true));
        return () => (0, _requestIdleCallback).cancelIdleCallback(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./pages/components/homepage/Home.js":
/*!*******************************************!*\
  !*** ./pages/components/homepage/Home.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _parts_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./parts/Navbar */ "./pages/components/homepage/parts/Navbar.js");
/* harmony import */ var _parts_Hero__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./parts/Hero */ "./pages/components/homepage/parts/Hero.js");
/* harmony import */ var _parts_Section__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./parts/Section */ "./pages/components/homepage/parts/Section.js");
/* harmony import */ var _parts_categories__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./parts/categories */ "./pages/components/homepage/parts/categories.js");
/* harmony import */ var _parts_locations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./parts/locations */ "./pages/components/homepage/parts/locations.js");
/* harmony import */ var _parts_Contactus__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./parts/Contactus */ "./pages/components/homepage/parts/Contactus.js");
/* harmony import */ var _parts_AboutUs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./parts/AboutUs */ "./pages/components/homepage/parts/AboutUs.js");
/* harmony import */ var _parts_styles_Container_styled__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./parts/styles/Container.styled */ "./pages/components/homepage/parts/styles/Container.styled.js");
/* harmony import */ var _parts_Founder__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./parts/Founder */ "./pages/components/homepage/parts/Founder.js");
/* harmony import */ var _parts_styles_Foundercontainer_styled__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./parts/styles/Foundercontainer.styled */ "./pages/components/homepage/parts/styles/Foundercontainer.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\Home.js";














const theme = {
  mobile: '589px',
  fontFamily: 'Inter'
};

function Home() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(styled_components__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
    theme: theme,
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_Navbar__WEBPACK_IMPORTED_MODULE_2__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_styles_Container_styled__WEBPACK_IMPORTED_MODULE_9__.Container, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_AboutUs__WEBPACK_IMPORTED_MODULE_8__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_styles_Foundercontainer_styled__WEBPACK_IMPORTED_MODULE_11__.Foundercontainer, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_Founder__WEBPACK_IMPORTED_MODULE_10__.default, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 9
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_Hero__WEBPACK_IMPORTED_MODULE_3__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_Section__WEBPACK_IMPORTED_MODULE_4__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_categories__WEBPACK_IMPORTED_MODULE_5__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_locations__WEBPACK_IMPORTED_MODULE_6__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 7
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_parts_Contactus__WEBPACK_IMPORTED_MODULE_7__.default, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 7
      }, this)]
    }, void 0, true)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 22,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

/***/ }),

/***/ "./pages/components/homepage/parts/AboutUs.js":
/*!****************************************************!*\
  !*** ./pages/components/homepage/parts/AboutUs.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Aboutus_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Aboutus.styled */ "./pages/components/homepage/parts/styles/Aboutus.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\AboutUs.js";




const AboutUs = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Aboutus_styled__WEBPACK_IMPORTED_MODULE_1__.Aboutuscard, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h2", {
        children: "About Us"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc odio in et, lectus sit lorem id integer dolor sit amet, consectetur adipiscing elit. Nunc odio in et. id integer dolor sit amet, consectetur adipiscing elit. Net."
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
        src: "../../../../aboutus.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutUs);

/***/ }),

/***/ "./pages/components/homepage/parts/Contactus.js":
/*!******************************************************!*\
  !*** ./pages/components/homepage/parts/Contactus.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/Contactus.styled */ "./pages/components/homepage/parts/styles/Contactus.styled.js");
/* harmony import */ var _public_help_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../public/help.svg */ "./public/help.svg");
/* harmony import */ var _public_contactus1_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../public/contactus1.svg */ "./public/contactus1.svg");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\Contactus.js";







function Contactus() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Container, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Container1, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Leftdiv, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Heading, {
          children: "Contact us"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Text, {
          children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc odio in et, lectus sit lorem id integer dolor sit amet, consectetur adipiscing elit. Nunc odio in et. id integer dolor sit amet, consectetur adipiscing elit. Net."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Button, {
          children: "Join Skilzen"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Logo, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Rightdiv, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: _public_contactus1_svg__WEBPACK_IMPORTED_MODULE_4__.default,
          alt: "rightimg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxDEV)(_styles_Contactus_styled__WEBPACK_IMPORTED_MODULE_2__.Button1, {
          children: "Join Skilzen"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contactus);

/***/ }),

/***/ "./pages/components/homepage/parts/Founder.js":
/*!****************************************************!*\
  !*** ./pages/components/homepage/parts/Founder.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Foundernote_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Foundernote.styled */ "./pages/components/homepage/parts/styles/Foundernote.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\Founder.js";





const Founder = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Foundernote_styled__WEBPACK_IMPORTED_MODULE_1__.Foundernote, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h1", {
            children: "Founder's Note"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 17
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          className: "maintext",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("span", {
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
                src: "../../../../quotes.png",
                className: "quotes"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 16,
                columnNumber: 29
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 15,
              columnNumber: 25
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 21
          }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              children: " We had an incredible experience working with Skilzen and were impressed they made such a big difference in only three weeks. Our team is so grateful for the wonderful improvements they made and their ability to get familiar with the product concept so quickly. It acted as a catalyst to take our design to the next level and get more eyes on our product. Our team is so grateful for the wonderful improvements they made and their ability to get familiar with the product concept so quickly. It acted as a catalyst to take our design to"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 25
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "fullname",
              children: "Full name"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 25
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("p", {
              className: "ceo",
              children: "CEO at Skillzen"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 25
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 21
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 13
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
          src: "../../../../Founder.png"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 9
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Foundernote_styled__WEBPACK_IMPORTED_MODULE_1__.Team, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
        className: "team",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("h4", {
          children: "Our Team"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 13
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figure", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
              className: "teamimg",
              src: "../../../../team1.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 21
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figcaption", {
              children: "CEO at Skilzen"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 21
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 38,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figure", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
              className: "teamimg",
              src: "../../../../team2.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 46,
              columnNumber: 21
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figcaption", {
              children: "Designer at Skilzen"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 21
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figure", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
              className: "teamimg",
              src: "../../../../team3.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 52,
              columnNumber: 21
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figcaption", {
              children: "Designer at Skilzen"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 21
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 17
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figure", {
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("img", {
              className: "teamimg",
              src: "../../../../team4.png"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 58,
              columnNumber: 21
            }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("figcaption", {
              children: "Designer at Skilzen"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 59,
              columnNumber: 21
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 17
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 13
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 9
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Founder);

/***/ }),

/***/ "./pages/components/homepage/parts/Hero.js":
/*!*************************************************!*\
  !*** ./pages/components/homepage/parts/Hero.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Hero.styled */ "./pages/components/homepage/parts/styles/Hero.styled.js");
/* harmony import */ var _styles_CommonComponents_SearchButton_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/CommonComponents/SearchButton.styled */ "./pages/components/homepage/parts/styles/CommonComponents/SearchButton.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\Hero.js";





function Hero() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroContainer, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroDiv, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroLeft, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Heading, {
          children: ["Find your dream ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 32,
            columnNumber: 29
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Head, {
            children: "Internship"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Button, {
          children: "Get Started"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Para, {
          children: "The only way to do great work is to love what you do. If you haven\u2019t found it yet, keep looking. Don\u2019t settle. As with all matters of the heart, you\u2019ll know when you find it.\u201D"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Writer, {
          children: "-Steve Jobs"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 41,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroRight, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Image, {
          src: "./home.png"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearch, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearchLeft, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Img, {
          src: "./earbugs.svg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearchRight, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Search, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchIcon, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchImg, {
              src: "./search.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 54,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchField, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Input, {
              placeholder: "Search Internships here..."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 57,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_styles_CommonComponents_SearchButton_styled__WEBPACK_IMPORTED_MODULE_2__.SearchButton, {
            children: "Search"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 15
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

/***/ }),

/***/ "./pages/components/homepage/parts/Navbar.js":
/*!***************************************************!*\
  !*** ./pages/components/homepage/parts/Navbar.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Navbar.styled */ "./pages/components/homepage/parts/styles/Navbar.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\Navbar.js";




function Navbar() {
  const {
    0: click,
    1: setClick
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const handleClick = () => {
    setClick(!click);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Container, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.ImageContainer, {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Image, {
        src: "/logo.svg"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.LinkContainer, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Menu, {
        src: "./menu.svg",
        onClick: handleClick
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Links, {
        onClick: handleClick,
        click: click,
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Link, {
          children: "Post an Internship"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Link, {
          children: "Find Internships"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Link, {
          children: "Sign In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_styles_Navbar_styled__WEBPACK_IMPORTED_MODULE_1__.Button, {
          children: "Sign Up"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 21,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

/***/ }),

/***/ "./pages/components/homepage/parts/Section.js":
/*!****************************************************!*\
  !*** ./pages/components/homepage/parts/Section.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_Section_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/Section.styled */ "./pages/components/homepage/parts/styles/Section.styled.js");
/* harmony import */ var _styles_CommonComponents_Button_styled__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./styles/CommonComponents/Button.styled */ "./pages/components/homepage/parts/styles/CommonComponents/Button.styled.js");
/* harmony import */ var _styles_CommonComponents_Heading_styled__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./styles/CommonComponents/Heading.styled */ "./pages/components/homepage/parts/styles/CommonComponents/Heading.styled.js");
/* harmony import */ var _styles_CommonComponents_Card_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./styles/CommonComponents/Card.styled */ "./pages/components/homepage/parts/styles/CommonComponents/Card.styled.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\Section.js";








const Section = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_Section_styled__WEBPACK_IMPORTED_MODULE_2__.Container, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_Section_styled__WEBPACK_IMPORTED_MODULE_2__.Top, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "left",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_CommonComponents_Heading_styled__WEBPACK_IMPORTED_MODULE_4__.Heading, {
          children: "How does it work?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "right",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("h5", {
          children: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed atque nihil labore repudiandae eligendi, animi accusamus facere. Perferendis et quaerat eos magni veritatis, itaque unde, quis quas a maiores facere."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_CommonComponents_Button_styled__WEBPACK_IMPORTED_MODULE_3__.Button, {
          children: "Apply Now"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 22,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_Section_styled__WEBPACK_IMPORTED_MODULE_2__.Bottom, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_CommonComponents_Card_styled__WEBPACK_IMPORTED_MODULE_5__.Card, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/images/1.png",
          alt: "universe",
          width: 400,
          height: 400
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("h3", {
          children: "Sign In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("p", {
          children: "Create an account to get started"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_CommonComponents_Card_styled__WEBPACK_IMPORTED_MODULE_5__.Card, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/images/2.png",
          alt: "universe",
          width: 350,
          height: 350
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("h3", {
          children: "Search for internships"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("p", {
          children: "Look thorugh our carefully handpicked bunch of internships"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_styles_CommonComponents_Card_styled__WEBPACK_IMPORTED_MODULE_5__.Card, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
          src: "/images/3.png",
          alt: "universe",
          width: 350,
          height: 350
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("h3", {
          children: "Apply and follow procedure"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("p", {
          children: "Now sit back and wait for the call back and follow simple steps"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 41,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section);

/***/ }),

/***/ "./pages/components/homepage/parts/categories.js":
/*!*******************************************************!*\
  !*** ./pages/components/homepage/parts/categories.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Categories.styled */ "./pages/components/homepage/parts/styles/Categories.styled.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_engg_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../public/engg.svg */ "./public/engg.svg");
/* harmony import */ var _public_commerce_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../public/commerce.svg */ "./public/commerce.svg");
/* harmony import */ var _public_level_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../public/level.svg */ "./public/level.svg");
/* harmony import */ var _public_medical_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../public/medical.svg */ "./public/medical.svg");
/* harmony import */ var _public_science_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../public/science.svg */ "./public/science.svg");
/* harmony import */ var _public_LT_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../public/LT.svg */ "./public/LT.svg");
/* harmony import */ var _public_humanities_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../public/humanities.svg */ "./public/humanities.svg");
/* harmony import */ var _public_law_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../public/law.svg */ "./public/law.svg");
/* harmony import */ var _public_arts_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../public/arts.svg */ "./public/arts.svg");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\categories.js";














function Categories() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Container, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Divstart, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Innerdiv1, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Span50, {
          children: "50+"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Span1, {
          children: "Categories"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Innerdiv2, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Spanright, {
          children: "Explore our handpicked catagory of Internships and unlock your journey with us today! Select one to view the internships"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Spanright2, {
          children: "View all Internships"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 41,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Lowerdiv, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_engg_svg__WEBPACK_IMPORTED_MODULE_3__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Engineering"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_commerce_svg__WEBPACK_IMPORTED_MODULE_4__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Commerce"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_level_svg__WEBPACK_IMPORTED_MODULE_5__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Management"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_medical_svg__WEBPACK_IMPORTED_MODULE_6__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 60,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Medical"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_science_svg__WEBPACK_IMPORTED_MODULE_7__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Science"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_LT_svg__WEBPACK_IMPORTED_MODULE_8__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "L.T."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 67,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_humanities_svg__WEBPACK_IMPORTED_MODULE_9__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Humanities"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_law_svg__WEBPACK_IMPORTED_MODULE_10__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 76,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Law"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
          src: _public_arts_svg__WEBPACK_IMPORTED_MODULE_11__.default,
          alt: "engg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
          children: "Arts"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Categorycard1, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Categories_styled__WEBPACK_IMPORTED_MODULE_1__.Button, {
          children: "View more"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 45,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 29,
    columnNumber: 5
  }, this);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Categories);

/***/ }),

/***/ "./pages/components/homepage/parts/locations.js":
/*!******************************************************!*\
  !*** ./pages/components/homepage/parts/locations.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles/Hero.styled */ "./pages/components/homepage/parts/styles/Hero.styled.js");
/* harmony import */ var _styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles/Locations.styled */ "./pages/components/homepage/parts/styles/Locations.styled.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_delhincr_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../public/delhincr.svg */ "./public/delhincr.svg");
/* harmony import */ var _public_bengaluru_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../public/bengaluru.svg */ "./public/bengaluru.svg");
/* harmony import */ var _public_chennai_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../../public/chennai.svg */ "./public/chennai.svg");
/* harmony import */ var _public_hyderabad_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../public/hyderabad.svg */ "./public/hyderabad.svg");
/* harmony import */ var _public_kolkata_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../public/kolkata.svg */ "./public/kolkata.svg");
/* harmony import */ var _public_mumbai_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../public/mumbai.svg */ "./public/mumbai.svg");
/* harmony import */ var _public_pune_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../public/pune.svg */ "./public/pune.svg");
/* harmony import */ var _public_wfh_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../../public/wfh.svg */ "./public/wfh.svg");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\components\\homepage\\parts\\locations.js";















function Locations() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Container, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Divstart, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Innerdiv1, {
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Span1, {
            children: "Locations"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Innerdiv2, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Spanright, {
            children: "We are currently encouraging Work From Home Internships for the safety for all our loved ones. Find the best internship opportunities here to launch your professional career."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("br", {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 47,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Lowerdiv, {
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard1, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_delhincr_svg__WEBPACK_IMPORTED_MODULE_4__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "New Delhi NCR"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_mumbai_svg__WEBPACK_IMPORTED_MODULE_9__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 63,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Mumbai"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_pune_svg__WEBPACK_IMPORTED_MODULE_10__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 67,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Pune"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_kolkata_svg__WEBPACK_IMPORTED_MODULE_8__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Kolkata"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 72,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_chennai_svg__WEBPACK_IMPORTED_MODULE_6__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Chennai"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_bengaluru_svg__WEBPACK_IMPORTED_MODULE_5__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Bengaluru"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_hyderabad_svg__WEBPACK_IMPORTED_MODULE_7__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 83,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Hyderabad"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 84,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 11
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Locations_styled__WEBPACK_IMPORTED_MODULE_2__.Categorycard, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
            src: _public_wfh_svg__WEBPACK_IMPORTED_MODULE_11__.default,
            alt: "engg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)("span", {
            children: "Work From Home"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearch, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearchLeft, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Img, {
          src: "./earbugs.svg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 94,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.HeroSearchRight, {
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Search, {
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchIcon, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchImg, {
              src: "./search.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 99,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchField, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.Input, {
              placeholder: "Search Location here..."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 102,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 101,
            columnNumber: 13
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.SearchButton, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxDEV)(_styles_Hero_styled__WEBPACK_IMPORTED_MODULE_1__.ButtonSearch, {
              children: "Search"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 105,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 104,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Locations);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Aboutus.styled.js":
/*!******************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Aboutus.styled.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Aboutuscard": () => (/* binding */ Aboutuscard)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Aboutuscard = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Aboutusstyled__Aboutuscard",
  componentId: "sc-11j1t8n-0"
})(["display:flex;align-items:center;justify-content:center;background-color:#fff;div{width:100%}img{width:447px;height:480px;margin-left:40px;}h2{font-family:Inter;font-style:normal;font-weight:bold;font-size:40px;margin-bottom:60px;width:220px;border-bottom:#F26A7E solid 5px;font-feature-settings:'salt' on,'liga' off;color:#404366;}p{font-family:Inter;font-style:normal;font-weight:normal;font-size:20px;line-height:32px;width:600px;font-feature-settings:'salt' on,'liga' off;color:#18191F;}@media (max-width:", "){flex-direction:column;width:100%;margin-left:100px;img{width:400px;height:420px;margin-left:100px;margin-top:30px;}"], ({
  theme
}) => theme.mobile);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Categories.styled.js":
/*!*********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Categories.styled.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "Divstart": () => (/* binding */ Divstart),
/* harmony export */   "Innerdiv1": () => (/* binding */ Innerdiv1),
/* harmony export */   "Innerdiv2": () => (/* binding */ Innerdiv2),
/* harmony export */   "Span50": () => (/* binding */ Span50),
/* harmony export */   "Span1": () => (/* binding */ Span1),
/* harmony export */   "Spanright": () => (/* binding */ Spanright),
/* harmony export */   "Spanright2": () => (/* binding */ Spanright2),
/* harmony export */   "Lowerdiv": () => (/* binding */ Lowerdiv),
/* harmony export */   "Categorycard": () => (/* binding */ Categorycard),
/* harmony export */   "Categorycard1": () => (/* binding */ Categorycard1),
/* harmony export */   "Logo": () => (/* binding */ Logo),
/* harmony export */   "Button": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Container",
  componentId: "sc-1tyy3ex-0"
})(["width:100%;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;margin-top:40px;}"]);
const Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Divstart",
  componentId: "sc-1tyy3ex-1"
})(["display:flex;justify-content:space-between;flex-wrap:wrap;width:80%;@media (max-width:589px){flex-direction:column;}"]);
const Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Innerdiv1",
  componentId: "sc-1tyy3ex-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
const Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Innerdiv2",
  componentId: "sc-1tyy3ex-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
const Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Span50",
  componentId: "sc-1tyy3ex-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
const Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Span1",
  componentId: "sc-1tyy3ex-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
const Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Spanright",
  componentId: "sc-1tyy3ex-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
const Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Spanright2",
  componentId: "sc-1tyy3ex-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
const Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Lowerdiv",
  componentId: "sc-1tyy3ex-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
const Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Categorycard",
  componentId: "sc-1tyy3ex-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
const Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Categoriesstyled__Categorycard1",
  componentId: "sc-1tyy3ex-10"
})(["width:174px;height:13em;border:0px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
const Logo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Categoriesstyled__Logo",
  componentId: "sc-1tyy3ex-11"
})(["width:30px;height:30px;"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Categoriesstyled__Button",
  componentId: "sc-1tyy3ex-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/CommonComponents/Button.styled.js":
/*!**********************************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/CommonComponents/Button.styled.js ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Button": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Buttonstyled__Button",
  componentId: "sc-1lleeal-0"
})(["cursor:pointer;background-color:#f26a7e;margin-right:20px;color:#fff;font-size:16px;border:none;padding:10px 26px;border-radius:4px;&:hover{background-color:#fc5b73;transition:all 0.3s ease;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/CommonComponents/Card.styled.js":
/*!********************************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/CommonComponents/Card.styled.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Card": () => (/* binding */ Card)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Card = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Cardstyled__Card",
  componentId: "sc-11ak338-0"
})(["background-color:#fff;border:1px solid lightgray;padding:15px;text-align:center;border-radius:7px;display:flex;flex-direction:column;justify-content:space-evenly;img{object-fit:contain;max-height:240px;}h3{font-weight:600;font-size:24px;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/CommonComponents/Heading.styled.js":
/*!***********************************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/CommonComponents/Heading.styled.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Heading": () => (/* binding */ Heading)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Heading = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({
  displayName: "Headingstyled__Heading",
  componentId: "sc-gyir6u-0"
})(["font-family:Inter;font-style:normal;font-weight:bold;font-size:60px;font-feature-settings:'salt' on,'liga' off;color:#404366;"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/CommonComponents/SearchButton.styled.js":
/*!****************************************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/CommonComponents/SearchButton.styled.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchButton": () => (/* binding */ SearchButton)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const SearchButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "SearchButtonstyled__SearchButton",
  componentId: "sc-3c661o-0"
})(["cursor:pointer;text-align:center;background-color:#404366;color:#fff;font-size:16px;width:30%;border:none;padding:13px 38px;border-radius:4px;&:hover{background-color:#404355;transition:all 0.3s ease;}@media (max-width:783px){margin-right:0;font-size:14px;padding:14px 30px;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Contactus.styled.js":
/*!********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Contactus.styled.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "Container1": () => (/* binding */ Container1),
/* harmony export */   "Leftdiv": () => (/* binding */ Leftdiv),
/* harmony export */   "Rightdiv": () => (/* binding */ Rightdiv),
/* harmony export */   "Heading": () => (/* binding */ Heading),
/* harmony export */   "Text": () => (/* binding */ Text),
/* harmony export */   "Logo": () => (/* binding */ Logo),
/* harmony export */   "Button": () => (/* binding */ Button),
/* harmony export */   "Button1": () => (/* binding */ Button1)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Container",
  componentId: "sc-znxz4s-0"
})(["display:flex;align-items:center;justify-content:center;@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
const Container1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Container1",
  componentId: "sc-znxz4s-1"
})(["display:flex;width:80%;@media (max-width:589px){flex-direction:column;}"]);
const Leftdiv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Leftdiv",
  componentId: "sc-znxz4s-2"
})(["display:flex;width:50%;align-items:flex-start;justify-content:center;flex-direction:column;margin-top:15%;"]);
const Rightdiv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Rightdiv",
  componentId: "sc-znxz4s-3"
})(["display:flex;width:50%;align-items:flex-end;justify-content:center;flex-direction:column;margin-top:15%;@media (max-width:589px){align-items:center;justify-content:center;width:100%;}"]);
const Heading = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Heading",
  componentId: "sc-znxz4s-4"
})(["font-family:Inter;font-style:normal;font-weight:bold;font-size:40px;line-height:60px;font-feature-settings:\"salt\" on,\"liga\" off;border-bottom:5px solid #f26a7e;border-radius:4px;color:#404366;@media (max-width:529px){font-weight:500;font-size:22px;}"]);
const Text = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Text",
  componentId: "sc-znxz4s-5"
})(["font-family:Inter;font-style:normal;font-weight:normal;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;margin-top:10%;width:70%;@media (max-width:589px){font-size:16px;line-height:26px;width:200%;}"]);
const Logo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Contactusstyled__Logo",
  componentId: "sc-znxz4s-6"
})(["position:absolute;width:69px;height:69px;left:68px;top:669px;@media (max-width:600px){width:42px;height:42px;left:80%;top:20rem;filter:drop-shadow(-4.26087px 0px 14.6087px rgba(242,106,126,0.44));}"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Contactusstyled__Button",
  componentId: "sc-znxz4s-7"
})(["padding:17px 35px;color:#ffffff;background:#f26a7e;border-radius:6px;border:0px;margin-top:5%;@media (max-width:589px){display:none;}"]);
const Button1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Contactusstyled__Button1",
  componentId: "sc-znxz4s-8"
})(["display:none;@media (max-width:589px){padding:17px 35px;display:flex;color:#ffffff;background:#f26a7e;border-radius:6px;border:0px;margin-top:5%;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Container.styled.js":
/*!********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Container.styled.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Containerstyled__Container",
  componentId: "sc-4pb6dz-0"
})(["width:1000px;max-width:100%;padding:0 20px;margin:20px auto;"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Foundercontainer.styled.js":
/*!***************************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Foundercontainer.styled.js ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Foundercontainer": () => (/* binding */ Foundercontainer)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Foundercontainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Foundercontainerstyled__Foundercontainer",
  componentId: "sc-1v6fy5h-0"
})(["width:100%;max-width:100%;padding:20px 80px;background-color:#C9CBE2;@media (max-width:", "){max-width:1000px;min-width:780px;left:0;background-color:#C9CBE2;margin:40px 40px;border-radius:15px;padding:40px 80px;p{margin-right:50px;}}"], ({
  theme
}) => theme.mobile);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Foundernote.styled.js":
/*!**********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Foundernote.styled.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Foundernote": () => (/* binding */ Foundernote),
/* harmony export */   "Team": () => (/* binding */ Team)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Foundernote = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Foundernotestyled__Foundernote",
  componentId: "sc-1wqnmdx-0"
})(["display:flex;justify-content:center;background-color:#C9CBE2;div{width:100%;background-color:#C9CBE2;}h1{font-family:Inter;font-style:normal;font-weight:bold;font-size:40px;width:400px;font-feature-settings:'salt' on,'liga' off;margin-top:30px;margin-left:80px;margin-bottom:30px;color:#404366;}p{width:640px;margin-left:20px;font-family:Inter;font-style:normal;font-weight:normal;font-size:20px;padding-right:60px;font-feature-settings:'salt' on,'liga' off;color:#404366;}img{width:300px;height:428px;border-radius:19px;}.maintext{display:flex;}.fullname{color:#F26A7E;font-weight:bold;margin-bottom:20px;margin-top:20px}.ceo{font-size:small;margin:none;line-height:0}@media (max-width:", "){flex-direction:column-reverse;align-items:center;background-color:#C9CBE28A;width:device-width;img{margin-left:27%;}h1{margin-left:24%;margin-bottom:30px}p{margin-right:60px;margin-top:30px;}}.quotes{height:50px;width:50px;opacity:0.4}"], ({
  theme
}) => theme.mobile);
const Team = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Foundernotestyled__Team",
  componentId: "sc-1wqnmdx-1"
})([".team{margin-top:20px;display:flex;margin-left:100px;}.teamimg{height:100px;width:100px;border-radius:50%;margin-left:60px;}h4{font-family:", ";font-style:normal;font-weight:bold;font-size:21.2442px;color:#404366;margin-top:80px;}@media (max-width:", "){.team{margin-left:0px;margin-right:40px;background-color:#C9CBE2;}}figcaption{margin-left:45px;margin-top:10px;font-family:Inter;font-style:normal;font-weight:normal;font-feature-settings:'salt' on,'liga' off;color:#404366;}"], ({
  theme
}) => theme.fontFamily, ({
  theme
}) => theme.mobile);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Hero.styled.js":
/*!***************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Hero.styled.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeroDiv": () => (/* binding */ HeroDiv),
/* harmony export */   "HeroContainer": () => (/* binding */ HeroContainer),
/* harmony export */   "HeroLeft": () => (/* binding */ HeroLeft),
/* harmony export */   "HeroRight": () => (/* binding */ HeroRight),
/* harmony export */   "Image": () => (/* binding */ Image),
/* harmony export */   "Button": () => (/* binding */ Button),
/* harmony export */   "Para": () => (/* binding */ Para),
/* harmony export */   "Writer": () => (/* binding */ Writer),
/* harmony export */   "Heading": () => (/* binding */ Heading),
/* harmony export */   "Head": () => (/* binding */ Head),
/* harmony export */   "HeroSearch": () => (/* binding */ HeroSearch),
/* harmony export */   "HeroSearchLeft": () => (/* binding */ HeroSearchLeft),
/* harmony export */   "HeroSearchRight": () => (/* binding */ HeroSearchRight),
/* harmony export */   "Search": () => (/* binding */ Search),
/* harmony export */   "Img": () => (/* binding */ Img),
/* harmony export */   "SearchImg": () => (/* binding */ SearchImg),
/* harmony export */   "SearchIcon": () => (/* binding */ SearchIcon),
/* harmony export */   "SearchField": () => (/* binding */ SearchField),
/* harmony export */   "Input": () => (/* binding */ Input),
/* harmony export */   "ButtonSearch": () => (/* binding */ ButtonSearch),
/* harmony export */   "SearchButton": () => (/* binding */ SearchButton)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const HeroDiv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroDiv",
  componentId: "sc-yjfsrr-0"
})(["display:flex;justify-content:space-between;@media (max-width:589px){max-width:1000px;min-width:780px;flex-direction:column;}"]);
const HeroContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroContainer",
  componentId: "sc-yjfsrr-1"
})(["padding-left:40px;padding-right:40px;padding-bottom:20px;background-color:#f5f5f5;@media (max-width:783px){padding-left:25px;padding-right:25px;}@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
const HeroLeft = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroLeft",
  componentId: "sc-yjfsrr-2"
})(["", " height:450px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;", " ", " margin-left:130px;@media (max-width:783px){height:350px;}@media (max-width:1129px){margin-left:50px;}@media (max-width:903px){margin-left:30px;}"], ""
/* height: 65vh; */
, ""
/* align-items: center; */
, ""
/* text-align: center; */
);
const HeroRight = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroRight",
  componentId: "sc-yjfsrr-3"
})(["height:400px;@media (max-width:783px){text-align:center;margin-top:-30px;margin-bottom:-30px;height:min-content;}"]);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Herostyled__Image",
  componentId: "sc-yjfsrr-4"
})(["width:538px;height:100%;@media (max-width:1129px){width:439px;}@media (max-width:783px){width:365px;height:354px;}@media (max-width:392px){width:265px;height:254px;}@media (max-width:954px){width:390px;}"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Herostyled__Button",
  componentId: "sc-yjfsrr-5"
})(["cursor:pointer;background-color:#f26a7e;margin-right:20px;color:#fff;font-size:16px;border:none;padding:10px 26px;border-radius:4px;&:hover{background-color:#fc5b73;transition:all 0.3s ease;}"]);
const Para = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "Herostyled__Para",
  componentId: "sc-yjfsrr-6"
})(["width:420px;color:#404366;line-height:25px;font-style:italic;font-weight:500;padding:15px 0;@media (max-width:783px){width:332px;font-weight:500;font-size:14px;line-height:21px;}@media (max-width:392px){width:300px;}@media (max-width:341px){width:280px;}"]);
const Writer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "Herostyled__Writer",
  componentId: "sc-yjfsrr-7"
})(["font-weight:500;"]);
const Heading = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({
  displayName: "Herostyled__Heading",
  componentId: "sc-yjfsrr-8"
})(["font-size:45px;color:#404366;margin-bottom:50px;@media (max-width:783px){font-size:36px;margin-bottom:13px;margin-top:0;}@media (max-width:404px){font-size:30px;}"]);
const Head = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "Herostyled__Head",
  componentId: "sc-yjfsrr-9"
})(["font-size:51px;font-weight:bold;@media (max-width:783px){font-size:44px;}@media (max-width:404px){font-size:36px;}"]);
const HeroSearch = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroSearch",
  componentId: "sc-yjfsrr-10"
})(["display:flex;margin-left:40px;margin-right:170px;margin-bottom:40px;@media (max-width:783px){margin-left:0px;margin-right:0px;}"]);
const HeroSearchLeft = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroSearchLeft",
  componentId: "sc-yjfsrr-11"
})(["background-color:#f9bfc2;padding:10px 9px;border-radius:50%;margin-right:60px;@media (max-width:783px){margin-right:0px;position:absolute;right:10px;top:50%;box-shadow:rgba(242,106,126,0.25) 0px 54px 55px,rgba(242,106,126,0.12) 0px -12px 30px,rgba(242,106,126,0.12) 0px 4px 6px,rgba(242,106,126,0.17) 0px 9px 13px,rgba(242,106,126,0.09) 0px -3px 5px;}"]);
const HeroSearchRight = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__HeroSearchRight",
  componentId: "sc-yjfsrr-12"
})(["border:1px solid #c9cbe2;border-radius:4px;height:45px;margin-top:5px;flex:1;"]);
const Search = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__Search",
  componentId: "sc-yjfsrr-13"
})(["display:flex;align-items:center;height:100%;justify-content:flex-start;background-color:#fff;border-radius:4px;@media (max-width:589px){max-width:800px;min-width:780px;margin-left:35px;}"]);
const Img = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Herostyled__Img",
  componentId: "sc-yjfsrr-14"
})(["width:34px;height:25px;"]);
const SearchImg = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Herostyled__SearchImg",
  componentId: "sc-yjfsrr-15"
})(["width:34px;height:25px;@media (max-width:783px){width:24px;height:16px;color:#f26a7e;}"]);
const SearchIcon = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__SearchIcon",
  componentId: "sc-yjfsrr-16"
})(["margin-left:40px;margin-right:40px;background-color:#fff;@media (max-width:783px){margin-left:0;margin-right:5px;}"]);
const SearchField = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__SearchField",
  componentId: "sc-yjfsrr-17"
})(["width:100%;"]);
const Input = styled_components__WEBPACK_IMPORTED_MODULE_0___default().input.withConfig({
  displayName: "Herostyled__Input",
  componentId: "sc-yjfsrr-18"
})(["border:none;outline:none;width:100%;padding:10px 0;color:#404366;font-size:16px;font-weight:400;&::placeholder{color:#c9cbe2;font-size:16px;font-weight:400;}@media (max-width:783px){&::placeholder{font-size:13px;}}"]);
const ButtonSearch = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Herostyled__ButtonSearch",
  componentId: "sc-yjfsrr-19"
})(["cursor:pointer;background-color:#404366;margin-right:20px;color:#fff;font-size:16px;width:100%;border:none;padding:13px 38px;border-radius:4px;&:hover{background-color:#404355;transition:all 0.3s ease;}@media (max-width:783px){margin-right:0;font-size:14px;padding:14px 30px;}"]);
const SearchButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Herostyled__SearchButton",
  componentId: "sc-yjfsrr-20"
})([""]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Locations.styled.js":
/*!********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Locations.styled.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "Divstart": () => (/* binding */ Divstart),
/* harmony export */   "Innerdiv1": () => (/* binding */ Innerdiv1),
/* harmony export */   "Innerdiv2": () => (/* binding */ Innerdiv2),
/* harmony export */   "Span50": () => (/* binding */ Span50),
/* harmony export */   "Span1": () => (/* binding */ Span1),
/* harmony export */   "Spanright": () => (/* binding */ Spanright),
/* harmony export */   "Spanright2": () => (/* binding */ Spanright2),
/* harmony export */   "Lowerdiv": () => (/* binding */ Lowerdiv),
/* harmony export */   "Categorycard": () => (/* binding */ Categorycard),
/* harmony export */   "Categorycard1": () => (/* binding */ Categorycard1),
/* harmony export */   "Logo": () => (/* binding */ Logo),
/* harmony export */   "Button": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Container",
  componentId: "sc-1w9848a-0"
})(["width:100%;margin-top:100px;margin-bottom:80px;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
const Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Divstart",
  componentId: "sc-1w9848a-1"
})(["display:flex;justify-content:space-between;flex-wrap:wrap;width:80%;@media (max-width:589px){flex-direction:column;}"]);
const Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Innerdiv1",
  componentId: "sc-1w9848a-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
const Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Innerdiv2",
  componentId: "sc-1w9848a-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
const Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Span50",
  componentId: "sc-1w9848a-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
const Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Span1",
  componentId: "sc-1w9848a-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
const Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Spanright",
  componentId: "sc-1w9848a-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
const Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Spanright2",
  componentId: "sc-1w9848a-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
const Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Lowerdiv",
  componentId: "sc-1w9848a-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
const Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Categorycard",
  componentId: "sc-1w9848a-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
const Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Locationsstyled__Categorycard1",
  componentId: "sc-1w9848a-10"
})(["width:174px;background-color:#fff8f8;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
const Logo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Locationsstyled__Logo",
  componentId: "sc-1w9848a-11"
})(["width:30px;height:30px;"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Locationsstyled__Button",
  componentId: "sc-1w9848a-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Navbar.styled.js":
/*!*****************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Navbar.styled.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "Image": () => (/* binding */ Image),
/* harmony export */   "Menu": () => (/* binding */ Menu),
/* harmony export */   "Links": () => (/* binding */ Links),
/* harmony export */   "Link": () => (/* binding */ Link),
/* harmony export */   "Button": () => (/* binding */ Button),
/* harmony export */   "ImageContainer": () => (/* binding */ ImageContainer),
/* harmony export */   "LinkContainer": () => (/* binding */ LinkContainer)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Navbarstyled__Container",
  componentId: "sc-1en3s0w-0"
})(["max-width:1200px;margin:0 auto;height:77px;background-color:#fff;display:flex;align-items:center;justify-content:space-between;@media (max-width:1158px){margin-left:40px;margin-right:40px;}@media (max-width:400px){margin-left:20px;margin-right:20px;}"]);
const Image = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Navbarstyled__Image",
  componentId: "sc-1en3s0w-1"
})([""]);
const Menu = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({
  displayName: "Navbarstyled__Menu",
  componentId: "sc-1en3s0w-2"
})(["display:none;@media (max-width:783px){display:block;cursor:pointer;transition:all 0.2s;}"]);
const Links = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Navbarstyled__Links",
  componentId: "sc-1en3s0w-3"
})(["width:500px;display:flex;justify-content:space-between;align-items:center;@media (max-width:783px){flex-direction:column;padding:10px 0;width:100%;height:300px;position:absolute;right:0;top:80px;left:", ";opacity:1;transition:all 0.5s ease;background:#e5e5e5;}"], ({
  click
}) => click ? 0 : "-100%");
const Link = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "Navbarstyled__Link",
  componentId: "sc-1en3s0w-4"
})(["color:#404366;font-size:16px;font-weight:500;@media (max-width:783px){display:flex;align-items:center;justify-content:center;height:80px;border-bottom:2px solid transparent;&:hover{border-bottom:2px solid #4b59f7;}}"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "Navbarstyled__Button",
  componentId: "sc-1en3s0w-5"
})(["cursor:pointer;background-color:#f26a7e;margin-right:20px;color:#fff;font-size:16px;border:none;padding:10px 26px;border-radius:2px;&:hover{background-color:#fc5b73;transition:all 0.3s ease;}@media (max-width:783px){margin-top:20px;margin-bottom:25px;margin-left:20px;padding:12px 64px;", "}"], ""
/* width: 80%;  */
);
const ImageContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Navbarstyled__ImageContainer",
  componentId: "sc-1en3s0w-6"
})(["margin-bottom:10px;"]);
const LinkContainer = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Navbarstyled__LinkContainer",
  componentId: "sc-1en3s0w-7"
})(["display:flex;justify-content:flex-end;"]);

/***/ }),

/***/ "./pages/components/homepage/parts/styles/Section.styled.js":
/*!******************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Section.styled.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": () => (/* binding */ Container),
/* harmony export */   "Top": () => (/* binding */ Top),
/* harmony export */   "Bottom": () => (/* binding */ Bottom),
/* harmony export */   "Wrap": () => (/* binding */ Wrap)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "styled-components");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Sectionstyled__Container",
  componentId: "sc-1rrpk2a-0"
})(["background-color:#fcfcfc;margin:0 auto;padding:100px;display:flex;flex-direction:column;align-items:center;@media (max-width:932px){padding:50px;}@media (max-width:600px){padding:10px;}@media (max-width:589px){max-width:1000px;min-width:780px;margin-left:30px;margin-top:30px;}"]);
const Top = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Sectionstyled__Top",
  componentId: "sc-1rrpk2a-1"
})(["display:flex;@media (max-width:932px){flex-direction:column;}.left{flex:0.5;h1{font-size:72px;color:#404366;max-width:500px;@media (max-width:600px){font-size:52px;}}}.right{margin-left:20px;flex:0.5;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;@media (max-width:932px){margin-left:0;margin-top:20px;}h5{font-weight:500;font-size:20px;line-height:32px;@media (max-width:932px){font-size:15px;line-height:22px;}}button{margin-top:30px;background-color:#f26a7e;color:#fff;border:none;padding:10px;cursor:pointer;border-radius:4px;}}"]);
const Bottom = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Sectionstyled__Bottom",
  componentId: "sc-1rrpk2a-2"
})(["display:grid;margin-top:100px;width:100%;grid-template-columns:repeat(3,minmax(0,1fr));grid-gap:20px;@media (max-width:932px){grid-template-columns:repeat(2,minmax(0,1fr));margin-top:30px;}@media (max-width:600px){grid-template-columns:repeat(1,minmax(0,1fr));}"]);
const Wrap = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Sectionstyled__Wrap",
  componentId: "sc-1rrpk2a-3"
})(["background-color:#fff;border:1px solid lightgray;padding:15px;text-align:center;border-radius:7px;display:flex;flex-direction:column;justify-content:space-evenly;img{object-fit:contain;max-height:240px;}h3{font-weight:600;font-size:24px;}"]);


/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_homepage_Home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/homepage/Home */ "./pages/components/homepage/Home.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__);
var _jsxFileName = "C:\\Users\\AMISHA\\Desktop\\zen-static\\pages\\index.js";




function Home() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("title", {
        children: "Home"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("meta", {
        name: "description",
        content: "Generated by create next app"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("link", {
        rel: "icon",
        href: "/favicon.ico"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(_components_homepage_Home__WEBPACK_IMPORTED_MODULE_1__.default, {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

/***/ }),

/***/ "./public/LT.svg":
/*!***********************!*\
  !*** ./public/LT.svg ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/LT.7d5e2ddc0beaedeb6cdb6a433c9ee4e6.svg","height":80,"width":81});

/***/ }),

/***/ "./public/arts.svg":
/*!*************************!*\
  !*** ./public/arts.svg ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/arts.23c83b9b50c71c3f2ca33c85e67ad1c5.svg","height":81,"width":81});

/***/ }),

/***/ "./public/bengaluru.svg":
/*!******************************!*\
  !*** ./public/bengaluru.svg ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/bengaluru.f9592506beb78ea3c2696277319a1666.svg","height":80,"width":88});

/***/ }),

/***/ "./public/chennai.svg":
/*!****************************!*\
  !*** ./public/chennai.svg ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/chennai.f65804effb732ce3f85d1a855f2b1702.svg","height":80,"width":58});

/***/ }),

/***/ "./public/commerce.svg":
/*!*****************************!*\
  !*** ./public/commerce.svg ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/commerce.36428ebfd59aedabc4d6f0a25990a6ff.svg","height":81,"width":81});

/***/ }),

/***/ "./public/contactus1.svg":
/*!*******************************!*\
  !*** ./public/contactus1.svg ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/contactus1.d48b6629d9705d6f39be55c2b2500cc5.svg","height":508,"width":473});

/***/ }),

/***/ "./public/delhincr.svg":
/*!*****************************!*\
  !*** ./public/delhincr.svg ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/delhincr.c20f3958eedd769b61ed3eeec3153b8d.svg","height":80,"width":78});

/***/ }),

/***/ "./public/engg.svg":
/*!*************************!*\
  !*** ./public/engg.svg ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/engg.fba348f85a33b34e7d03f9086de58138.svg","height":81,"width":81});

/***/ }),

/***/ "./public/help.svg":
/*!*************************!*\
  !*** ./public/help.svg ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/help.374759fb6ba5affb4e724ce0512c3bc4.svg","height":69,"width":69});

/***/ }),

/***/ "./public/humanities.svg":
/*!*******************************!*\
  !*** ./public/humanities.svg ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/humanities.372ed09c592b810320dcf7bd4128050d.svg","height":81,"width":81});

/***/ }),

/***/ "./public/hyderabad.svg":
/*!******************************!*\
  !*** ./public/hyderabad.svg ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/hyderabad.5cec061518f98255da6ad1491b3467e2.svg","height":80,"width":96});

/***/ }),

/***/ "./public/kolkata.svg":
/*!****************************!*\
  !*** ./public/kolkata.svg ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/kolkata.0b7c768a95060404c75901894ade29b1.svg","height":80,"width":135});

/***/ }),

/***/ "./public/law.svg":
/*!************************!*\
  !*** ./public/law.svg ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/law.8666b95e991ecf8510ff6fccd374ed8b.svg","height":81,"width":81});

/***/ }),

/***/ "./public/level.svg":
/*!**************************!*\
  !*** ./public/level.svg ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/level.ac18b6734153bec746783b5a3b5edd55.svg","height":81,"width":81});

/***/ }),

/***/ "./public/medical.svg":
/*!****************************!*\
  !*** ./public/medical.svg ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/medical.0d99f9d0b9029f39f62ab35a8ad916d7.svg","height":81,"width":81});

/***/ }),

/***/ "./public/mumbai.svg":
/*!***************************!*\
  !*** ./public/mumbai.svg ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/mumbai.ec87a1b705539250eabc7fb9e3ad6122.svg","height":80,"width":104});

/***/ }),

/***/ "./public/pune.svg":
/*!*************************!*\
  !*** ./public/pune.svg ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/pune.413eebcc250a52522ab37e676a942a52.svg","height":81,"width":37});

/***/ }),

/***/ "./public/science.svg":
/*!****************************!*\
  !*** ./public/science.svg ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/science.dc85439c83ebb485a5c4194390167f9c.svg","height":81,"width":81});

/***/ }),

/***/ "./public/wfh.svg":
/*!************************!*\
  !*** ./public/wfh.svg ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/image/public/wfh.700e0a508faceabf7dd816ab239860e7.svg","height":80,"width":99});

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "../server/image-config":
/*!***************************************************!*\
  !*** external "next/dist/server/image-config.js" ***!
  \***************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ "../shared/lib/head":
/*!***********************************************!*\
  !*** external "next/dist/shared/lib/head.js" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ "../shared/lib/to-base-64":
/*!*****************************************************!*\
  !*** external "next/dist/shared/lib/to-base-64.js" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFhOztBQUNiQSw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCxlQUFBLEdBQWtCRyxNQUFsQjs7QUFDQSxJQUFJQyxNQUFNLEdBQUdDLHNCQUFzQixDQUFDQyxtQkFBTyxDQUFDLG9CQUFELENBQVIsQ0FBbkM7O0FBQ0EsSUFBSUMsS0FBSyxHQUFHRixzQkFBc0IsQ0FBQ0MsbUJBQU8sQ0FBQyw4Q0FBRCxDQUFSLENBQWxDOztBQUNBLElBQUlFLFNBQVMsR0FBR0YsbUJBQU8sQ0FBQywwREFBRCxDQUF2Qjs7QUFDQSxJQUFJRyxZQUFZLEdBQUdILG1CQUFPLENBQUMsc0RBQUQsQ0FBMUI7O0FBQ0EsSUFBSUksZ0JBQWdCLEdBQUdKLG1CQUFPLENBQUMsK0VBQUQsQ0FBOUI7O0FBQ0EsU0FBU0ssZUFBVCxDQUF5QkMsR0FBekIsRUFBOEJDLEdBQTlCLEVBQW1DWixLQUFuQyxFQUEwQztBQUN0QyxNQUFJWSxHQUFHLElBQUlELEdBQVgsRUFBZ0I7QUFDWmQsSUFBQUEsTUFBTSxDQUFDQyxjQUFQLENBQXNCYSxHQUF0QixFQUEyQkMsR0FBM0IsRUFBZ0M7QUFDNUJaLE1BQUFBLEtBQUssRUFBRUEsS0FEcUI7QUFFNUJhLE1BQUFBLFVBQVUsRUFBRSxJQUZnQjtBQUc1QkMsTUFBQUEsWUFBWSxFQUFFLElBSGM7QUFJNUJDLE1BQUFBLFFBQVEsRUFBRTtBQUprQixLQUFoQztBQU1ILEdBUEQsTUFPTztBQUNISixJQUFBQSxHQUFHLENBQUNDLEdBQUQsQ0FBSCxHQUFXWixLQUFYO0FBQ0g7O0FBQ0QsU0FBT1csR0FBUDtBQUNIOztBQUNELFNBQVNQLHNCQUFULENBQWdDTyxHQUFoQyxFQUFxQztBQUNqQyxTQUFPQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ0ssVUFBWCxHQUF3QkwsR0FBeEIsR0FBOEI7QUFDakNWLElBQUFBLE9BQU8sRUFBRVU7QUFEd0IsR0FBckM7QUFHSDs7QUFDRCxTQUFTTSxhQUFULENBQXVCQyxNQUF2QixFQUErQjtBQUMzQixPQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWVBLENBQUMsR0FBR0MsU0FBUyxDQUFDQyxNQUE3QixFQUFxQ0YsQ0FBQyxFQUF0QyxFQUF5QztBQUNyQyxRQUFJRyxNQUFNLEdBQUdGLFNBQVMsQ0FBQ0QsQ0FBRCxDQUFULElBQWdCLElBQWhCLEdBQXVCQyxTQUFTLENBQUNELENBQUQsQ0FBaEMsR0FBc0MsRUFBbkQ7QUFFQSxRQUFJSSxPQUFPLEdBQUcxQixNQUFNLENBQUMyQixJQUFQLENBQVlGLE1BQVosQ0FBZDs7QUFDQSxRQUFJLE9BQU96QixNQUFNLENBQUM0QixxQkFBZCxLQUF3QyxVQUE1QyxFQUF3RDtBQUNwREYsTUFBQUEsT0FBTyxHQUFHQSxPQUFPLENBQUNHLE1BQVIsQ0FBZTdCLE1BQU0sQ0FBQzRCLHFCQUFQLENBQTZCSCxNQUE3QixFQUFxQ0ssTUFBckMsQ0FBNEMsVUFBU0MsR0FBVCxFQUFjO0FBQy9FLGVBQU8vQixNQUFNLENBQUNnQyx3QkFBUCxDQUFnQ1AsTUFBaEMsRUFBd0NNLEdBQXhDLEVBQTZDZixVQUFwRDtBQUNILE9BRndCLENBQWYsQ0FBVjtBQUdIOztBQUNEVSxJQUFBQSxPQUFPLENBQUNPLE9BQVIsQ0FBZ0IsVUFBU2xCLEdBQVQsRUFBYztBQUMxQkYsTUFBQUEsZUFBZSxDQUFDUSxNQUFELEVBQVNOLEdBQVQsRUFBY1UsTUFBTSxDQUFDVixHQUFELENBQXBCLENBQWY7QUFDSCxLQUZEO0FBR0g7O0FBQ0QsU0FBT00sTUFBUDtBQUNIOztBQUNELFNBQVNhLHdCQUFULENBQWtDVCxNQUFsQyxFQUEwQ1UsUUFBMUMsRUFBb0Q7QUFDaEQsTUFBSVYsTUFBTSxJQUFJLElBQWQsRUFBb0IsT0FBTyxFQUFQOztBQUVwQixNQUFJSixNQUFNLEdBQUdlLDZCQUE2QixDQUFDWCxNQUFELEVBQVNVLFFBQVQsQ0FBMUM7O0FBQ0EsTUFBSXBCLEdBQUosRUFBU08sQ0FBVDs7QUFDQSxNQUFJdEIsTUFBTSxDQUFDNEIscUJBQVgsRUFBa0M7QUFDOUIsUUFBSVMsZ0JBQWdCLEdBQUdyQyxNQUFNLENBQUM0QixxQkFBUCxDQUE2QkgsTUFBN0IsQ0FBdkI7O0FBQ0EsU0FBSUgsQ0FBQyxHQUFHLENBQVIsRUFBV0EsQ0FBQyxHQUFHZSxnQkFBZ0IsQ0FBQ2IsTUFBaEMsRUFBd0NGLENBQUMsRUFBekMsRUFBNEM7QUFDeENQLE1BQUFBLEdBQUcsR0FBR3NCLGdCQUFnQixDQUFDZixDQUFELENBQXRCO0FBQ0EsVUFBSWEsUUFBUSxDQUFDRyxPQUFULENBQWlCdkIsR0FBakIsS0FBeUIsQ0FBN0IsRUFBZ0M7QUFDaEMsVUFBSSxDQUFDZixNQUFNLENBQUN1QyxTQUFQLENBQWlCQyxvQkFBakIsQ0FBc0NDLElBQXRDLENBQTJDaEIsTUFBM0MsRUFBbURWLEdBQW5ELENBQUwsRUFBOEQ7QUFDOURNLE1BQUFBLE1BQU0sQ0FBQ04sR0FBRCxDQUFOLEdBQWNVLE1BQU0sQ0FBQ1YsR0FBRCxDQUFwQjtBQUNIO0FBQ0o7O0FBQ0QsU0FBT00sTUFBUDtBQUNIOztBQUNELFNBQVNlLDZCQUFULENBQXVDWCxNQUF2QyxFQUErQ1UsUUFBL0MsRUFBeUQ7QUFDckQsTUFBSVYsTUFBTSxJQUFJLElBQWQsRUFBb0IsT0FBTyxFQUFQO0FBRXBCLE1BQUlKLE1BQU0sR0FBRyxFQUFiO0FBRUEsTUFBSXFCLFVBQVUsR0FBRzFDLE1BQU0sQ0FBQzJCLElBQVAsQ0FBWUYsTUFBWixDQUFqQjtBQUNBLE1BQUlWLEdBQUosRUFBU08sQ0FBVDs7QUFDQSxPQUFJQSxDQUFDLEdBQUcsQ0FBUixFQUFXQSxDQUFDLEdBQUdvQixVQUFVLENBQUNsQixNQUExQixFQUFrQ0YsQ0FBQyxFQUFuQyxFQUFzQztBQUNsQ1AsSUFBQUEsR0FBRyxHQUFHMkIsVUFBVSxDQUFDcEIsQ0FBRCxDQUFoQjtBQUNBLFFBQUlhLFFBQVEsQ0FBQ0csT0FBVCxDQUFpQnZCLEdBQWpCLEtBQXlCLENBQTdCLEVBQWdDO0FBQ2hDTSxJQUFBQSxNQUFNLENBQUNOLEdBQUQsQ0FBTixHQUFjVSxNQUFNLENBQUNWLEdBQUQsQ0FBcEI7QUFDSDs7QUFDRCxTQUFPTSxNQUFQO0FBQ0g7O0FBQ0QsTUFBTXNCLGVBQWUsR0FBRyxJQUFJQyxHQUFKLEVBQXhCOztBQUNBLElBQUksTUFBK0I7QUFDL0JDLEVBQUFBLE1BQU0sQ0FBQ0MscUJBQVAsR0FBK0IsSUFBL0I7QUFDSDs7QUFDRCxNQUFNQyxvQkFBb0IsR0FBRyxDQUN6QixNQUR5QixFQUV6QixPQUZ5QixFQUd6QkMsU0FIeUIsQ0FBN0I7QUFLQSxNQUFNQyxPQUFPLEdBQUcsSUFBSUMsR0FBSixDQUFRLENBQ3BCLENBQ0ksU0FESixFQUVJQyxhQUZKLENBRG9CLEVBS3BCLENBQ0ksT0FESixFQUVJQyxXQUZKLENBTG9CLEVBU3BCLENBQ0ksWUFESixFQUVJQyxnQkFGSixDQVRvQixFQWFwQixDQUNJLFFBREosRUFFSUMsWUFGSixDQWJvQixFQWlCcEIsQ0FDSSxRQURKLEVBRUlDLFlBRkosQ0FqQm9CLENBQVIsQ0FBaEI7QUFzQkEsTUFBTUMsbUJBQW1CLEdBQUcsQ0FDeEIsTUFEd0IsRUFFeEIsT0FGd0IsRUFHeEIsV0FId0IsRUFJeEIsWUFKd0IsRUFLeEJSLFNBTHdCLENBQTVCOztBQU9BLFNBQVNTLGVBQVQsQ0FBeUJDLEdBQXpCLEVBQThCO0FBQzFCLFNBQU9BLEdBQUcsQ0FBQ3RELE9BQUosS0FBZ0I0QyxTQUF2QjtBQUNIOztBQUNELFNBQVNXLGlCQUFULENBQTJCRCxHQUEzQixFQUFnQztBQUM1QixTQUFPQSxHQUFHLENBQUNBLEdBQUosS0FBWVYsU0FBbkI7QUFDSDs7QUFDRCxTQUFTWSxjQUFULENBQXdCRixHQUF4QixFQUE2QjtBQUN6QixTQUFPLE9BQU9BLEdBQVAsS0FBZSxRQUFmLEtBQTRCRCxlQUFlLENBQUNDLEdBQUQsQ0FBZixJQUF3QkMsaUJBQWlCLENBQUNELEdBQUQsQ0FBckUsQ0FBUDtBQUNIOztBQUNELE1BQU07QUFBRUcsRUFBQUEsV0FBVyxFQUFFQyxpQkFBZjtBQUFtQ0MsRUFBQUEsVUFBVSxFQUFFQyxnQkFBL0M7QUFBa0VDLEVBQUFBLE1BQU0sRUFBRUMsWUFBMUU7QUFBeUZDLEVBQUFBLElBQUksRUFBRUMsVUFBL0Y7QUFBNEdDLEVBQUFBLE9BQU8sRUFBRUM7QUFBckgsSUFBMElDLHNKQUFBLElBQWlDNUQsWUFBWSxDQUFDK0Qsa0JBQTlMLEVBQ0E7O0FBQ0EsTUFBTUMsUUFBUSxHQUFHLENBQ2IsR0FBR2IsaUJBRFUsRUFFYixHQUFHRSxnQkFGVSxDQUFqQjtBQUlBRixpQkFBaUIsQ0FBQ2MsSUFBbEIsQ0FBdUIsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVFELENBQUMsR0FBR0MsQ0FBbkM7QUFFQUgsUUFBUSxDQUFDQyxJQUFULENBQWMsQ0FBQ0MsQ0FBRCxFQUFJQyxDQUFKLEtBQVFELENBQUMsR0FBR0MsQ0FBMUI7O0FBRUEsU0FBU0MsU0FBVCxDQUFtQkMsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDQyxLQUFsQyxFQUF5QztBQUNyQyxNQUFJQSxLQUFLLEtBQUtELE1BQU0sS0FBSyxNQUFYLElBQXFCQSxNQUFNLEtBQUssWUFBckMsQ0FBVCxFQUE2RDtBQUN6RDtBQUNBLFVBQU1FLGVBQWUsR0FBRyxvQkFBeEI7QUFDQSxVQUFNQyxZQUFZLEdBQUcsRUFBckI7O0FBQ0EsU0FBSSxJQUFJQyxLQUFSLEVBQWVBLEtBQUssR0FBR0YsZUFBZSxDQUFDRyxJQUFoQixDQUFxQkosS0FBckIsQ0FBdkIsRUFBb0RHLEtBQXBELEVBQTBEO0FBQ3RERCxNQUFBQSxZQUFZLENBQUNHLElBQWIsQ0FBa0JDLFFBQVEsQ0FBQ0gsS0FBSyxDQUFDLENBQUQsQ0FBTixDQUExQjtBQUNIOztBQUNELFFBQUlELFlBQVksQ0FBQzVELE1BQWpCLEVBQXlCO0FBQ3JCLFlBQU1pRSxhQUFhLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTLEdBQUdQLFlBQVosSUFBNEIsSUFBbEQ7QUFDQSxhQUFPO0FBQ0hRLFFBQUFBLE1BQU0sRUFBRWpCLFFBQVEsQ0FBQzdDLE1BQVQsQ0FBaUIrRCxDQUFELElBQUtBLENBQUMsSUFBSS9CLGlCQUFpQixDQUFDLENBQUQsQ0FBakIsR0FBdUIyQixhQUFqRCxDQURMO0FBR0hLLFFBQUFBLElBQUksRUFBRTtBQUhILE9BQVA7QUFLSDs7QUFDRCxXQUFPO0FBQ0hGLE1BQUFBLE1BQU0sRUFBRWpCLFFBREw7QUFFSG1CLE1BQUFBLElBQUksRUFBRTtBQUZILEtBQVA7QUFJSDs7QUFDRCxNQUFJLE9BQU9kLEtBQVAsS0FBaUIsUUFBakIsSUFBNkJDLE1BQU0sS0FBSyxNQUF4QyxJQUFrREEsTUFBTSxLQUFLLFlBQWpFLEVBQStFO0FBQzNFLFdBQU87QUFDSFcsTUFBQUEsTUFBTSxFQUFFOUIsaUJBREw7QUFFSGdDLE1BQUFBLElBQUksRUFBRTtBQUZILEtBQVA7QUFJSDs7QUFDRCxRQUFNRixNQUFNLEdBQUcsQ0FDWCxHQUFHLElBQUloRCxHQUFKLEVBQVE7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQ0lvQyxLQURKLEVBRUlBLEtBQUssR0FBRztBQUFFO0FBRmQsSUFHRWUsR0FIRixDQUdPQyxDQUFELElBQUtyQixRQUFRLENBQUNzQixJQUFULENBQWVDLENBQUQsSUFBS0EsQ0FBQyxJQUFJRixDQUF4QixLQUNGckIsUUFBUSxDQUFDQSxRQUFRLENBQUNuRCxNQUFULEdBQWtCLENBQW5CLENBSmpCLENBUkcsQ0FEUSxDQUFmO0FBZ0JBLFNBQU87QUFDSG9FLElBQUFBLE1BREc7QUFFSEUsSUFBQUEsSUFBSSxFQUFFO0FBRkgsR0FBUDtBQUlIOztBQUNELFNBQVNLLGdCQUFULENBQTBCO0FBQUV6QyxFQUFBQSxHQUFGO0FBQVEwQyxFQUFBQSxXQUFSO0FBQXNCbkIsRUFBQUEsTUFBdEI7QUFBK0JELEVBQUFBLEtBQS9CO0FBQXVDcUIsRUFBQUEsT0FBdkM7QUFBaURuQixFQUFBQSxLQUFqRDtBQUF5RGpCLEVBQUFBO0FBQXpELENBQTFCLEVBQThGO0FBQzFGLE1BQUltQyxXQUFKLEVBQWlCO0FBQ2IsV0FBTztBQUNIMUMsTUFBQUEsR0FERztBQUVINEMsTUFBQUEsTUFBTSxFQUFFdEQsU0FGTDtBQUdIa0MsTUFBQUEsS0FBSyxFQUFFbEM7QUFISixLQUFQO0FBS0g7O0FBQ0QsUUFBTTtBQUFFNEMsSUFBQUEsTUFBRjtBQUFXRSxJQUFBQTtBQUFYLE1BQXFCZixTQUFTLENBQUNDLEtBQUQsRUFBUUMsTUFBUixFQUFnQkMsS0FBaEIsQ0FBcEM7QUFDQSxRQUFNcUIsSUFBSSxHQUFHWCxNQUFNLENBQUNwRSxNQUFQLEdBQWdCLENBQTdCO0FBQ0EsU0FBTztBQUNIMEQsSUFBQUEsS0FBSyxFQUFFLENBQUNBLEtBQUQsSUFBVVksSUFBSSxLQUFLLEdBQW5CLEdBQXlCLE9BQXpCLEdBQW1DWixLQUR2QztBQUVIb0IsSUFBQUEsTUFBTSxFQUFFVixNQUFNLENBQUNHLEdBQVAsQ0FBVyxDQUFDQyxDQUFELEVBQUkxRSxDQUFKLEtBQVMsR0FBRTJDLE1BQU0sQ0FBQztBQUM3QlAsTUFBQUEsR0FENkI7QUFFN0IyQyxNQUFBQSxPQUY2QjtBQUc3QnJCLE1BQUFBLEtBQUssRUFBRWdCO0FBSHNCLEtBQUQsQ0FJN0IsSUFBR0YsSUFBSSxLQUFLLEdBQVQsR0FBZUUsQ0FBZixHQUFtQjFFLENBQUMsR0FBRyxDQUFFLEdBQUV3RSxJQUFLLEVBSmxDLEVBS05VLElBTE0sQ0FLRCxJQUxDLENBRkw7QUFRSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTlDLElBQUFBLEdBQUcsRUFBRU8sTUFBTSxDQUFDO0FBQ1JQLE1BQUFBLEdBRFE7QUFFUjJDLE1BQUFBLE9BRlE7QUFHUnJCLE1BQUFBLEtBQUssRUFBRVksTUFBTSxDQUFDVyxJQUFEO0FBSEwsS0FBRDtBQWRSLEdBQVA7QUFvQkg7O0FBQ0QsU0FBU0UsTUFBVCxDQUFnQkMsQ0FBaEIsRUFBbUI7QUFDZixNQUFJLE9BQU9BLENBQVAsS0FBYSxRQUFqQixFQUEyQjtBQUN2QixXQUFPQSxDQUFQO0FBQ0g7O0FBQ0QsTUFBSSxPQUFPQSxDQUFQLEtBQWEsUUFBakIsRUFBMkI7QUFDdkIsV0FBT2xCLFFBQVEsQ0FBQ2tCLENBQUQsRUFBSSxFQUFKLENBQWY7QUFDSDs7QUFDRCxTQUFPMUQsU0FBUDtBQUNIOztBQUNELFNBQVMyRCxrQkFBVCxDQUE0QkMsV0FBNUIsRUFBeUM7QUFDckMsUUFBTUMsSUFBSSxHQUFHNUQsT0FBTyxDQUFDNkQsR0FBUixDQUFZNUMsWUFBWixDQUFiOztBQUNBLE1BQUkyQyxJQUFKLEVBQVU7QUFDTixXQUFPQSxJQUFJLENBQUN6RixhQUFhLENBQUM7QUFDdEIyRixNQUFBQSxJQUFJLEVBQUUzQztBQURnQixLQUFELEVBRXRCd0MsV0FGc0IsQ0FBZCxDQUFYO0FBR0g7O0FBQ0QsUUFBTSxJQUFJSSxLQUFKLENBQVcseURBQXdEckcsWUFBWSxDQUFDc0csYUFBYixDQUEyQlQsSUFBM0IsQ0FBZ0MsSUFBaEMsQ0FBc0MsZUFBY3RDLFlBQWEsRUFBcEksQ0FBTjtBQUNILEVBQ0Q7QUFDQTs7O0FBQ0EsU0FBU2dELGFBQVQsQ0FBdUJDLEdBQXZCLEVBQTRCekQsR0FBNUIsRUFBaUN1QixNQUFqQyxFQUF5Q21DLFdBQXpDLEVBQXNEQyxpQkFBdEQsRUFBeUU7QUFDckUsTUFBSSxDQUFDRixHQUFMLEVBQVU7QUFDTjtBQUNIOztBQUNELFFBQU1HLFVBQVUsR0FBRyxNQUFJO0FBQ25CLFFBQUksQ0FBQ0gsR0FBRyxDQUFDekQsR0FBSixDQUFRNkQsVUFBUixDQUFtQixPQUFuQixDQUFMLEVBQWtDO0FBQzlCLFlBQU1yQixDQUFDLEdBQUcsWUFBWWlCLEdBQVosR0FBa0JBLEdBQUcsQ0FBQ0ssTUFBSixFQUFsQixHQUFpQ0MsT0FBTyxDQUFDQyxPQUFSLEVBQTNDO0FBQ0F4QixNQUFBQSxDQUFDLENBQUN5QixLQUFGLENBQVEsTUFBSSxDQUNYLENBREQsRUFDR0MsSUFESCxDQUNRLE1BQUk7QUFDUixZQUFJUixXQUFXLEtBQUssTUFBcEIsRUFBNEI7QUFDeEJELFVBQUFBLEdBQUcsQ0FBQ1UsS0FBSixDQUFVL0YsTUFBVixHQUFtQixNQUFuQjtBQUNBcUYsVUFBQUEsR0FBRyxDQUFDVSxLQUFKLENBQVVDLGNBQVYsR0FBMkIsTUFBM0I7QUFDQVgsVUFBQUEsR0FBRyxDQUFDVSxLQUFKLENBQVVFLGVBQVYsR0FBNEIsTUFBNUI7QUFDSDs7QUFDRHBGLFFBQUFBLGVBQWUsQ0FBQ3FGLEdBQWhCLENBQW9CdEUsR0FBcEI7O0FBQ0EsWUFBSTJELGlCQUFKLEVBQXVCO0FBQ25CLGdCQUFNO0FBQUVZLFlBQUFBLFlBQUY7QUFBaUJDLFlBQUFBO0FBQWpCLGNBQW9DZixHQUExQyxDQURtQixDQUVuQjtBQUNBOztBQUNBRSxVQUFBQSxpQkFBaUIsQ0FBQztBQUNkWSxZQUFBQSxZQURjO0FBRWRDLFlBQUFBO0FBRmMsV0FBRCxDQUFqQjtBQUlIOztBQUNELGtCQUEyQztBQUN2QyxjQUFJQyxHQUFKOztBQUNBLGNBQUksQ0FBQ0EsR0FBRyxHQUFHaEIsR0FBRyxDQUFDaUIsYUFBWCxNQUE4QixJQUE5QixJQUFzQ0QsR0FBRyxLQUFLLEtBQUssQ0FBbkQsR0FBdUQsS0FBSyxDQUE1RCxHQUFnRUEsR0FBRyxDQUFDQyxhQUF4RSxFQUF1RjtBQUNuRixrQkFBTUMsTUFBTSxHQUFHQyxnQkFBZ0IsQ0FBQ25CLEdBQUcsQ0FBQ2lCLGFBQUosQ0FBa0JBLGFBQW5CLENBQS9COztBQUNBLGdCQUFJbkQsTUFBTSxLQUFLLFlBQVgsSUFBMkJvRCxNQUFNLENBQUNFLE9BQVAsS0FBbUIsTUFBbEQsRUFBMEQ7QUFDdERDLGNBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksMEhBQXBDO0FBQ0gsYUFGRCxNQUVPLElBQUl1QixNQUFNLEtBQUssTUFBWCxJQUFxQm9ELE1BQU0sQ0FBQ0ssUUFBUCxLQUFvQixVQUE3QyxFQUF5RDtBQUM1REYsY0FBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWMsbUJBQWtCL0UsR0FBSSwyREFBMEQyRSxNQUFNLENBQUNLLFFBQVMsdUZBQTlHO0FBQ0g7QUFDSjtBQUNKO0FBQ0osT0E1QkQ7QUE2Qkg7QUFDSixHQWpDRDs7QUFrQ0EsTUFBSXZCLEdBQUcsQ0FBQ3dCLFFBQVIsRUFBa0I7QUFDZDtBQUNBO0FBQ0E7QUFDQXJCLElBQUFBLFVBQVU7QUFDYixHQUxELE1BS087QUFDSEgsSUFBQUEsR0FBRyxDQUFDeUIsTUFBSixHQUFhdEIsVUFBYjtBQUNIO0FBQ0o7O0FBQ0QsU0FBU2pILE1BQVQsQ0FBZ0J3SSxNQUFoQixFQUF3QjtBQUNwQixNQUFJO0FBQUVuRixJQUFBQSxHQUFGO0FBQVF3QixJQUFBQSxLQUFSO0FBQWdCa0IsSUFBQUEsV0FBVyxHQUFFLEtBQTdCO0FBQXFDMEMsSUFBQUEsUUFBUSxHQUFFLEtBQS9DO0FBQXVEQyxJQUFBQSxPQUF2RDtBQUFpRUMsSUFBQUEsWUFBWSxHQUFFLE9BQS9FO0FBQXlGQyxJQUFBQSxTQUF6RjtBQUFxRzVDLElBQUFBLE9BQXJHO0FBQStHckIsSUFBQUEsS0FBL0c7QUFBdUhrRSxJQUFBQSxNQUF2SDtBQUFnSUMsSUFBQUEsU0FBaEk7QUFBNElDLElBQUFBLGNBQTVJO0FBQTZKL0IsSUFBQUEsaUJBQTdKO0FBQWlMcEQsSUFBQUEsTUFBTSxHQUFFMEMsa0JBQXpMO0FBQThNUyxJQUFBQSxXQUFXLEdBQUUsT0FBM047QUFBcU9pQyxJQUFBQTtBQUFyTyxNQUFzUFIsTUFBMVA7QUFBQSxNQUFrUVMsR0FBRyxHQUFHcEgsd0JBQXdCLENBQUMyRyxNQUFELEVBQVMsQ0FBQyxLQUFELEVBQVEsT0FBUixFQUFpQixhQUFqQixFQUFnQyxVQUFoQyxFQUE0QyxTQUE1QyxFQUF1RCxjQUF2RCxFQUF1RSxXQUF2RSxFQUFvRixTQUFwRixFQUErRixPQUEvRixFQUF3RyxRQUF4RyxFQUFrSCxXQUFsSCxFQUErSCxnQkFBL0gsRUFBaUosbUJBQWpKLEVBQXNLLFFBQXRLLEVBQWdMLGFBQWhMLEVBQStMLGFBQS9MLENBQVQsQ0FBaFM7O0FBQ0EsTUFBSVUsSUFBSSxHQUFHRCxHQUFYO0FBQ0EsTUFBSXJFLE1BQU0sR0FBR0MsS0FBSyxHQUFHLFlBQUgsR0FBa0IsV0FBcEM7O0FBQ0EsTUFBSSxZQUFZcUUsSUFBaEIsRUFBc0I7QUFDbEI7QUFDQSxRQUFJQSxJQUFJLENBQUN0RSxNQUFULEVBQWlCQSxNQUFNLEdBQUdzRSxJQUFJLENBQUN0RSxNQUFkLENBRkMsQ0FHbEI7O0FBQ0EsV0FBT3NFLElBQUksQ0FBQyxRQUFELENBQVg7QUFDSDs7QUFDRCxNQUFJQyxTQUFTLEdBQUcsRUFBaEI7O0FBQ0EsTUFBSTVGLGNBQWMsQ0FBQ0YsR0FBRCxDQUFsQixFQUF5QjtBQUNyQixVQUFNK0YsZUFBZSxHQUFHaEcsZUFBZSxDQUFDQyxHQUFELENBQWYsR0FBdUJBLEdBQUcsQ0FBQ3RELE9BQTNCLEdBQXFDc0QsR0FBN0Q7O0FBQ0EsUUFBSSxDQUFDK0YsZUFBZSxDQUFDL0YsR0FBckIsRUFBMEI7QUFDdEIsWUFBTSxJQUFJc0QsS0FBSixDQUFXLDhJQUE2STBDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixlQUFmLENBQWdDLEVBQXhMLENBQU47QUFDSDs7QUFDREosSUFBQUEsV0FBVyxHQUFHQSxXQUFXLElBQUlJLGVBQWUsQ0FBQ0osV0FBN0M7QUFDQUcsSUFBQUEsU0FBUyxHQUFHQyxlQUFlLENBQUMvRixHQUE1Qjs7QUFDQSxRQUFJLENBQUN1QixNQUFELElBQVdBLE1BQU0sS0FBSyxNQUExQixFQUFrQztBQUM5QmlFLE1BQUFBLE1BQU0sR0FBR0EsTUFBTSxJQUFJTyxlQUFlLENBQUNQLE1BQW5DO0FBQ0FsRSxNQUFBQSxLQUFLLEdBQUdBLEtBQUssSUFBSXlFLGVBQWUsQ0FBQ3pFLEtBQWpDOztBQUNBLFVBQUksQ0FBQ3lFLGVBQWUsQ0FBQ1AsTUFBakIsSUFBMkIsQ0FBQ08sZUFBZSxDQUFDekUsS0FBaEQsRUFBdUQ7QUFDbkQsY0FBTSxJQUFJZ0MsS0FBSixDQUFXLDJKQUEwSjBDLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixlQUFmLENBQWdDLEVBQXJNLENBQU47QUFDSDtBQUNKO0FBQ0o7O0FBQ0QvRixFQUFBQSxHQUFHLEdBQUcsT0FBT0EsR0FBUCxLQUFlLFFBQWYsR0FBMEJBLEdBQTFCLEdBQWdDOEYsU0FBdEM7QUFDQSxRQUFNSSxRQUFRLEdBQUduRCxNQUFNLENBQUN6QixLQUFELENBQXZCO0FBQ0EsUUFBTTZFLFNBQVMsR0FBR3BELE1BQU0sQ0FBQ3lDLE1BQUQsQ0FBeEI7QUFDQSxRQUFNWSxVQUFVLEdBQUdyRCxNQUFNLENBQUNKLE9BQUQsQ0FBekI7QUFDQSxNQUFJMEQsTUFBTSxHQUFHLENBQUNqQixRQUFELEtBQWNDLE9BQU8sS0FBSyxNQUFaLElBQXNCLE9BQU9BLE9BQVAsS0FBbUIsV0FBdkQsQ0FBYjs7QUFDQSxNQUFJckYsR0FBRyxDQUFDNkQsVUFBSixDQUFlLE9BQWYsS0FBMkI3RCxHQUFHLENBQUM2RCxVQUFKLENBQWUsT0FBZixDQUEvQixFQUF3RDtBQUNwRDtBQUNBbkIsSUFBQUEsV0FBVyxHQUFHLElBQWQ7QUFDQTJELElBQUFBLE1BQU0sR0FBRyxLQUFUO0FBQ0g7O0FBQ0QsTUFBSSxLQUFKLEVBQStELEVBRTlEOztBQUNELFlBQTJDO0FBQ3ZDLFFBQUksQ0FBQ3JHLEdBQUwsRUFBVTtBQUNOLFlBQU0sSUFBSXNELEtBQUosQ0FBVywwSEFBeUgwQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNySjNFLFFBQUFBLEtBRHFKO0FBRXJKa0UsUUFBQUEsTUFGcUo7QUFHcko3QyxRQUFBQTtBQUhxSixPQUFmLENBSXZJLEVBSkcsQ0FBTjtBQUtIOztBQUNELFFBQUksQ0FBQzdDLG1CQUFtQixDQUFDeUcsUUFBcEIsQ0FBNkJoRixNQUE3QixDQUFMLEVBQTJDO0FBQ3ZDLFlBQU0sSUFBSStCLEtBQUosQ0FBVyxtQkFBa0J0RCxHQUFJLDhDQUE2Q3VCLE1BQU8sc0JBQXFCekIsbUJBQW1CLENBQUN1QyxHQUFwQixDQUF3Qm1FLE1BQXhCLEVBQWdDMUQsSUFBaEMsQ0FBcUMsR0FBckMsQ0FBMEMsR0FBcEosQ0FBTjtBQUNIOztBQUNELFFBQUksT0FBT29ELFFBQVAsS0FBb0IsV0FBcEIsSUFBbUNPLEtBQUssQ0FBQ1AsUUFBRCxDQUF4QyxJQUFzRCxPQUFPQyxTQUFQLEtBQXFCLFdBQXJCLElBQW9DTSxLQUFLLENBQUNOLFNBQUQsQ0FBbkcsRUFBZ0g7QUFDNUcsWUFBTSxJQUFJN0MsS0FBSixDQUFXLG1CQUFrQnRELEdBQUksNkVBQWpDLENBQU47QUFDSDs7QUFDRCxRQUFJdUIsTUFBTSxLQUFLLE1BQVgsS0FBc0JELEtBQUssSUFBSWtFLE1BQS9CLENBQUosRUFBNEM7QUFDeENWLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksMkZBQXBDO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDWCxvQkFBb0IsQ0FBQ2tILFFBQXJCLENBQThCbEIsT0FBOUIsQ0FBTCxFQUE2QztBQUN6QyxZQUFNLElBQUkvQixLQUFKLENBQVcsbUJBQWtCdEQsR0FBSSwrQ0FBOENxRixPQUFRLHNCQUFxQmhHLG9CQUFvQixDQUFDZ0QsR0FBckIsQ0FBeUJtRSxNQUF6QixFQUFpQzFELElBQWpDLENBQXNDLEdBQXRDLENBQTJDLEdBQXZKLENBQU47QUFDSDs7QUFDRCxRQUFJc0MsUUFBUSxJQUFJQyxPQUFPLEtBQUssTUFBNUIsRUFBb0M7QUFDaEMsWUFBTSxJQUFJL0IsS0FBSixDQUFXLG1CQUFrQnRELEdBQUksaUZBQWpDLENBQU47QUFDSDs7QUFDRCxRQUFJMEQsV0FBVyxLQUFLLE1BQXBCLEVBQTRCO0FBQ3hCLFVBQUluQyxNQUFNLEtBQUssTUFBWCxJQUFxQixDQUFDMkUsUUFBUSxJQUFJLENBQWIsS0FBbUJDLFNBQVMsSUFBSSxDQUFoQyxJQUFxQyxJQUE5RCxFQUFvRTtBQUNoRXJCLFFBQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksc0dBQXBDO0FBQ0g7O0FBQ0QsVUFBSSxDQUFDMkYsV0FBTCxFQUFrQjtBQUNkLGNBQU1lLGNBQWMsR0FBRyxDQUNuQixNQURtQixFQUVuQixLQUZtQixFQUduQixNQUhtQixDQUF2QixDQUlFO0FBSkY7QUFNQSxjQUFNLElBQUlwRCxLQUFKLENBQVcsbUJBQWtCdEQsR0FBSTtBQUN2RDtBQUNBO0FBQ0EsbUdBQW1HMEcsY0FBYyxDQUFDNUQsSUFBZixDQUFvQixHQUFwQixDQUF5QjtBQUM1SDtBQUNBLGdGQUxzQixDQUFOO0FBTUg7QUFDSjs7QUFDRCxRQUFJLFNBQVMrQyxJQUFiLEVBQW1CO0FBQ2ZmLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUksaUdBQXBDO0FBQ0g7O0FBQ0QsUUFBSSxXQUFXNkYsSUFBZixFQUFxQjtBQUNqQmYsTUFBQUEsT0FBTyxDQUFDQyxJQUFSLENBQWMsbUJBQWtCL0UsR0FBSSx1RkFBcEM7QUFDSDs7QUFDRCxVQUFNMkcsSUFBSSxHQUFHM0UsSUFBSSxDQUFDNEUsS0FBTCxDQUFXNUUsSUFBSSxDQUFDNkUsTUFBTCxLQUFnQixJQUEzQixJQUFtQyxHQUFoRDs7QUFDQSxRQUFJLENBQUNuRSxXQUFELElBQWdCLENBQUNuQyxNQUFNLENBQUM7QUFDeEJQLE1BQUFBLEdBRHdCO0FBRXhCc0IsTUFBQUEsS0FBSyxFQUFFcUYsSUFGaUI7QUFHeEJoRSxNQUFBQSxPQUFPLEVBQUU7QUFIZSxLQUFELENBQU4sQ0FJbEI0RCxRQUprQixDQUlUSSxJQUFJLENBQUNHLFFBQUwsRUFKUyxDQUFyQixFQUk4QjtBQUMxQmhDLE1BQUFBLE9BQU8sQ0FBQ0MsSUFBUixDQUFjLG1CQUFrQi9FLEdBQUkseUhBQXZCLEdBQW1KLCtFQUFoSztBQUNIO0FBQ0o7O0FBQ0QsUUFBTSxDQUFDK0csTUFBRCxFQUFTQyxhQUFULElBQTBCLENBQUMsR0FBRzlKLGdCQUFKLEVBQXNCK0osZUFBdEIsQ0FBc0M7QUFDbEVDLElBQUFBLFVBQVUsRUFBRTVCLFlBRHNEO0FBRWxFNkIsSUFBQUEsUUFBUSxFQUFFLENBQUNkO0FBRnVELEdBQXRDLENBQWhDO0FBSUEsUUFBTWUsU0FBUyxHQUFHLENBQUNmLE1BQUQsSUFBV1csYUFBN0I7QUFDQSxNQUFJSyxZQUFKO0FBQ0EsTUFBSUMsVUFBSjtBQUNBLE1BQUlDLFFBQUo7QUFDQSxNQUFJQyxRQUFRLEdBQUc7QUFDWHhDLElBQUFBLFFBQVEsRUFBRSxVQURDO0FBRVh5QyxJQUFBQSxHQUFHLEVBQUUsQ0FGTTtBQUdYQyxJQUFBQSxJQUFJLEVBQUUsQ0FISztBQUlYQyxJQUFBQSxNQUFNLEVBQUUsQ0FKRztBQUtYQyxJQUFBQSxLQUFLLEVBQUUsQ0FMSTtBQU1YQyxJQUFBQSxTQUFTLEVBQUUsWUFOQTtBQU9YQyxJQUFBQSxPQUFPLEVBQUUsQ0FQRTtBQVFYQyxJQUFBQSxNQUFNLEVBQUUsTUFSRztBQVNYQyxJQUFBQSxNQUFNLEVBQUUsTUFURztBQVVYbkQsSUFBQUEsT0FBTyxFQUFFLE9BVkU7QUFXWHZELElBQUFBLEtBQUssRUFBRSxDQVhJO0FBWVhrRSxJQUFBQSxNQUFNLEVBQUUsQ0FaRztBQWFYeUMsSUFBQUEsUUFBUSxFQUFFLE1BYkM7QUFjWEMsSUFBQUEsUUFBUSxFQUFFLE1BZEM7QUFlWEMsSUFBQUEsU0FBUyxFQUFFLE1BZkE7QUFnQlhDLElBQUFBLFNBQVMsRUFBRSxNQWhCQTtBQWlCWDNDLElBQUFBLFNBakJXO0FBa0JYQyxJQUFBQTtBQWxCVyxHQUFmO0FBb0JBLFFBQU0yQyxTQUFTLEdBQUczRSxXQUFXLEtBQUssTUFBaEIsR0FBeUI7QUFDdkN0RixJQUFBQSxNQUFNLEVBQUUsWUFEK0I7QUFFdkNnRyxJQUFBQSxjQUFjLEVBQUVxQixTQUFTLElBQUksT0FGVTtBQUd2Q3BCLElBQUFBLGVBQWUsRUFBRyxRQUFPc0IsV0FBWSxJQUhFO0FBSXZDMkMsSUFBQUEsa0JBQWtCLEVBQUU1QyxjQUFjLElBQUk7QUFKQyxHQUF6QixHQUtkLEVBTEo7O0FBT0EsTUFBSW5FLE1BQU0sS0FBSyxNQUFmLEVBQXVCO0FBQ25CO0FBQ0E4RixJQUFBQSxZQUFZLEdBQUc7QUFDWHhDLE1BQUFBLE9BQU8sRUFBRSxPQURFO0FBRVgwRCxNQUFBQSxRQUFRLEVBQUUsUUFGQztBQUdYdkQsTUFBQUEsUUFBUSxFQUFFLFVBSEM7QUFJWHlDLE1BQUFBLEdBQUcsRUFBRSxDQUpNO0FBS1hDLE1BQUFBLElBQUksRUFBRSxDQUxLO0FBTVhDLE1BQUFBLE1BQU0sRUFBRSxDQU5HO0FBT1hDLE1BQUFBLEtBQUssRUFBRSxDQVBJO0FBUVhDLE1BQUFBLFNBQVMsRUFBRSxZQVJBO0FBU1hHLE1BQUFBLE1BQU0sRUFBRTtBQVRHLEtBQWY7QUFXSCxHQWJELE1BYU8sSUFBSSxPQUFPOUIsUUFBUCxLQUFvQixXQUFwQixJQUFtQyxPQUFPQyxTQUFQLEtBQXFCLFdBQTVELEVBQXlFO0FBQzVFO0FBQ0EsVUFBTXFDLFFBQVEsR0FBR3JDLFNBQVMsR0FBR0QsUUFBN0I7QUFDQSxVQUFNdUMsVUFBVSxHQUFHaEMsS0FBSyxDQUFDK0IsUUFBRCxDQUFMLEdBQWtCLE1BQWxCLEdBQTRCLEdBQUVBLFFBQVEsR0FBRyxHQUFJLEdBQWhFOztBQUNBLFFBQUlqSCxNQUFNLEtBQUssWUFBZixFQUE2QjtBQUN6QjtBQUNBOEYsTUFBQUEsWUFBWSxHQUFHO0FBQ1h4QyxRQUFBQSxPQUFPLEVBQUUsT0FERTtBQUVYMEQsUUFBQUEsUUFBUSxFQUFFLFFBRkM7QUFHWHZELFFBQUFBLFFBQVEsRUFBRSxVQUhDO0FBSVg2QyxRQUFBQSxTQUFTLEVBQUUsWUFKQTtBQUtYRyxRQUFBQSxNQUFNLEVBQUU7QUFMRyxPQUFmO0FBT0FWLE1BQUFBLFVBQVUsR0FBRztBQUNUekMsUUFBQUEsT0FBTyxFQUFFLE9BREE7QUFFVGdELFFBQUFBLFNBQVMsRUFBRSxZQUZGO0FBR1RZLFFBQUFBO0FBSFMsT0FBYjtBQUtILEtBZEQsTUFjTyxJQUFJbEgsTUFBTSxLQUFLLFdBQWYsRUFBNEI7QUFDL0I7QUFDQThGLE1BQUFBLFlBQVksR0FBRztBQUNYeEMsUUFBQUEsT0FBTyxFQUFFLGNBREU7QUFFWHFELFFBQUFBLFFBQVEsRUFBRSxNQUZDO0FBR1hLLFFBQUFBLFFBQVEsRUFBRSxRQUhDO0FBSVh2RCxRQUFBQSxRQUFRLEVBQUUsVUFKQztBQUtYNkMsUUFBQUEsU0FBUyxFQUFFLFlBTEE7QUFNWEcsUUFBQUEsTUFBTSxFQUFFO0FBTkcsT0FBZjtBQVFBVixNQUFBQSxVQUFVLEdBQUc7QUFDVE8sUUFBQUEsU0FBUyxFQUFFLFlBREY7QUFFVGhELFFBQUFBLE9BQU8sRUFBRSxPQUZBO0FBR1RxRCxRQUFBQSxRQUFRLEVBQUU7QUFIRCxPQUFiO0FBS0FYLE1BQUFBLFFBQVEsR0FBSSxlQUFjckIsUUFBUyxhQUFZQyxTQUFVLHNEQUF6RDtBQUNILEtBaEJNLE1BZ0JBLElBQUk1RSxNQUFNLEtBQUssT0FBZixFQUF3QjtBQUMzQjtBQUNBOEYsTUFBQUEsWUFBWSxHQUFHO0FBQ1hrQixRQUFBQSxRQUFRLEVBQUUsUUFEQztBQUVYVixRQUFBQSxTQUFTLEVBQUUsWUFGQTtBQUdYaEQsUUFBQUEsT0FBTyxFQUFFLGNBSEU7QUFJWEcsUUFBQUEsUUFBUSxFQUFFLFVBSkM7QUFLWDFELFFBQUFBLEtBQUssRUFBRTRFLFFBTEk7QUFNWFYsUUFBQUEsTUFBTSxFQUFFVztBQU5HLE9BQWY7QUFRSDtBQUNKLEdBN0NNLE1BNkNBO0FBQ0g7QUFDQSxjQUEyQztBQUN2QyxZQUFNLElBQUk3QyxLQUFKLENBQVcsbUJBQWtCdEQsR0FBSSx5RUFBakMsQ0FBTjtBQUNIO0FBQ0o7O0FBQ0QsTUFBSTBJLGFBQWEsR0FBRztBQUNoQjFJLElBQUFBLEdBQUcsRUFBRSxnRkFEVztBQUVoQjRDLElBQUFBLE1BQU0sRUFBRXRELFNBRlE7QUFHaEJrQyxJQUFBQSxLQUFLLEVBQUVsQztBQUhTLEdBQXBCOztBQUtBLE1BQUk4SCxTQUFKLEVBQWU7QUFDWHNCLElBQUFBLGFBQWEsR0FBR2pHLGdCQUFnQixDQUFDO0FBQzdCekMsTUFBQUEsR0FENkI7QUFFN0IwQyxNQUFBQSxXQUY2QjtBQUc3Qm5CLE1BQUFBLE1BSDZCO0FBSTdCRCxNQUFBQSxLQUFLLEVBQUU0RSxRQUpzQjtBQUs3QnZELE1BQUFBLE9BQU8sRUFBRXlELFVBTG9CO0FBTTdCNUUsTUFBQUEsS0FONkI7QUFPN0JqQixNQUFBQTtBQVA2QixLQUFELENBQWhDO0FBU0g7O0FBQ0QsTUFBSW9JLFNBQVMsR0FBRzNJLEdBQWhCO0FBQ0EsU0FBTyxhQUFjcEQsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQ3JEekUsSUFBQUEsS0FBSyxFQUFFa0Q7QUFEOEMsR0FBcEMsRUFFbEJDLFVBQVUsR0FBRyxhQUFjMUssTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQzlEekUsSUFBQUEsS0FBSyxFQUFFbUQ7QUFEdUQsR0FBcEMsRUFFM0JDLFFBQVEsR0FBRyxhQUFjM0ssTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLEtBQTdCLEVBQW9DO0FBQzVEekUsSUFBQUEsS0FBSyxFQUFFO0FBQ0grRCxNQUFBQSxRQUFRLEVBQUUsTUFEUDtBQUVIckQsTUFBQUEsT0FBTyxFQUFFLE9BRk47QUFHSG1ELE1BQUFBLE1BQU0sRUFBRSxDQUhMO0FBSUhELE1BQUFBLE1BQU0sRUFBRSxNQUpMO0FBS0hELE1BQUFBLE9BQU8sRUFBRTtBQUxOLEtBRHFEO0FBUTVEZSxJQUFBQSxHQUFHLEVBQUUsRUFSdUQ7QUFTNUQsbUJBQWUsSUFUNkM7QUFVNUQ3SSxJQUFBQSxHQUFHLEVBQUcsNkJBQTRCLENBQUMsR0FBR2hELFNBQUosRUFBZThMLFFBQWYsQ0FBd0J2QixRQUF4QixDQUFrQztBQVZSLEdBQXBDLENBQWpCLEdBV04sSUFieUIsQ0FBakIsR0FhQSxJQWZRLEVBZUYsYUFBYzNLLE1BQU0sQ0FBQ0YsT0FBUCxDQUFla00sYUFBZixDQUE2QixLQUE3QixFQUFvQ3RNLE1BQU0sQ0FBQ3lNLE1BQVAsQ0FBYyxFQUFkLEVBQ2xFbEQsSUFEa0UsRUFDNUQ2QyxhQUQ0RCxFQUM3QztBQUNwQk0sSUFBQUEsUUFBUSxFQUFFLE9BRFU7QUFFcEIsaUJBQWF6SCxNQUZPO0FBR3BCZ0UsSUFBQUEsU0FBUyxFQUFFQSxTQUhTO0FBSXBCZCxJQUFBQSxHQUFHLEVBQUdoQixHQUFELElBQU87QUFDUnNELE1BQUFBLE1BQU0sQ0FBQ3RELEdBQUQsQ0FBTjtBQUNBRCxNQUFBQSxhQUFhLENBQUNDLEdBQUQsRUFBTWtGLFNBQU4sRUFBaUJwSCxNQUFqQixFQUF5Qm1DLFdBQXpCLEVBQXNDQyxpQkFBdEMsQ0FBYjtBQUNILEtBUG1CO0FBUXBCUSxJQUFBQSxLQUFLLEVBQUV6RyxhQUFhLENBQUMsRUFBRCxFQUNqQjhKLFFBRGlCLEVBQ1BhLFNBRE87QUFSQSxHQUQ2QyxDQUFwQyxDQWZaLEVBMEJoQixhQUFjekwsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLFVBQTdCLEVBQXlDLElBQXpDLEVBQStDLGFBQWNoTSxNQUFNLENBQUNGLE9BQVAsQ0FBZWtNLGFBQWYsQ0FBNkIsS0FBN0IsRUFBb0N0TSxNQUFNLENBQUN5TSxNQUFQLENBQWMsRUFBZCxFQUNqSGxELElBRGlILEVBQzNHcEQsZ0JBQWdCLENBQUM7QUFDdEJ6QyxJQUFBQSxHQURzQjtBQUV0QjBDLElBQUFBLFdBRnNCO0FBR3RCbkIsSUFBQUEsTUFIc0I7QUFJdEJELElBQUFBLEtBQUssRUFBRTRFLFFBSmU7QUFLdEJ2RCxJQUFBQSxPQUFPLEVBQUV5RCxVQUxhO0FBTXRCNUUsSUFBQUEsS0FOc0I7QUFPdEJqQixJQUFBQTtBQVBzQixHQUFELENBRDJGLEVBU2hIO0FBQ0F5SSxJQUFBQSxRQUFRLEVBQUUsT0FEVjtBQUVBLGlCQUFhekgsTUFGYjtBQUdBNEMsSUFBQUEsS0FBSyxFQUFFcUQsUUFIUDtBQUlBakMsSUFBQUEsU0FBUyxFQUFFQSxTQUpYO0FBS0FGLElBQUFBLE9BQU8sRUFBRUEsT0FBTyxJQUFJO0FBTHBCLEdBVGdILENBQXBDLENBQTdELENBMUJFLEVBeUNmRCxRQUFRLEdBQUc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFBY3hJLEVBQUFBLE1BQU0sQ0FBQ0YsT0FBUCxDQUFla00sYUFBZixDQUE2QjdMLEtBQUssQ0FBQ0wsT0FBbkMsRUFBNEMsSUFBNUMsRUFBa0QsYUFBY0UsTUFBTSxDQUFDRixPQUFQLENBQWVrTSxhQUFmLENBQTZCLE1BQTdCLEVBQXFDO0FBQy9HdkwsSUFBQUEsR0FBRyxFQUFFLFlBQVlxTCxhQUFhLENBQUMxSSxHQUExQixHQUFnQzBJLGFBQWEsQ0FBQzlGLE1BQTlDLEdBQXVEOEYsYUFBYSxDQUFDbEgsS0FEcUM7QUFFL0d5SCxJQUFBQSxHQUFHLEVBQUUsU0FGMEc7QUFHL0dDLElBQUFBLEVBQUUsRUFBRSxPQUgyRztBQUkvR0MsSUFBQUEsSUFBSSxFQUFFVCxhQUFhLENBQUM5RixNQUFkLEdBQXVCdEQsU0FBdkIsR0FBbUNvSixhQUFhLENBQUMxSSxHQUp3RDtBQUsvRztBQUNBb0osSUFBQUEsV0FBVyxFQUFFVixhQUFhLENBQUM5RixNQU5vRjtBQU8vRztBQUNBeUcsSUFBQUEsVUFBVSxFQUFFWCxhQUFhLENBQUNsSDtBQVJxRixHQUFyQyxDQUFoRSxDQUxBLEdBY1IsSUF2RGUsQ0FBckI7QUF3REg7O0FBQ0QsU0FBUzhILFlBQVQsQ0FBc0J0SixHQUF0QixFQUEyQjtBQUN2QixTQUFPQSxHQUFHLENBQUMsQ0FBRCxDQUFILEtBQVcsR0FBWCxHQUFpQkEsR0FBRyxDQUFDdUosS0FBSixDQUFVLENBQVYsQ0FBakIsR0FBZ0N2SixHQUF2QztBQUNIOztBQUNELFNBQVNOLFdBQVQsQ0FBcUI7QUFBRTJELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBLEtBQWY7QUFBdUJxQixFQUFBQTtBQUF2QixDQUFyQixFQUF3RDtBQUNwRDtBQUNBLFFBQU02RyxHQUFHLEdBQUcsSUFBSUMsR0FBSixDQUFTLEdBQUVwRyxJQUFLLEdBQUVpRyxZQUFZLENBQUN0SixHQUFELENBQU0sRUFBcEMsQ0FBWjtBQUNBLFFBQU0wSixNQUFNLEdBQUdGLEdBQUcsQ0FBQ0csWUFBbkI7QUFDQUQsRUFBQUEsTUFBTSxDQUFDRSxHQUFQLENBQVcsTUFBWCxFQUFtQkYsTUFBTSxDQUFDdEcsR0FBUCxDQUFXLE1BQVgsS0FBc0IsUUFBekM7QUFDQXNHLEVBQUFBLE1BQU0sQ0FBQ0UsR0FBUCxDQUFXLEtBQVgsRUFBa0JGLE1BQU0sQ0FBQ3RHLEdBQVAsQ0FBVyxLQUFYLEtBQXFCLEtBQXZDO0FBQ0FzRyxFQUFBQSxNQUFNLENBQUNFLEdBQVAsQ0FBVyxHQUFYLEVBQWdCRixNQUFNLENBQUN0RyxHQUFQLENBQVcsR0FBWCxLQUFtQjlCLEtBQUssQ0FBQ3dGLFFBQU4sRUFBbkM7O0FBQ0EsTUFBSW5FLE9BQUosRUFBYTtBQUNUK0csSUFBQUEsTUFBTSxDQUFDRSxHQUFQLENBQVcsR0FBWCxFQUFnQmpILE9BQU8sQ0FBQ21FLFFBQVIsRUFBaEI7QUFDSDs7QUFDRCxTQUFPMEMsR0FBRyxDQUFDTCxJQUFYO0FBQ0g7O0FBQ0QsU0FBU3ZKLFlBQVQsQ0FBc0I7QUFBRXlELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBO0FBQWYsQ0FBdEIsRUFBK0M7QUFDM0MsU0FBUSxHQUFFK0IsSUFBSyxHQUFFaUcsWUFBWSxDQUFDdEosR0FBRCxDQUFNLFlBQVdzQixLQUFNLEVBQXBEO0FBQ0g7O0FBQ0QsU0FBUzNCLGdCQUFULENBQTBCO0FBQUUwRCxFQUFBQSxJQUFGO0FBQVNyRCxFQUFBQSxHQUFUO0FBQWVzQixFQUFBQSxLQUFmO0FBQXVCcUIsRUFBQUE7QUFBdkIsQ0FBMUIsRUFBNkQ7QUFDekQ7QUFDQSxRQUFNK0csTUFBTSxHQUFHLENBQ1gsUUFEVyxFQUVYLFNBRlcsRUFHWCxPQUFPcEksS0FISSxFQUlYLFFBQVFxQixPQUFPLElBQUksTUFBbkIsQ0FKVyxDQUFmO0FBTUEsTUFBSWtILFlBQVksR0FBR0gsTUFBTSxDQUFDNUcsSUFBUCxDQUFZLEdBQVosSUFBbUIsR0FBdEM7QUFDQSxTQUFRLEdBQUVPLElBQUssR0FBRXdHLFlBQWEsR0FBRVAsWUFBWSxDQUFDdEosR0FBRCxDQUFNLEVBQWxEO0FBQ0g7O0FBQ0QsU0FBU0gsWUFBVCxDQUFzQjtBQUFFRyxFQUFBQTtBQUFGLENBQXRCLEVBQWdDO0FBQzVCLFFBQU0sSUFBSXNELEtBQUosQ0FBVyxtQkFBa0J0RCxHQUFJLDZCQUF2QixHQUF1RCx5RUFBakUsQ0FBTjtBQUNIOztBQUNELFNBQVNQLGFBQVQsQ0FBdUI7QUFBRTRELEVBQUFBLElBQUY7QUFBU3JELEVBQUFBLEdBQVQ7QUFBZXNCLEVBQUFBLEtBQWY7QUFBdUJxQixFQUFBQTtBQUF2QixDQUF2QixFQUEwRDtBQUN0RCxZQUEyQztBQUN2QyxVQUFNbUgsYUFBYSxHQUFHLEVBQXRCLENBRHVDLENBRXZDOztBQUNBLFFBQUksQ0FBQzlKLEdBQUwsRUFBVThKLGFBQWEsQ0FBQ2pJLElBQWQsQ0FBbUIsS0FBbkI7QUFDVixRQUFJLENBQUNQLEtBQUwsRUFBWXdJLGFBQWEsQ0FBQ2pJLElBQWQsQ0FBbUIsT0FBbkI7O0FBQ1osUUFBSWlJLGFBQWEsQ0FBQ2hNLE1BQWQsR0FBdUIsQ0FBM0IsRUFBOEI7QUFDMUIsWUFBTSxJQUFJd0YsS0FBSixDQUFXLG9DQUFtQ3dHLGFBQWEsQ0FBQ2hILElBQWQsQ0FBbUIsSUFBbkIsQ0FBeUIsZ0dBQStGa0QsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDdkxqRyxRQUFBQSxHQUR1TDtBQUV2THNCLFFBQUFBLEtBRnVMO0FBR3ZMcUIsUUFBQUE7QUFIdUwsT0FBZixDQUl6SyxFQUpHLENBQU47QUFLSDs7QUFDRCxRQUFJM0MsR0FBRyxDQUFDNkQsVUFBSixDQUFlLElBQWYsQ0FBSixFQUEwQjtBQUN0QixZQUFNLElBQUlQLEtBQUosQ0FBVyx3QkFBdUJ0RCxHQUFJLDBHQUF0QyxDQUFOO0FBQ0g7O0FBQ0QsUUFBSSxDQUFDQSxHQUFHLENBQUM2RCxVQUFKLENBQWUsR0FBZixDQUFELElBQXdCakQsYUFBNUIsRUFBMkM7QUFDdkMsVUFBSW1KLFNBQUo7O0FBQ0EsVUFBSTtBQUNBQSxRQUFBQSxTQUFTLEdBQUcsSUFBSU4sR0FBSixDQUFRekosR0FBUixDQUFaO0FBQ0gsT0FGRCxDQUVFLE9BQU9nSyxHQUFQLEVBQVk7QUFDVmxGLFFBQUFBLE9BQU8sQ0FBQ21GLEtBQVIsQ0FBY0QsR0FBZDtBQUNBLGNBQU0sSUFBSTFHLEtBQUosQ0FBVyx3QkFBdUJ0RCxHQUFJLGlJQUF0QyxDQUFOO0FBQ0g7O0FBQ0QsVUFBSSxTQUFtQyxDQUFDWSxhQUFhLENBQUMyRixRQUFkLENBQXVCd0QsU0FBUyxDQUFDRyxRQUFqQyxDQUF4QyxFQUFvRjtBQUNoRixjQUFNLElBQUk1RyxLQUFKLENBQVcscUJBQW9CdEQsR0FBSSxrQ0FBaUMrSixTQUFTLENBQUNHLFFBQVMsK0RBQTdFLEdBQStJLDhFQUF6SixDQUFOO0FBQ0g7QUFDSjtBQUNKOztBQUNELFNBQVEsR0FBRTdHLElBQUssUUFBTzhHLGtCQUFrQixDQUFDbkssR0FBRCxDQUFNLE1BQUtzQixLQUFNLE1BQUtxQixPQUFPLElBQUksRUFBRyxFQUE1RTtBQUNIOzs7Ozs7Ozs7OztBQ2htQlk7O0FBQ2JyRyw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCwyQkFBQSxHQUE4QkEsMEJBQUEsR0FBNkIsS0FBSyxDQUFoRTs7QUFDQSxNQUFNNE4sbUJBQW1CLEdBQUcsT0FBT0UsSUFBUCxLQUFnQixXQUFoQixJQUErQkEsSUFBSSxDQUFDRixtQkFBcEMsSUFBMkRFLElBQUksQ0FBQ0YsbUJBQUwsQ0FBeUJHLElBQXpCLENBQThCQyxNQUE5QixDQUEzRCxJQUFvRyxVQUFTQyxFQUFULEVBQWE7QUFDekksTUFBSUMsS0FBSyxHQUFHQyxJQUFJLENBQUNDLEdBQUwsRUFBWjtBQUNBLFNBQU9DLFVBQVUsQ0FBQyxZQUFXO0FBQ3pCSixJQUFBQSxFQUFFLENBQUM7QUFDQ0ssTUFBQUEsVUFBVSxFQUFFLEtBRGI7QUFFQ0MsTUFBQUEsYUFBYSxFQUFFLFlBQVc7QUFDdEIsZUFBTy9JLElBQUksQ0FBQ2dKLEdBQUwsQ0FBUyxDQUFULEVBQVksTUFBTUwsSUFBSSxDQUFDQyxHQUFMLEtBQWFGLEtBQW5CLENBQVosQ0FBUDtBQUNIO0FBSkYsS0FBRCxDQUFGO0FBTUgsR0FQZ0IsRUFPZCxDQVBjLENBQWpCO0FBUUgsQ0FWRDs7QUFXQWxPLDJCQUFBLEdBQThCNE4sbUJBQTlCOztBQUNBLE1BQU1DLGtCQUFrQixHQUFHLE9BQU9DLElBQVAsS0FBZ0IsV0FBaEIsSUFBK0JBLElBQUksQ0FBQ0Qsa0JBQXBDLElBQTBEQyxJQUFJLENBQUNELGtCQUFMLENBQXdCRSxJQUF4QixDQUE2QkMsTUFBN0IsQ0FBMUQsSUFBa0csVUFBU1MsRUFBVCxFQUFhO0FBQ3RJLFNBQU9DLFlBQVksQ0FBQ0QsRUFBRCxDQUFuQjtBQUNILENBRkQ7O0FBR0F6TywwQkFBQSxHQUE2QjZOLGtCQUE3Qjs7Ozs7Ozs7Ozs7QUNwQmE7O0FBQ2IvTiw4Q0FBNkM7QUFDekNHLEVBQUFBLEtBQUssRUFBRTtBQURrQyxDQUE3QztBQUdBRCx1QkFBQSxHQUEwQnlLLGVBQTFCOztBQUNBLElBQUlySyxNQUFNLEdBQUdFLG1CQUFPLENBQUMsb0JBQUQsQ0FBcEI7O0FBQ0EsSUFBSXFPLG9CQUFvQixHQUFHck8sbUJBQU8sQ0FBQyx5RkFBRCxDQUFsQzs7QUFDQSxNQUFNc08sdUJBQXVCLEdBQUcsT0FBT0Msb0JBQVAsS0FBZ0MsV0FBaEU7O0FBQ0EsU0FBU3BFLGVBQVQsQ0FBeUI7QUFBRUMsRUFBQUEsVUFBRjtBQUFlQyxFQUFBQTtBQUFmLENBQXpCLEVBQXFEO0FBQ2pELFFBQU1tRSxVQUFVLEdBQUduRSxRQUFRLElBQUksQ0FBQ2lFLHVCQUFoQztBQUNBLFFBQU1HLFNBQVMsR0FBRyxDQUFDLEdBQUczTyxNQUFKLEVBQVk0TyxNQUFaLEVBQWxCO0FBQ0EsUUFBTSxDQUFDQyxPQUFELEVBQVVDLFVBQVYsSUFBd0IsQ0FBQyxHQUFHOU8sTUFBSixFQUFZK08sUUFBWixDQUFxQixLQUFyQixDQUE5QjtBQUNBLFFBQU01RSxNQUFNLEdBQUcsQ0FBQyxHQUFHbkssTUFBSixFQUFZZ1AsV0FBWixDQUF5QkMsRUFBRCxJQUFNO0FBQ3pDLFFBQUlOLFNBQVMsQ0FBQ08sT0FBZCxFQUF1QjtBQUNuQlAsTUFBQUEsU0FBUyxDQUFDTyxPQUFWO0FBQ0FQLE1BQUFBLFNBQVMsQ0FBQ08sT0FBVixHQUFvQnhNLFNBQXBCO0FBQ0g7O0FBQ0QsUUFBSWdNLFVBQVUsSUFBSUcsT0FBbEIsRUFBMkI7O0FBQzNCLFFBQUlJLEVBQUUsSUFBSUEsRUFBRSxDQUFDRSxPQUFiLEVBQXNCO0FBQ2xCUixNQUFBQSxTQUFTLENBQUNPLE9BQVYsR0FBb0JFLE9BQU8sQ0FBQ0gsRUFBRCxFQUFNekUsU0FBRCxJQUFhQSxTQUFTLElBQUlzRSxVQUFVLENBQUN0RSxTQUFELENBQXpDLEVBQ3pCO0FBQ0VGLFFBQUFBO0FBREYsT0FEeUIsQ0FBM0I7QUFJSDtBQUNKLEdBWmMsRUFZWixDQUNDb0UsVUFERCxFQUVDcEUsVUFGRCxFQUdDdUUsT0FIRCxDQVpZLENBQWY7QUFpQkEsR0FBQyxHQUFHN08sTUFBSixFQUFZcVAsU0FBWixDQUFzQixNQUFJO0FBQ3RCLFFBQUksQ0FBQ2IsdUJBQUwsRUFBOEI7QUFDMUIsVUFBSSxDQUFDSyxPQUFMLEVBQWM7QUFDVixjQUFNUyxZQUFZLEdBQUcsQ0FBQyxHQUFHZixvQkFBSixFQUEwQmYsbUJBQTFCLENBQThDLE1BQUlzQixVQUFVLENBQUMsSUFBRCxDQUE1RCxDQUFyQjtBQUVBLGVBQU8sTUFBSSxDQUFDLEdBQUdQLG9CQUFKLEVBQTBCZCxrQkFBMUIsQ0FBNkM2QixZQUE3QyxDQUFYO0FBRUg7QUFDSjtBQUNKLEdBVEQsRUFTRyxDQUNDVCxPQURELENBVEg7QUFZQSxTQUFPLENBQ0gxRSxNQURHLEVBRUgwRSxPQUZHLENBQVA7QUFJSDs7QUFDRCxTQUFTTyxPQUFULENBQWlCRyxPQUFqQixFQUEwQkMsUUFBMUIsRUFBb0NDLE9BQXBDLEVBQTZDO0FBQ3pDLFFBQU07QUFBRXBCLElBQUFBLEVBQUY7QUFBT3FCLElBQUFBLFFBQVA7QUFBa0JDLElBQUFBO0FBQWxCLE1BQWdDQyxjQUFjLENBQUNILE9BQUQsQ0FBcEQ7QUFDQUUsRUFBQUEsUUFBUSxDQUFDM0MsR0FBVCxDQUFhdUMsT0FBYixFQUFzQkMsUUFBdEI7QUFDQUUsRUFBQUEsUUFBUSxDQUFDTixPQUFULENBQWlCRyxPQUFqQjtBQUNBLFNBQU8sU0FBU1osU0FBVCxHQUFxQjtBQUN4QmdCLElBQUFBLFFBQVEsQ0FBQ0UsTUFBVCxDQUFnQk4sT0FBaEI7QUFDQUcsSUFBQUEsUUFBUSxDQUFDZixTQUFULENBQW1CWSxPQUFuQixFQUZ3QixDQUd4Qjs7QUFDQSxRQUFJSSxRQUFRLENBQUNHLElBQVQsS0FBa0IsQ0FBdEIsRUFBeUI7QUFDckJKLE1BQUFBLFFBQVEsQ0FBQ0ssVUFBVDtBQUNBQyxNQUFBQSxTQUFTLENBQUNILE1BQVYsQ0FBaUJ4QixFQUFqQjtBQUNIO0FBQ0osR0FSRDtBQVNIOztBQUNELE1BQU0yQixTQUFTLEdBQUcsSUFBSXBOLEdBQUosRUFBbEI7O0FBQ0EsU0FBU2dOLGNBQVQsQ0FBd0JILE9BQXhCLEVBQWlDO0FBQzdCLFFBQU1wQixFQUFFLEdBQUdvQixPQUFPLENBQUNuRixVQUFSLElBQXNCLEVBQWpDO0FBQ0EsTUFBSTJGLFFBQVEsR0FBR0QsU0FBUyxDQUFDeEosR0FBVixDQUFjNkgsRUFBZCxDQUFmOztBQUNBLE1BQUk0QixRQUFKLEVBQWM7QUFDVixXQUFPQSxRQUFQO0FBQ0g7O0FBQ0QsUUFBTU4sUUFBUSxHQUFHLElBQUkvTSxHQUFKLEVBQWpCO0FBQ0EsUUFBTThNLFFBQVEsR0FBRyxJQUFJakIsb0JBQUosQ0FBMEJ5QixPQUFELElBQVc7QUFDakRBLElBQUFBLE9BQU8sQ0FBQ3ZPLE9BQVIsQ0FBaUJ3TyxLQUFELElBQVM7QUFDckIsWUFBTVgsUUFBUSxHQUFHRyxRQUFRLENBQUNuSixHQUFULENBQWEySixLQUFLLENBQUNwUCxNQUFuQixDQUFqQjtBQUNBLFlBQU15SixTQUFTLEdBQUcyRixLQUFLLENBQUNDLGNBQU4sSUFBd0JELEtBQUssQ0FBQ0UsaUJBQU4sR0FBMEIsQ0FBcEU7O0FBQ0EsVUFBSWIsUUFBUSxJQUFJaEYsU0FBaEIsRUFBMkI7QUFDdkJnRixRQUFBQSxRQUFRLENBQUNoRixTQUFELENBQVI7QUFDSDtBQUNKLEtBTkQ7QUFPSCxHQVJnQixFQVFkaUYsT0FSYyxDQUFqQjtBQVNBTyxFQUFBQSxTQUFTLENBQUNoRCxHQUFWLENBQWNxQixFQUFkLEVBQWtCNEIsUUFBUSxHQUFHO0FBQ3pCNUIsSUFBQUEsRUFEeUI7QUFFekJxQixJQUFBQSxRQUZ5QjtBQUd6QkMsSUFBQUE7QUFIeUIsR0FBN0I7QUFLQSxTQUFPTSxRQUFQO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0EsTUFBTWlCLEtBQUssR0FBRztBQUNaQyxFQUFBQSxNQUFNLEVBQUUsT0FESTtBQUVaQyxFQUFBQSxVQUFVLEVBQUU7QUFGQSxDQUFkOztBQUtBLFNBQVNDLElBQVQsR0FBZ0I7QUFDZCxzQkFDRSwrREFBQyw0REFBRDtBQUFlLFNBQUssRUFBRUgsS0FBdEI7QUFBQSwyQkFDQTtBQUFBLDhCQUNFLCtEQUFDLGtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFLCtEQUFDLHFFQUFEO0FBQUEsK0JBQ0UsK0RBQUMsbURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUtFLCtEQUFDLG9GQUFEO0FBQUEsK0JBQ0UsK0RBQUMsb0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRixlQVFFLCtEQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FSRixlQVNFLCtEQUFDLG1EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FURixlQVVFLCtEQUFDLHNEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FWRixlQVdFLCtEQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FYRixlQVlFLCtEQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FaRjtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBa0JEOztBQUVELGlFQUFlRyxJQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4Q0E7QUFDQTs7O0FBR0EsTUFBTVAsT0FBTyxHQUFHLE1BQU07QUFDbEIsc0JBQ0ksOERBQUMsK0RBQUQ7QUFBQSw0QkFDSTtBQUFBLDhCQUNJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBT0k7QUFBQSw2QkFDSTtBQUFLLFdBQUcsRUFBRztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBYUgsQ0FkRDs7QUFnQkEsaUVBQWVBLE9BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQkE7QUFDQTtBQUVBO0FBWUE7QUFDQTs7O0FBRUEsU0FBU0QsU0FBVCxHQUFxQjtBQUNuQixzQkFDRSw4REFBQywrREFBRDtBQUFBLDJCQUNFLDhEQUFDLGdFQUFEO0FBQUEsOEJBQ0UsOERBQUMsNkRBQUQ7QUFBQSxnQ0FDRSw4REFBQyw2REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLDhEQUFDLDBEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBUUUsOERBQUMsNERBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUkYsZUFTRSw4REFBQywwREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBWUUsOERBQUMsOERBQUQ7QUFBQSxnQ0FDRSw4REFBQyxtREFBRDtBQUFPLGFBQUcsRUFBRW9CLDJEQUFaO0FBQXFCLGFBQUcsRUFBQztBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBcUJEOztBQUVELGlFQUFlcEIsU0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQ0E7Ozs7QUFHQSxNQUFNRyxPQUFPLEdBQUcsTUFBTTtBQUNsQixzQkFDSTtBQUFBLDRCQUNBLDhEQUFDLG1FQUFEO0FBQUEsOEJBQ0k7QUFBQSxnQ0FDSTtBQUFBLGlDQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUlJO0FBQUssbUJBQVMsRUFBQyxVQUFmO0FBQUEsa0NBQ0k7QUFBQSxtQ0FDSTtBQUFBLHFDQUNJO0FBQUssbUJBQUcsRUFBRyx3QkFBWDtBQUFvQyx5QkFBUyxFQUFDO0FBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQU1JO0FBQUEsb0NBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFHSTtBQUFHLHVCQUFTLEVBQUMsVUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFISixlQU1JO0FBQUcsdUJBQVMsRUFBQyxLQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBdUJJO0FBQUEsK0JBQ0k7QUFBSyxhQUFHLEVBQUc7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURBLGVBNEJBLDhEQUFDLDREQUFEO0FBQUEsNkJBQ0k7QUFBSyxpQkFBUyxFQUFFLE1BQWhCO0FBQUEsZ0NBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREEsZUFFSTtBQUFBLGlDQUNJO0FBQUEsb0NBQ0E7QUFBSyx1QkFBUyxFQUFDLFNBQWY7QUFBeUIsaUJBQUcsRUFBRztBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURBLGVBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGSixlQVFJO0FBQUEsaUNBQ0k7QUFBQSxvQ0FDQTtBQUFLLHVCQUFTLEVBQUMsU0FBZjtBQUF5QixpQkFBRyxFQUFHO0FBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREEsZUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJKLGVBY0k7QUFBQSxpQ0FDSTtBQUFBLG9DQUNBO0FBQUssdUJBQVMsRUFBQyxTQUFmO0FBQXlCLGlCQUFHLEVBQUc7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFEQSxlQUVBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEosZUFvQkk7QUFBQSxpQ0FDQTtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyxTQUFmO0FBQXlCLGlCQUFHLEVBQUc7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUVJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNUJBO0FBQUEsa0JBREo7QUE0REgsQ0E3REQ7O0FBK0RBLGlFQUFlQSxPQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkVBO0FBQ0E7QUFzQkE7OztBQUVBLFNBQVNQLElBQVQsR0FBZ0I7QUFDZCxzQkFDRSw4REFBQyw4REFBRDtBQUFBLDRCQUNFLDhEQUFDLHdEQUFEO0FBQUEsOEJBQ0UsOERBQUMseURBQUQ7QUFBQSxnQ0FDRSw4REFBQyx3REFBRDtBQUFBLHNEQUNrQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURsQixlQUVFLDhEQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUtFLDhEQUFDLHVEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUxGLGVBTUUsOERBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTkYsZUFXRSw4REFBQyx1REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQWNFLDhEQUFDLDBEQUFEO0FBQUEsK0JBQ0UsOERBQUMsc0RBQUQ7QUFBTyxhQUFHLEVBQUM7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBbUJFLDhEQUFDLDJEQUFEO0FBQUEsOEJBQ0UsOERBQUMsK0RBQUQ7QUFBQSwrQkFDRSw4REFBQyxvREFBRDtBQUFLLGFBQUcsRUFBQztBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFJRSw4REFBQyxnRUFBRDtBQUFBLCtCQUNFLDhEQUFDLHVEQUFEO0FBQUEsa0NBQ0UsOERBQUMsMkRBQUQ7QUFBQSxtQ0FDRSw4REFBQywwREFBRDtBQUFXLGlCQUFHLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUlFLDhEQUFDLDREQUFEO0FBQUEsbUNBQ0UsOERBQUMsc0RBQUQ7QUFBTyx5QkFBVyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUpGLGVBT0ksOERBQUMsc0ZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQXNDRDs7QUFFRCxpRUFBZUEsSUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEVBO0FBQ0E7OztBQVdBLFNBQVNELE1BQVQsR0FBa0I7QUFDaEIsUUFBTTtBQUFBLE9BQUNtRCxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQjdFLCtDQUFRLENBQUMsS0FBRCxDQUFsQzs7QUFFQSxRQUFNOEUsV0FBVyxHQUFHLE1BQU07QUFDeEJELElBQUFBLFFBQVEsQ0FBQyxDQUFDRCxLQUFGLENBQVI7QUFDRCxHQUZEOztBQUlBLHNCQUNFLDhEQUFDLDREQUFEO0FBQUEsNEJBQ0UsOERBQUMsaUVBQUQ7QUFBQSw2QkFDRSw4REFBQyx3REFBRDtBQUFPLFdBQUcsRUFBQztBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFJRSw4REFBQyxnRUFBRDtBQUFBLDhCQUNFLDhEQUFDLHVEQUFEO0FBQU0sV0FBRyxFQUFDLFlBQVY7QUFBdUIsZUFBTyxFQUFFRTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFHRSw4REFBQyx3REFBRDtBQUFPLGVBQU8sRUFBRUEsV0FBaEI7QUFBNkIsYUFBSyxFQUFFRixLQUFwQztBQUFBLGdDQUNFLDhEQUFDLHVEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUUsOERBQUMsdURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkYsZUFHRSw4REFBQyx1REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFIRixlQUlFLDhEQUFDLHlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBaUJEOztBQUVELGlFQUFlbkQsTUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxNQUFNRSxPQUFPLEdBQUcsTUFBTTtBQUNwQixzQkFDRSw4REFBQyw2REFBRDtBQUFBLDRCQUNFLDhEQUFDLHVEQUFEO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFDLE1BQWY7QUFBQSwrQkFDRSw4REFBQyw0RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFJRTtBQUFLLGlCQUFTLEVBQUMsT0FBZjtBQUFBLGdDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBT0UsOERBQUMsMEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQWVFLDhEQUFDLDBEQUFEO0FBQUEsOEJBQ0UsOERBQUMsc0VBQUQ7QUFBQSxnQ0FDRSw4REFBQyxtREFBRDtBQUFPLGFBQUcsRUFBQyxlQUFYO0FBQTJCLGFBQUcsRUFBQyxVQUEvQjtBQUEwQyxlQUFLLEVBQUUsR0FBakQ7QUFBc0QsZ0JBQU0sRUFBRTtBQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFPRSw4REFBQyxzRUFBRDtBQUFBLGdDQUNFLDhEQUFDLG1EQUFEO0FBQU8sYUFBRyxFQUFDLGVBQVg7QUFBMkIsYUFBRyxFQUFDLFVBQS9CO0FBQTBDLGVBQUssRUFBRSxHQUFqRDtBQUFzRCxnQkFBTSxFQUFFO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQWFFLDhEQUFDLHNFQUFEO0FBQUEsZ0NBQ0UsOERBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUMsZUFBWDtBQUEyQixhQUFHLEVBQUMsVUFBL0I7QUFBMEMsZUFBSyxFQUFFLEdBQWpEO0FBQXNELGdCQUFNLEVBQUU7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFDRCxDQXRDRDs7QUF3Q0EsaUVBQWVBLE9BQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NBO0FBQ0E7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsU0FBU0MsVUFBVCxHQUFzQjtBQUNwQixzQkFDRSwrREFBQyxnRUFBRDtBQUFBLDRCQUNFLCtEQUFDLCtEQUFEO0FBQUEsOEJBQ0UsK0RBQUMsZ0VBQUQ7QUFBQSxnQ0FDRSwrREFBQyw2REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLCtEQUFDLDREQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBS0UsK0RBQUMsZ0VBQUQ7QUFBQSxnQ0FDRSwrREFBQyxnRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTEYsZUFNRSwrREFBQyxpRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQWdCRSwrREFBQywrREFBRDtBQUFBLDhCQUNFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBRUUsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVpRSxxREFBWjtBQUFrQixhQUFHLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBTUUsK0RBQUMsbUVBQUQ7QUFBQSxnQ0FDRSwrREFBQyxtREFBRDtBQUFPLGFBQUcsRUFBRUMseURBQVo7QUFBc0IsYUFBRyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FORixlQVVFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLHNEQUFaO0FBQW9CLGFBQUcsRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVkYsZUFjRSwrREFBQyxtRUFBRDtBQUFBLGdDQUNFLCtEQUFDLG1EQUFEO0FBQU8sYUFBRyxFQUFFQyx3REFBWjtBQUFxQixhQUFHLEVBQUM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRGLGVBa0JFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLHdEQUFaO0FBQXFCLGFBQUcsRUFBQztBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbEJGLGVBc0JFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLG1EQUFaO0FBQWdCLGFBQUcsRUFBQztBQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdEJGLGVBMEJFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLDJEQUFaO0FBQXdCLGFBQUcsRUFBQztBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMUJGLGVBOEJFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLHFEQUFaO0FBQWlCLGFBQUcsRUFBQztBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOUJGLGVBa0NFLCtEQUFDLG1FQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxhQUFHLEVBQUVDLHNEQUFaO0FBQWtCLGFBQUcsRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbENGLGVBc0NFLCtEQUFDLG9FQUFEO0FBQUEsK0JBQ0UsK0RBQUMsNkRBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFERjtBQTZERDs7QUFFRCxpRUFBZXpFLFVBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUZBO0FBQ0E7QUFhQTtBQWNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7OztBQUVBLFNBQVNDLFNBQVQsR0FBcUI7QUFDbkIsc0JBQ0U7QUFBQSw0QkFDRSwrREFBQywrREFBRDtBQUFBLDhCQUNFLCtEQUFDLDhEQUFEO0FBQUEsZ0NBQ0UsK0RBQUMsK0RBQUQ7QUFBQSxpQ0FDRSwrREFBQywyREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFJRSwrREFBQywrREFBRDtBQUFBLGtDQUNFLCtEQUFDLCtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBTUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFlRSwrREFBQyw4REFBRDtBQUFBLGdDQUNFLCtEQUFDLG1FQUFEO0FBQUEsa0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxlQUFHLEVBQUV5RSx5REFBWjtBQUFpQixlQUFHLEVBQUM7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUtFLCtEQUFDLGtFQUFEO0FBQUEsa0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxlQUFHLEVBQUVLLHVEQUFaO0FBQW9CLGVBQUcsRUFBQztBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUxGLGVBU0UsK0RBQUMsa0VBQUQ7QUFBQSxrQ0FDRSwrREFBQyxtREFBRDtBQUFPLGVBQUcsRUFBRUMsc0RBQVo7QUFBa0IsZUFBRyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEYsZUFhRSwrREFBQyxrRUFBRDtBQUFBLGtDQUNFLCtEQUFDLG1EQUFEO0FBQU8sZUFBRyxFQUFFRix3REFBWjtBQUFxQixlQUFHLEVBQUM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFiRixlQWlCRSwrREFBQyxrRUFBRDtBQUFBLGtDQUNFLCtEQUFDLG1EQUFEO0FBQU8sZUFBRyxFQUFFRix3REFBWjtBQUFxQixlQUFHLEVBQUM7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFqQkYsZUFxQkUsK0RBQUMsa0VBQUQ7QUFBQSxrQ0FDRSwrREFBQyxtREFBRDtBQUFPLGVBQUcsRUFBRUQsMERBQVo7QUFBdUIsZUFBRyxFQUFDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsZUFFRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBckJGLGVBeUJFLCtEQUFDLGtFQUFEO0FBQUEsa0NBQ0UsK0RBQUMsbURBQUQ7QUFBTyxlQUFHLEVBQUVFLDBEQUFaO0FBQXVCLGVBQUcsRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXpCRixlQTZCRSwrREFBQyxrRUFBRDtBQUFBLGtDQUNFLCtEQUFDLG1EQUFEO0FBQU8sZUFBRyxFQUFFSSxxREFBWjtBQUFpQixlQUFHLEVBQUM7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFtREUsK0RBQUMsMkRBQUQ7QUFBQSw4QkFDRSwrREFBQywrREFBRDtBQUFBLCtCQUNFLCtEQUFDLG9EQUFEO0FBQUssYUFBRyxFQUFDO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUlFLCtEQUFDLGdFQUFEO0FBQUEsK0JBQ0UsK0RBQUMsdURBQUQ7QUFBQSxrQ0FDRSwrREFBQywyREFBRDtBQUFBLG1DQUNFLCtEQUFDLDBEQUFEO0FBQVcsaUJBQUcsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLGVBSUUsK0RBQUMsNERBQUQ7QUFBQSxtQ0FDRSwrREFBQyxzREFBRDtBQUFPLHlCQUFXLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSkYsZUFPRSwrREFBQyw2REFBRDtBQUFBLG1DQUNFLCtEQUFDLDZEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbkRGO0FBQUEsa0JBREY7QUF3RUQ7O0FBRUQsaUVBQWVoRixTQUFmOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2pIQTtBQUVPLE1BQU1VLFdBQVcsR0FBR3VFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDhuQkFnREgsQ0FBQztBQUFFM0UsRUFBQUE7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0MsTUFoRGxCLENBQWpCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBRU8sTUFBTUosU0FBUyxHQUFHOEUsdUVBQUg7QUFBQTtBQUFBO0FBQUEsaU1BQWY7QUFlQSxNQUFNM0IsUUFBUSxHQUFHMkIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsNEhBQWQ7QUFXQSxNQUFNMUIsU0FBUyxHQUFHMEIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsd0NBQWY7QUFJQSxNQUFNekIsU0FBUyxHQUFHeUIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsa0RBQWY7QUFNQSxNQUFNeEIsTUFBTSxHQUFHd0IsdUVBQUg7QUFBQTtBQUFBO0FBQUEsZ01BQVo7QUFhQSxNQUFNbEIsS0FBSyxHQUFHa0IsdUVBQUg7QUFBQTtBQUFBO0FBQUEsNk9BQVg7QUFpQkEsTUFBTXZCLFNBQVMsR0FBR3VCLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFmO0FBbUJBLE1BQU10QixVQUFVLEdBQUdzQix1RUFBSDtBQUFBO0FBQUE7QUFBQSxrU0FBaEI7QUFxQkEsTUFBTXJCLFFBQVEsR0FBR3FCLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBMQUFkO0FBaUJBLE1BQU1wQixZQUFZLEdBQUdvQix1RUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbEI7QUEyQkEsTUFBTW5CLGFBQWEsR0FBR21CLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGtaQUFuQjtBQTZCQSxNQUFNOUQsSUFBSSxHQUFHOEQsdUVBQUg7QUFBQTtBQUFBO0FBQUEsK0JBQVY7QUFLQSxNQUFNbEUsTUFBTSxHQUFHa0UsMEVBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVo7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMUxQO0FBRU8sTUFBTWxFLE1BQU0sR0FBR2tFLDBFQUFIO0FBQUE7QUFBQTtBQUFBLHVNQUFaOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBRU8sTUFBTTVCLElBQUksR0FBRzRCLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHNQQUFWOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBRU8sTUFBTWhFLE9BQU8sR0FBR2dFLHNFQUFIO0FBQUE7QUFBQTtBQUFBLHFJQUFiOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBRU8sTUFBTXhDLFlBQVksR0FBR3dDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDJSQUFsQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZQO0FBRU8sTUFBTTlFLFNBQVMsR0FBRzhFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBIQUFmO0FBV0EsTUFBTXJFLFVBQVUsR0FBR3FFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLCtFQUFoQjtBQVNBLE1BQU1wRSxPQUFPLEdBQUdvRSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxrSEFBYjtBQVFBLE1BQU1uRSxRQUFRLEdBQUdtRSx1RUFBSDtBQUFBO0FBQUE7QUFBQSwrTEFBZDtBQWVBLE1BQU1oRSxPQUFPLEdBQUdnRSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxxUUFBYjtBQW1CQSxNQUFNL0QsSUFBSSxHQUFHK0QsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMFBBQVY7QUFxQkEsTUFBTTlELElBQUksR0FBRzhELHVFQUFIO0FBQUE7QUFBQTtBQUFBLDZNQUFWO0FBZ0JBLE1BQU1sRSxNQUFNLEdBQUdrRSwwRUFBSDtBQUFBO0FBQUE7QUFBQSw2SUFBWjtBQVlBLE1BQU1qRSxPQUFPLEdBQUdpRSwwRUFBSDtBQUFBO0FBQUE7QUFBQSwwSkFBYjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSFA7QUFFTyxNQUFNOUUsU0FBUyxHQUFHOEUsdUVBQUg7QUFBQTtBQUFBO0FBQUEsb0VBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDRlA7QUFFTyxNQUFNNUUsZ0JBQWdCLEdBQUc0RSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxtUEFNTixDQUFDO0FBQUUzRSxFQUFBQTtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDQyxNQU5mLENBQXRCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGUDtBQUVPLE1BQU1lLFdBQVcsR0FBRzJELHVFQUFIO0FBQUE7QUFBQTtBQUFBLHk2QkE4REgsQ0FBQztBQUFFM0UsRUFBQUE7QUFBRixDQUFELEtBQWVBLEtBQUssQ0FBQ0MsTUE5RGxCLENBQWpCO0FBc0ZBLE1BQU1nQixJQUFJLEdBQUcwRCx1RUFBSDtBQUFBO0FBQUE7QUFBQSx1ZUFlRSxDQUFDO0FBQUUzRSxFQUFBQTtBQUFGLENBQUQsS0FBZUEsS0FBSyxDQUFDRSxVQWZ2QixFQXVCSSxDQUFDO0FBQUVGLEVBQUFBO0FBQUYsQ0FBRCxLQUFlQSxLQUFLLENBQUNDLE1BdkJ6QixDQUFWOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEZQO0FBRU8sTUFBTWtCLE9BQU8sR0FBR3dELHVFQUFIO0FBQUE7QUFBQTtBQUFBLG9JQUFiO0FBYUEsTUFBTXpELGFBQWEsR0FBR3lELHVFQUFIO0FBQUE7QUFBQTtBQUFBLG9OQUFuQjtBQWlCQSxNQUFNdEQsUUFBUSxHQUFHc0QsdUVBQUg7QUFBQTtBQUFBO0FBQUEsc1FBQ2pCO0FBQUc7QUFEYyxFQU9qQjtBQUFHO0FBUGMsRUFRakI7QUFBRztBQVJjLENBQWQ7QUFxQkEsTUFBTXJELFNBQVMsR0FBR3FELHVFQUFIO0FBQUE7QUFBQTtBQUFBLHlIQUFmO0FBV0EsTUFBTXRFLEtBQUssR0FBR3NFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLG1OQUFYO0FBbUJBLE1BQU1sRSxNQUFNLEdBQUdrRSwwRUFBSDtBQUFBO0FBQUE7QUFBQSx1TUFBWjtBQWVBLE1BQU1uRCxJQUFJLEdBQUdtRCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxzUUFBVjtBQXFCQSxNQUFNcEQsTUFBTSxHQUFHb0Qsd0VBQUg7QUFBQTtBQUFBO0FBQUEsd0JBQVo7QUFJQSxNQUFNaEUsT0FBTyxHQUFHZ0Usc0VBQUg7QUFBQTtBQUFBO0FBQUEsMEtBQWI7QUFlQSxNQUFNbEQsSUFBSSxHQUFHa0Qsd0VBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVY7QUFZQSxNQUFNdkQsVUFBVSxHQUFHdUQsdUVBQUg7QUFBQTtBQUFBO0FBQUEsdUlBQWhCO0FBV0EsTUFBTWpELGNBQWMsR0FBR2lELHVFQUFIO0FBQUE7QUFBQTtBQUFBLHVXQUFwQjtBQWtCQSxNQUFNaEQsZUFBZSxHQUFHZ0QsdUVBQUg7QUFBQTtBQUFBO0FBQUEscUZBQXJCO0FBUUEsTUFBTTVDLE1BQU0sR0FBRzRDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGtNQUFaO0FBY0EsTUFBTS9DLEdBQUcsR0FBRytDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLCtCQUFUO0FBS0EsTUFBTXpDLFNBQVMsR0FBR3lDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDhGQUFmO0FBVUEsTUFBTTlDLFVBQVUsR0FBRzhDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDBIQUFoQjtBQVVBLE1BQU03QyxXQUFXLEdBQUc2Qyx1RUFBSDtBQUFBO0FBQUE7QUFBQSxtQkFBakI7QUFJQSxNQUFNM0MsS0FBSyxHQUFHMkMseUVBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVg7QUFvQkEsTUFBTTFDLFlBQVksR0FBRzBDLDBFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFsQjtBQXFCQSxNQUFNeEMsWUFBWSxHQUFHd0MsdUVBQUg7QUFBQTtBQUFBO0FBQUEsUUFBbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL1FQO0FBRU8sTUFBTTlFLFNBQVMsR0FBRzhFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLHFOQUFmO0FBZ0JBLE1BQU0zQixRQUFRLEdBQUcyQix1RUFBSDtBQUFBO0FBQUE7QUFBQSw0SEFBZDtBQVVBLE1BQU0xQixTQUFTLEdBQUcwQix1RUFBSDtBQUFBO0FBQUE7QUFBQSx3Q0FBZjtBQUlBLE1BQU16QixTQUFTLEdBQUd5Qix1RUFBSDtBQUFBO0FBQUE7QUFBQSxrREFBZjtBQU1BLE1BQU14QixNQUFNLEdBQUd3Qix1RUFBSDtBQUFBO0FBQUE7QUFBQSxnTUFBWjtBQWFBLE1BQU1sQixLQUFLLEdBQUdrQix1RUFBSDtBQUFBO0FBQUE7QUFBQSw2T0FBWDtBQWlCQSxNQUFNdkIsU0FBUyxHQUFHdUIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsNFJBQWY7QUFtQkEsTUFBTXRCLFVBQVUsR0FBR3NCLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGtTQUFoQjtBQXFCQSxNQUFNckIsUUFBUSxHQUFHcUIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMExBQWQ7QUFnQkEsTUFBTXBCLFlBQVksR0FBR29CLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGtaQUFsQjtBQTJCQSxNQUFNbkIsYUFBYSxHQUFHbUIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsMmFBQW5CO0FBNkJBLE1BQU05RCxJQUFJLEdBQUc4RCx1RUFBSDtBQUFBO0FBQUE7QUFBQSwrQkFBVjtBQUtBLE1BQU1sRSxNQUFNLEdBQUdrRSwwRUFBSDtBQUFBO0FBQUE7QUFBQSw4TkFBWjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekxQO0FBRU8sTUFBTTlFLFNBQVMsR0FBRzhFLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGtRQUFmO0FBb0JBLE1BQU10RSxLQUFLLEdBQUdzRSx1RUFBSDtBQUFBO0FBQUE7QUFBQSxRQUFYO0FBRUEsTUFBTW5DLElBQUksR0FBR21DLHVFQUFIO0FBQUE7QUFBQTtBQUFBLGdHQUFWO0FBU0EsTUFBTXZDLEtBQUssR0FBR3VDLHVFQUFIO0FBQUE7QUFBQTtBQUFBLDZRQWFOLENBQUM7QUFBRWxDLEVBQUFBO0FBQUYsQ0FBRCxLQUFnQkEsS0FBSyxHQUFHLENBQUgsR0FBTyxPQWJ0QixDQUFYO0FBb0JBLE1BQU1KLElBQUksR0FBR3NDLHFFQUFIO0FBQUE7QUFBQTtBQUFBLCtOQUFWO0FBZ0JBLE1BQU1sRSxNQUFNLEdBQUdrRSwwRUFBSDtBQUFBO0FBQUE7QUFBQSw0U0FrQmI7QUFBRztBQWxCVSxDQUFaO0FBc0JBLE1BQU1yQyxjQUFjLEdBQUdxQyx1RUFBSDtBQUFBO0FBQUE7QUFBQSwyQkFBcEI7QUFJQSxNQUFNcEMsYUFBYSxHQUFHb0MsdUVBQUg7QUFBQTtBQUFBO0FBQUEsOENBQW5COzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9GUDtBQUVBLE1BQU05RSxTQUFTLEdBQUc4RSx1RUFBSDtBQUFBO0FBQUE7QUFBQSw2UkFBZjtBQW9CQSxNQUFNOUIsR0FBRyxHQUFHOEIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsOGpCQUFUO0FBK0NBLE1BQU0vQixNQUFNLEdBQUcrQix1RUFBSDtBQUFBO0FBQUE7QUFBQSw2UUFBWjtBQWNBLE1BQU03QixJQUFJLEdBQUc2Qix1RUFBSDtBQUFBO0FBQUE7QUFBQSxzUEFBVjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25GQTtBQUNBOzs7QUFFZSxTQUFTeEUsSUFBVCxHQUFnQjtBQUM3QixzQkFDRTtBQUFBLDRCQUNFLDhEQUFDLGtEQUFEO0FBQUEsOEJBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUVFO0FBQU0sWUFBSSxFQUFDLGFBQVg7QUFBeUIsZUFBTyxFQUFDO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FGRixlQUdFO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQU9FLDhEQUFDLDhEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFQRjtBQUFBLGtCQURGO0FBV0Q7Ozs7Ozs7Ozs7Ozs7OztBQ2ZELGlFQUFlLENBQUMsa0dBQWtHOzs7Ozs7Ozs7Ozs7Ozs7QUNBbEgsaUVBQWUsQ0FBQyxvR0FBb0c7Ozs7Ozs7Ozs7Ozs7OztBQ0FwSCxpRUFBZSxDQUFDLHlHQUF5Rzs7Ozs7Ozs7Ozs7Ozs7O0FDQXpILGlFQUFlLENBQUMsdUdBQXVHOzs7Ozs7Ozs7Ozs7Ozs7QUNBdkgsaUVBQWUsQ0FBQyx3R0FBd0c7Ozs7Ozs7Ozs7Ozs7OztBQ0F4SCxpRUFBZSxDQUFDLDRHQUE0Rzs7Ozs7Ozs7Ozs7Ozs7O0FDQTVILGlFQUFlLENBQUMsd0dBQXdHOzs7Ozs7Ozs7Ozs7Ozs7QUNBeEgsaUVBQWUsQ0FBQyxvR0FBb0c7Ozs7Ozs7Ozs7Ozs7OztBQ0FwSCxpRUFBZSxDQUFDLG9HQUFvRzs7Ozs7Ozs7Ozs7Ozs7O0FDQXBILGlFQUFlLENBQUMsMEdBQTBHOzs7Ozs7Ozs7Ozs7Ozs7QUNBMUgsaUVBQWUsQ0FBQyx5R0FBeUc7Ozs7Ozs7Ozs7Ozs7OztBQ0F6SCxpRUFBZSxDQUFDLHdHQUF3Rzs7Ozs7Ozs7Ozs7Ozs7O0FDQXhILGlFQUFlLENBQUMsbUdBQW1HOzs7Ozs7Ozs7Ozs7Ozs7QUNBbkgsaUVBQWUsQ0FBQyxxR0FBcUc7Ozs7Ozs7Ozs7Ozs7OztBQ0FySCxpRUFBZSxDQUFDLHVHQUF1Rzs7Ozs7Ozs7Ozs7Ozs7O0FDQXZILGlFQUFlLENBQUMsdUdBQXVHOzs7Ozs7Ozs7Ozs7Ozs7QUNBdkgsaUVBQWUsQ0FBQyxvR0FBb0c7Ozs7Ozs7Ozs7Ozs7OztBQ0FwSCxpRUFBZSxDQUFDLHVHQUF1Rzs7Ozs7Ozs7Ozs7Ozs7O0FDQXZILGlFQUFlLENBQUMsbUdBQW1HOzs7Ozs7Ozs7O0FDQW5ILDJHQUErQzs7Ozs7Ozs7Ozs7O0FDQS9DOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7OztBQ0FBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L2ltYWdlLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NsaWVudC9yZXF1ZXN0LWlkbGUtY2FsbGJhY2suanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvSG9tZS5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9BYm91dFVzLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL0NvbnRhY3R1cy5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9Gb3VuZGVyLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL0hlcm8uanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvTmF2YmFyLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL1NlY3Rpb24uanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvY2F0ZWdvcmllcy5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9sb2NhdGlvbnMuanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0Fib3V0dXMuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9DYXRlZ29yaWVzLnN0eWxlZC5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvQ29tbW9uQ29tcG9uZW50cy9CdXR0b24uc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9Db21tb25Db21wb25lbnRzL0NhcmQuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9Db21tb25Db21wb25lbnRzL0hlYWRpbmcuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9Db21tb25Db21wb25lbnRzL1NlYXJjaEJ1dHRvbi5zdHlsZWQuanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0NvbnRhY3R1cy5zdHlsZWQuanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0NvbnRhaW5lci5zdHlsZWQuanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0ZvdW5kZXJjb250YWluZXIuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9Gb3VuZGVybm90ZS5zdHlsZWQuanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0hlcm8uc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9Mb2NhdGlvbnMuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9OYXZiYXIuc3R5bGVkLmpzIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9TZWN0aW9uLnN0eWxlZC5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcGFnZXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3B1YmxpYy9MVC5zdmciLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3B1YmxpYy9hcnRzLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2JlbmdhbHVydS5zdmciLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3B1YmxpYy9jaGVubmFpLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2NvbW1lcmNlLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2NvbnRhY3R1czEuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvZGVsaGluY3Iuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvZW5nZy5zdmciLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3B1YmxpYy9oZWxwLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2h1bWFuaXRpZXMuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvaHlkZXJhYmFkLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2tvbGthdGEuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvbGF3LnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL2xldmVsLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL21lZGljYWwuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvbXVtYmFpLnN2ZyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljLy4vcHVibGljL3B1bmUuc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9wdWJsaWMvc2NpZW5jZS5zdmciLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy8uL3B1YmxpYy93Zmguc3ZnIiwid2VicGFjazovL3plbi1zdGF0aWMvLi9ub2RlX21vZHVsZXMvbmV4dC9pbWFnZS5qcyIsIndlYnBhY2s6Ly96ZW4tc3RhdGljL2V4dGVybmFsIFwibmV4dC9kaXN0L3NlcnZlci9pbWFnZS1jb25maWcuanNcIiIsIndlYnBhY2s6Ly96ZW4tc3RhdGljL2V4dGVybmFsIFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaGVhZC5qc1wiIiwid2VicGFjazovL3plbi1zdGF0aWMvZXh0ZXJuYWwgXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vemVuLXN0YXRpYy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovL3plbi1zdGF0aWMvZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovL3plbi1zdGF0aWMvZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly96ZW4tc3RhdGljL2V4dGVybmFsIFwic3R5bGVkLWNvbXBvbmVudHNcIiJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwge1xuICAgIHZhbHVlOiB0cnVlXG59KTtcbmV4cG9ydHMuZGVmYXVsdCA9IEltYWdlMTtcbnZhciBfcmVhY3QgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCJyZWFjdFwiKSk7XG52YXIgX2hlYWQgPSBfaW50ZXJvcFJlcXVpcmVEZWZhdWx0KHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL2hlYWRcIikpO1xudmFyIF90b0Jhc2U2NCA9IHJlcXVpcmUoXCIuLi9zaGFyZWQvbGliL3RvLWJhc2UtNjRcIik7XG52YXIgX2ltYWdlQ29uZmlnID0gcmVxdWlyZShcIi4uL3NlcnZlci9pbWFnZS1jb25maWdcIik7XG52YXIgX3VzZUludGVyc2VjdGlvbiA9IHJlcXVpcmUoXCIuL3VzZS1pbnRlcnNlY3Rpb25cIik7XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkob2JqLCBrZXksIHZhbHVlKSB7XG4gICAgaWYgKGtleSBpbiBvYmopIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwga2V5LCB7XG4gICAgICAgICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWVcbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgb2JqW2tleV0gPSB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG9iajtcbn1cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICAgICAgZGVmYXVsdDogb2JqXG4gICAgfTtcbn1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQodGFyZ2V0KSB7XG4gICAgZm9yKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKyl7XG4gICAgICAgIHZhciBzb3VyY2UgPSBhcmd1bWVudHNbaV0gIT0gbnVsbCA/IGFyZ3VtZW50c1tpXSA6IHtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIG93bktleXMgPSBPYmplY3Qua2V5cyhzb3VyY2UpO1xuICAgICAgICBpZiAodHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgb3duS2V5cyA9IG93bktleXMuY29uY2F0KE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKS5maWx0ZXIoZnVuY3Rpb24oc3ltKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Ioc291cmNlLCBzeW0pLmVudW1lcmFibGU7XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgb3duS2V5cy5mb3JFYWNoKGZ1bmN0aW9uKGtleSkge1xuICAgICAgICAgICAgX2RlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBzb3VyY2Vba2V5XSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKHNvdXJjZSwgZXhjbHVkZWQpIHtcbiAgICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7XG4gICAgfTtcbiAgICB2YXIgdGFyZ2V0ID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCk7XG4gICAgdmFyIGtleSwgaTtcbiAgICBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgICAgICB2YXIgc291cmNlU3ltYm9sS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKTtcbiAgICAgICAgZm9yKGkgPSAwOyBpIDwgc291cmNlU3ltYm9sS2V5cy5sZW5ndGg7IGkrKyl7XG4gICAgICAgICAgICBrZXkgPSBzb3VyY2VTeW1ib2xLZXlzW2ldO1xuICAgICAgICAgICAgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTtcbiAgICAgICAgICAgIGlmICghT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHNvdXJjZSwga2V5KSkgY29udGludWU7XG4gICAgICAgICAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0YXJnZXQ7XG59XG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShzb3VyY2UsIGV4Y2x1ZGVkKSB7XG4gICAgaWYgKHNvdXJjZSA9PSBudWxsKSByZXR1cm4ge1xuICAgIH07XG4gICAgdmFyIHRhcmdldCA9IHtcbiAgICB9O1xuICAgIHZhciBzb3VyY2VLZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgICB2YXIga2V5LCBpO1xuICAgIGZvcihpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspe1xuICAgICAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgICAgICBpZiAoZXhjbHVkZWQuaW5kZXhPZihrZXkpID49IDApIGNvbnRpbnVlO1xuICAgICAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xufVxuY29uc3QgbG9hZGVkSW1hZ2VVUkxzID0gbmV3IFNldCgpO1xuaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgZ2xvYmFsLl9fTkVYVF9JTUFHRV9JTVBPUlRFRCA9IHRydWU7XG59XG5jb25zdCBWQUxJRF9MT0FESU5HX1ZBTFVFUyA9IFtcbiAgICAnbGF6eScsXG4gICAgJ2VhZ2VyJyxcbiAgICB1bmRlZmluZWRcbl07XG5jb25zdCBsb2FkZXJzID0gbmV3IE1hcChbXG4gICAgW1xuICAgICAgICAnZGVmYXVsdCcsXG4gICAgICAgIGRlZmF1bHRMb2FkZXJcbiAgICBdLFxuICAgIFtcbiAgICAgICAgJ2ltZ2l4JyxcbiAgICAgICAgaW1naXhMb2FkZXJcbiAgICBdLFxuICAgIFtcbiAgICAgICAgJ2Nsb3VkaW5hcnknLFxuICAgICAgICBjbG91ZGluYXJ5TG9hZGVyXG4gICAgXSxcbiAgICBbXG4gICAgICAgICdha2FtYWknLFxuICAgICAgICBha2FtYWlMb2FkZXJcbiAgICBdLFxuICAgIFtcbiAgICAgICAgJ2N1c3RvbScsXG4gICAgICAgIGN1c3RvbUxvYWRlclxuICAgIF0sIFxuXSk7XG5jb25zdCBWQUxJRF9MQVlPVVRfVkFMVUVTID0gW1xuICAgICdmaWxsJyxcbiAgICAnZml4ZWQnLFxuICAgICdpbnRyaW5zaWMnLFxuICAgICdyZXNwb25zaXZlJyxcbiAgICB1bmRlZmluZWQsIFxuXTtcbmZ1bmN0aW9uIGlzU3RhdGljUmVxdWlyZShzcmMpIHtcbiAgICByZXR1cm4gc3JjLmRlZmF1bHQgIT09IHVuZGVmaW5lZDtcbn1cbmZ1bmN0aW9uIGlzU3RhdGljSW1hZ2VEYXRhKHNyYykge1xuICAgIHJldHVybiBzcmMuc3JjICE9PSB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBpc1N0YXRpY0ltcG9ydChzcmMpIHtcbiAgICByZXR1cm4gdHlwZW9mIHNyYyA9PT0gJ29iamVjdCcgJiYgKGlzU3RhdGljUmVxdWlyZShzcmMpIHx8IGlzU3RhdGljSW1hZ2VEYXRhKHNyYykpO1xufVxuY29uc3QgeyBkZXZpY2VTaXplczogY29uZmlnRGV2aWNlU2l6ZXMgLCBpbWFnZVNpemVzOiBjb25maWdJbWFnZVNpemVzICwgbG9hZGVyOiBjb25maWdMb2FkZXIgLCBwYXRoOiBjb25maWdQYXRoICwgZG9tYWluczogY29uZmlnRG9tYWlucyAsICB9ID0gcHJvY2Vzcy5lbnYuX19ORVhUX0lNQUdFX09QVFMgfHwgX2ltYWdlQ29uZmlnLmltYWdlQ29uZmlnRGVmYXVsdDtcbi8vIHNvcnQgc21hbGxlc3QgdG8gbGFyZ2VzdFxuY29uc3QgYWxsU2l6ZXMgPSBbXG4gICAgLi4uY29uZmlnRGV2aWNlU2l6ZXMsXG4gICAgLi4uY29uZmlnSW1hZ2VTaXplc1xuXTtcbmNvbmZpZ0RldmljZVNpemVzLnNvcnQoKGEsIGIpPT5hIC0gYlxuKTtcbmFsbFNpemVzLnNvcnQoKGEsIGIpPT5hIC0gYlxuKTtcbmZ1bmN0aW9uIGdldFdpZHRocyh3aWR0aCwgbGF5b3V0LCBzaXplcykge1xuICAgIGlmIChzaXplcyAmJiAobGF5b3V0ID09PSAnZmlsbCcgfHwgbGF5b3V0ID09PSAncmVzcG9uc2l2ZScpKSB7XG4gICAgICAgIC8vIEZpbmQgYWxsIHRoZSBcInZ3XCIgcGVyY2VudCBzaXplcyB1c2VkIGluIHRoZSBzaXplcyBwcm9wXG4gICAgICAgIGNvbnN0IHZpZXdwb3J0V2lkdGhSZSA9IC8oXnxcXHMpKDE/XFxkP1xcZCl2dy9nO1xuICAgICAgICBjb25zdCBwZXJjZW50U2l6ZXMgPSBbXTtcbiAgICAgICAgZm9yKGxldCBtYXRjaDsgbWF0Y2ggPSB2aWV3cG9ydFdpZHRoUmUuZXhlYyhzaXplcyk7IG1hdGNoKXtcbiAgICAgICAgICAgIHBlcmNlbnRTaXplcy5wdXNoKHBhcnNlSW50KG1hdGNoWzJdKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBlcmNlbnRTaXplcy5sZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IHNtYWxsZXN0UmF0aW8gPSBNYXRoLm1pbiguLi5wZXJjZW50U2l6ZXMpICogMC4wMTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgd2lkdGhzOiBhbGxTaXplcy5maWx0ZXIoKHMpPT5zID49IGNvbmZpZ0RldmljZVNpemVzWzBdICogc21hbGxlc3RSYXRpb1xuICAgICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgICAga2luZDogJ3cnXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3aWR0aHM6IGFsbFNpemVzLFxuICAgICAgICAgICAga2luZDogJ3cnXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2Ygd2lkdGggIT09ICdudW1iZXInIHx8IGxheW91dCA9PT0gJ2ZpbGwnIHx8IGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3aWR0aHM6IGNvbmZpZ0RldmljZVNpemVzLFxuICAgICAgICAgICAga2luZDogJ3cnXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IHdpZHRocyA9IFtcbiAgICAgICAgLi4ubmV3IFNldCgvLyA+IFRoaXMgbWVhbnMgdGhhdCBtb3N0IE9MRUQgc2NyZWVucyB0aGF0IHNheSB0aGV5IGFyZSAzeCByZXNvbHV0aW9uLFxuICAgICAgICAvLyA+IGFyZSBhY3R1YWxseSAzeCBpbiB0aGUgZ3JlZW4gY29sb3IsIGJ1dCBvbmx5IDEuNXggaW4gdGhlIHJlZCBhbmRcbiAgICAgICAgLy8gPiBibHVlIGNvbG9ycy4gU2hvd2luZyBhIDN4IHJlc29sdXRpb24gaW1hZ2UgaW4gdGhlIGFwcCB2cyBhIDJ4XG4gICAgICAgIC8vID4gcmVzb2x1dGlvbiBpbWFnZSB3aWxsIGJlIHZpc3VhbGx5IHRoZSBzYW1lLCB0aG91Z2ggdGhlIDN4IGltYWdlXG4gICAgICAgIC8vID4gdGFrZXMgc2lnbmlmaWNhbnRseSBtb3JlIGRhdGEuIEV2ZW4gdHJ1ZSAzeCByZXNvbHV0aW9uIHNjcmVlbnMgYXJlXG4gICAgICAgIC8vID4gd2FzdGVmdWwgYXMgdGhlIGh1bWFuIGV5ZSBjYW5ub3Qgc2VlIHRoYXQgbGV2ZWwgb2YgZGV0YWlsIHdpdGhvdXRcbiAgICAgICAgLy8gPiBzb21ldGhpbmcgbGlrZSBhIG1hZ25pZnlpbmcgZ2xhc3MuXG4gICAgICAgIC8vIGh0dHBzOi8vYmxvZy50d2l0dGVyLmNvbS9lbmdpbmVlcmluZy9lbl91cy90b3BpY3MvaW5mcmFzdHJ1Y3R1cmUvMjAxOS9jYXBwaW5nLWltYWdlLWZpZGVsaXR5LW9uLXVsdHJhLWhpZ2gtcmVzb2x1dGlvbi1kZXZpY2VzLmh0bWxcbiAgICAgICAgW1xuICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICB3aWR0aCAqIDIgLyosIHdpZHRoICogMyovIFxuICAgICAgICBdLm1hcCgodyk9PmFsbFNpemVzLmZpbmQoKHApPT5wID49IHdcbiAgICAgICAgICAgICkgfHwgYWxsU2l6ZXNbYWxsU2l6ZXMubGVuZ3RoIC0gMV1cbiAgICAgICAgKSksIFxuICAgIF07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgd2lkdGhzLFxuICAgICAgICBraW5kOiAneCdcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVJbWdBdHRycyh7IHNyYyAsIHVub3B0aW1pemVkICwgbGF5b3V0ICwgd2lkdGggLCBxdWFsaXR5ICwgc2l6ZXMgLCBsb2FkZXIgIH0pIHtcbiAgICBpZiAodW5vcHRpbWl6ZWQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHNyYyxcbiAgICAgICAgICAgIHNyY1NldDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgc2l6ZXM6IHVuZGVmaW5lZFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB7IHdpZHRocyAsIGtpbmQgIH0gPSBnZXRXaWR0aHMod2lkdGgsIGxheW91dCwgc2l6ZXMpO1xuICAgIGNvbnN0IGxhc3QgPSB3aWR0aHMubGVuZ3RoIC0gMTtcbiAgICByZXR1cm4ge1xuICAgICAgICBzaXplczogIXNpemVzICYmIGtpbmQgPT09ICd3JyA/ICcxMDB2dycgOiBzaXplcyxcbiAgICAgICAgc3JjU2V0OiB3aWR0aHMubWFwKCh3LCBpKT0+YCR7bG9hZGVyKHtcbiAgICAgICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICAgICAgcXVhbGl0eSxcbiAgICAgICAgICAgICAgICB3aWR0aDogd1xuICAgICAgICAgICAgfSl9ICR7a2luZCA9PT0gJ3cnID8gdyA6IGkgKyAxfSR7a2luZH1gXG4gICAgICAgICkuam9pbignLCAnKSxcbiAgICAgICAgLy8gSXQncyBpbnRlbmRlZCB0byBrZWVwIGBzcmNgIHRoZSBsYXN0IGF0dHJpYnV0ZSBiZWNhdXNlIFJlYWN0IHVwZGF0ZXNcbiAgICAgICAgLy8gYXR0cmlidXRlcyBpbiBvcmRlci4gSWYgd2Uga2VlcCBgc3JjYCB0aGUgZmlyc3Qgb25lLCBTYWZhcmkgd2lsbFxuICAgICAgICAvLyBpbW1lZGlhdGVseSBzdGFydCB0byBmZXRjaCBgc3JjYCwgYmVmb3JlIGBzaXplc2AgYW5kIGBzcmNTZXRgIGFyZSBldmVuXG4gICAgICAgIC8vIHVwZGF0ZWQgYnkgUmVhY3QuIFRoYXQgY2F1c2VzIG11bHRpcGxlIHVubmVjZXNzYXJ5IHJlcXVlc3RzIGlmIGBzcmNTZXRgXG4gICAgICAgIC8vIGFuZCBgc2l6ZXNgIGFyZSBkZWZpbmVkLlxuICAgICAgICAvLyBUaGlzIGJ1ZyBjYW5ub3QgYmUgcmVwcm9kdWNlZCBpbiBDaHJvbWUgb3IgRmlyZWZveC5cbiAgICAgICAgc3JjOiBsb2FkZXIoe1xuICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgcXVhbGl0eSxcbiAgICAgICAgICAgIHdpZHRoOiB3aWR0aHNbbGFzdF1cbiAgICAgICAgfSlcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2V0SW50KHgpIHtcbiAgICBpZiAodHlwZW9mIHggPT09ICdudW1iZXInKSB7XG4gICAgICAgIHJldHVybiB4O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHggPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiBwYXJzZUludCh4LCAxMCk7XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBkZWZhdWx0SW1hZ2VMb2FkZXIobG9hZGVyUHJvcHMpIHtcbiAgICBjb25zdCBsb2FkID0gbG9hZGVycy5nZXQoY29uZmlnTG9hZGVyKTtcbiAgICBpZiAobG9hZCkge1xuICAgICAgICByZXR1cm4gbG9hZChfb2JqZWN0U3ByZWFkKHtcbiAgICAgICAgICAgIHJvb3Q6IGNvbmZpZ1BhdGhcbiAgICAgICAgfSwgbG9hZGVyUHJvcHMpKTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIFwibG9hZGVyXCIgZm91bmQgaW4gXCJuZXh0LmNvbmZpZy5qc1wiLiBFeHBlY3RlZDogJHtfaW1hZ2VDb25maWcuVkFMSURfTE9BREVSUy5qb2luKCcsICcpfS4gUmVjZWl2ZWQ6ICR7Y29uZmlnTG9hZGVyfWApO1xufVxuLy8gU2VlIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vcS8zOTc3NzgzMy8yNjY1MzUgZm9yIHdoeSB3ZSB1c2UgdGhpcyByZWZcbi8vIGhhbmRsZXIgaW5zdGVhZCBvZiB0aGUgaW1nJ3Mgb25Mb2FkIGF0dHJpYnV0ZS5cbmZ1bmN0aW9uIGhhbmRsZUxvYWRpbmcoaW1nLCBzcmMsIGxheW91dCwgcGxhY2Vob2xkZXIsIG9uTG9hZGluZ0NvbXBsZXRlKSB7XG4gICAgaWYgKCFpbWcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVMb2FkID0gKCk9PntcbiAgICAgICAgaWYgKCFpbWcuc3JjLnN0YXJ0c1dpdGgoJ2RhdGE6JykpIHtcbiAgICAgICAgICAgIGNvbnN0IHAgPSAnZGVjb2RlJyBpbiBpbWcgPyBpbWcuZGVjb2RlKCkgOiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICAgICAgICAgIHAuY2F0Y2goKCk9PntcbiAgICAgICAgICAgIH0pLnRoZW4oKCk9PntcbiAgICAgICAgICAgICAgICBpZiAocGxhY2Vob2xkZXIgPT09ICdibHVyJykge1xuICAgICAgICAgICAgICAgICAgICBpbWcuc3R5bGUuZmlsdGVyID0gJ25vbmUnO1xuICAgICAgICAgICAgICAgICAgICBpbWcuc3R5bGUuYmFja2dyb3VuZFNpemUgPSAnbm9uZSc7XG4gICAgICAgICAgICAgICAgICAgIGltZy5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPSAnbm9uZSc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxvYWRlZEltYWdlVVJMcy5hZGQoc3JjKTtcbiAgICAgICAgICAgICAgICBpZiAob25Mb2FkaW5nQ29tcGxldGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyBuYXR1cmFsV2lkdGggLCBuYXR1cmFsSGVpZ2h0ICB9ID0gaW1nO1xuICAgICAgICAgICAgICAgICAgICAvLyBQYXNzIGJhY2sgcmVhZC1vbmx5IHByaW1pdGl2ZSB2YWx1ZXMgYnV0IG5vdCB0aGVcbiAgICAgICAgICAgICAgICAgICAgLy8gdW5kZXJseWluZyBET00gZWxlbWVudCBiZWNhdXNlIGl0IGNvdWxkIGJlIG1pc3VzZWQuXG4gICAgICAgICAgICAgICAgICAgIG9uTG9hZGluZ0NvbXBsZXRlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hdHVyYWxXaWR0aCxcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hdHVyYWxIZWlnaHRcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZWY7XG4gICAgICAgICAgICAgICAgICAgIGlmICgocmVmID0gaW1nLnBhcmVudEVsZW1lbnQpID09PSBudWxsIHx8IHJlZiA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVmLnBhcmVudEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcmVudCA9IGdldENvbXB1dGVkU3R5bGUoaW1nLnBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobGF5b3V0ID09PSAncmVzcG9uc2l2ZScgJiYgcGFyZW50LmRpc3BsYXkgPT09ICdmbGV4Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBtYXkgbm90IHJlbmRlciBwcm9wZXJseSBhcyBhIGNoaWxkIG9mIGEgZmxleCBjb250YWluZXIuIENvbnNpZGVyIHdyYXBwaW5nIHRoZSBpbWFnZSB3aXRoIGEgZGl2IHRvIGNvbmZpZ3VyZSB0aGUgd2lkdGguYCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ZpbGwnICYmIHBhcmVudC5wb3NpdGlvbiAhPT0gJ3JlbGF0aXZlJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBtYXkgbm90IHJlbmRlciBwcm9wZXJseSB3aXRoIGEgcGFyZW50IHVzaW5nIHBvc2l0aW9uOlwiJHtwYXJlbnQucG9zaXRpb259XCIuIENvbnNpZGVyIGNoYW5naW5nIHRoZSBwYXJlbnQgc3R5bGUgdG8gcG9zaXRpb246XCJyZWxhdGl2ZVwiIHdpdGggYSB3aWR0aCBhbmQgaGVpZ2h0LmApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGlmIChpbWcuY29tcGxldGUpIHtcbiAgICAgICAgLy8gSWYgdGhlIHJlYWwgaW1hZ2UgZmFpbHMgdG8gbG9hZCwgdGhpcyB3aWxsIHN0aWxsIHJlbW92ZSB0aGUgcGxhY2Vob2xkZXIuXG4gICAgICAgIC8vIFRoaXMgaXMgdGhlIGRlc2lyZWQgYmVoYXZpb3IgZm9yIG5vdywgYW5kIHdpbGwgYmUgcmV2aXNpdGVkIHdoZW4gZXJyb3JcbiAgICAgICAgLy8gaGFuZGxpbmcgaXMgd29ya2VkIG9uIGZvciB0aGUgaW1hZ2UgY29tcG9uZW50IGl0c2VsZi5cbiAgICAgICAgaGFuZGxlTG9hZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIGltZy5vbmxvYWQgPSBoYW5kbGVMb2FkO1xuICAgIH1cbn1cbmZ1bmN0aW9uIEltYWdlMShfcGFyYW0pIHtcbiAgICB2YXIgeyBzcmMgLCBzaXplcyAsIHVub3B0aW1pemVkID1mYWxzZSAsIHByaW9yaXR5ID1mYWxzZSAsIGxvYWRpbmcgLCBsYXp5Qm91bmRhcnkgPScyMDBweCcgLCBjbGFzc05hbWUgLCBxdWFsaXR5ICwgd2lkdGggLCBoZWlnaHQgLCBvYmplY3RGaXQgLCBvYmplY3RQb3NpdGlvbiAsIG9uTG9hZGluZ0NvbXBsZXRlICwgbG9hZGVyID1kZWZhdWx0SW1hZ2VMb2FkZXIgLCBwbGFjZWhvbGRlciA9J2VtcHR5JyAsIGJsdXJEYXRhVVJMICB9ID0gX3BhcmFtLCBhbGwgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoX3BhcmFtLCBbXCJzcmNcIiwgXCJzaXplc1wiLCBcInVub3B0aW1pemVkXCIsIFwicHJpb3JpdHlcIiwgXCJsb2FkaW5nXCIsIFwibGF6eUJvdW5kYXJ5XCIsIFwiY2xhc3NOYW1lXCIsIFwicXVhbGl0eVwiLCBcIndpZHRoXCIsIFwiaGVpZ2h0XCIsIFwib2JqZWN0Rml0XCIsIFwib2JqZWN0UG9zaXRpb25cIiwgXCJvbkxvYWRpbmdDb21wbGV0ZVwiLCBcImxvYWRlclwiLCBcInBsYWNlaG9sZGVyXCIsIFwiYmx1ckRhdGFVUkxcIl0pO1xuICAgIGxldCByZXN0ID0gYWxsO1xuICAgIGxldCBsYXlvdXQgPSBzaXplcyA/ICdyZXNwb25zaXZlJyA6ICdpbnRyaW5zaWMnO1xuICAgIGlmICgnbGF5b3V0JyBpbiByZXN0KSB7XG4gICAgICAgIC8vIE92ZXJyaWRlIGRlZmF1bHQgbGF5b3V0IGlmIHRoZSB1c2VyIHNwZWNpZmllZCBvbmU6XG4gICAgICAgIGlmIChyZXN0LmxheW91dCkgbGF5b3V0ID0gcmVzdC5sYXlvdXQ7XG4gICAgICAgIC8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbiAgICAgICAgZGVsZXRlIHJlc3RbJ2xheW91dCddO1xuICAgIH1cbiAgICBsZXQgc3RhdGljU3JjID0gJyc7XG4gICAgaWYgKGlzU3RhdGljSW1wb3J0KHNyYykpIHtcbiAgICAgICAgY29uc3Qgc3RhdGljSW1hZ2VEYXRhID0gaXNTdGF0aWNSZXF1aXJlKHNyYykgPyBzcmMuZGVmYXVsdCA6IHNyYztcbiAgICAgICAgaWYgKCFzdGF0aWNJbWFnZURhdGEuc3JjKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEFuIG9iamVjdCBzaG91bGQgb25seSBiZSBwYXNzZWQgdG8gdGhlIGltYWdlIGNvbXBvbmVudCBzcmMgcGFyYW1ldGVyIGlmIGl0IGNvbWVzIGZyb20gYSBzdGF0aWMgaW1hZ2UgaW1wb3J0LiBJdCBtdXN0IGluY2x1ZGUgc3JjLiBSZWNlaXZlZCAke0pTT04uc3RyaW5naWZ5KHN0YXRpY0ltYWdlRGF0YSl9YCk7XG4gICAgICAgIH1cbiAgICAgICAgYmx1ckRhdGFVUkwgPSBibHVyRGF0YVVSTCB8fCBzdGF0aWNJbWFnZURhdGEuYmx1ckRhdGFVUkw7XG4gICAgICAgIHN0YXRpY1NyYyA9IHN0YXRpY0ltYWdlRGF0YS5zcmM7XG4gICAgICAgIGlmICghbGF5b3V0IHx8IGxheW91dCAhPT0gJ2ZpbGwnKSB7XG4gICAgICAgICAgICBoZWlnaHQgPSBoZWlnaHQgfHwgc3RhdGljSW1hZ2VEYXRhLmhlaWdodDtcbiAgICAgICAgICAgIHdpZHRoID0gd2lkdGggfHwgc3RhdGljSW1hZ2VEYXRhLndpZHRoO1xuICAgICAgICAgICAgaWYgKCFzdGF0aWNJbWFnZURhdGEuaGVpZ2h0IHx8ICFzdGF0aWNJbWFnZURhdGEud2lkdGgpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEFuIG9iamVjdCBzaG91bGQgb25seSBiZSBwYXNzZWQgdG8gdGhlIGltYWdlIGNvbXBvbmVudCBzcmMgcGFyYW1ldGVyIGlmIGl0IGNvbWVzIGZyb20gYSBzdGF0aWMgaW1hZ2UgaW1wb3J0LiBJdCBtdXN0IGluY2x1ZGUgaGVpZ2h0IGFuZCB3aWR0aC4gUmVjZWl2ZWQgJHtKU09OLnN0cmluZ2lmeShzdGF0aWNJbWFnZURhdGEpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHNyYyA9IHR5cGVvZiBzcmMgPT09ICdzdHJpbmcnID8gc3JjIDogc3RhdGljU3JjO1xuICAgIGNvbnN0IHdpZHRoSW50ID0gZ2V0SW50KHdpZHRoKTtcbiAgICBjb25zdCBoZWlnaHRJbnQgPSBnZXRJbnQoaGVpZ2h0KTtcbiAgICBjb25zdCBxdWFsaXR5SW50ID0gZ2V0SW50KHF1YWxpdHkpO1xuICAgIGxldCBpc0xhenkgPSAhcHJpb3JpdHkgJiYgKGxvYWRpbmcgPT09ICdsYXp5JyB8fCB0eXBlb2YgbG9hZGluZyA9PT0gJ3VuZGVmaW5lZCcpO1xuICAgIGlmIChzcmMuc3RhcnRzV2l0aCgnZGF0YTonKSB8fCBzcmMuc3RhcnRzV2l0aCgnYmxvYjonKSkge1xuICAgICAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9IVFRQL0Jhc2ljc19vZl9IVFRQL0RhdGFfVVJJc1xuICAgICAgICB1bm9wdGltaXplZCA9IHRydWU7XG4gICAgICAgIGlzTGF6eSA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgbG9hZGVkSW1hZ2VVUkxzLmhhcyhzcmMpKSB7XG4gICAgICAgIGlzTGF6eSA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICBpZiAoIXNyYykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSBpcyBtaXNzaW5nIHJlcXVpcmVkIFwic3JjXCIgcHJvcGVydHkuIE1ha2Ugc3VyZSB5b3UgcGFzcyBcInNyY1wiIGluIHByb3BzIHRvIHRoZSBcXGBuZXh0L2ltYWdlXFxgIGNvbXBvbmVudC4gUmVjZWl2ZWQ6ICR7SlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgIHdpZHRoLFxuICAgICAgICAgICAgICAgIGhlaWdodCxcbiAgICAgICAgICAgICAgICBxdWFsaXR5XG4gICAgICAgICAgICB9KX1gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIVZBTElEX0xBWU9VVF9WQUxVRVMuaW5jbHVkZXMobGF5b3V0KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwibGF5b3V0XCIgcHJvcGVydHkuIFByb3ZpZGVkIFwiJHtsYXlvdXR9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xBWU9VVF9WQUxVRVMubWFwKFN0cmluZykuam9pbignLCcpfS5gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHdpZHRoSW50ICE9PSAndW5kZWZpbmVkJyAmJiBpc05hTih3aWR0aEludCkgfHwgdHlwZW9mIGhlaWdodEludCAhPT0gJ3VuZGVmaW5lZCcgJiYgaXNOYU4oaGVpZ2h0SW50KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwid2lkdGhcIiBvciBcImhlaWdodFwiIHByb3BlcnR5LiBUaGVzZSBzaG91bGQgYmUgbnVtZXJpYyB2YWx1ZXMuYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGxheW91dCA9PT0gJ2ZpbGwnICYmICh3aWR0aCB8fCBoZWlnaHQpKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgYW5kIFwibGF5b3V0PSdmaWxsJ1wiIGhhcyB1bnVzZWQgcHJvcGVydGllcyBhc3NpZ25lZC4gUGxlYXNlIHJlbW92ZSBcIndpZHRoXCIgYW5kIFwiaGVpZ2h0XCIuYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFWQUxJRF9MT0FESU5HX1ZBTFVFUy5pbmNsdWRlcyhsb2FkaW5nKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwibG9hZGluZ1wiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bG9hZGluZ31cIiBzaG91bGQgYmUgb25lIG9mICR7VkFMSURfTE9BRElOR19WQUxVRVMubWFwKFN0cmluZykuam9pbignLCcpfS5gKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJpb3JpdHkgJiYgbG9hZGluZyA9PT0gJ2xhenknKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGJvdGggXCJwcmlvcml0eVwiIGFuZCBcImxvYWRpbmc9J2xhenknXCIgcHJvcGVydGllcy4gT25seSBvbmUgc2hvdWxkIGJlIHVzZWQuYCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBsYWNlaG9sZGVyID09PSAnYmx1cicpIHtcbiAgICAgICAgICAgIGlmIChsYXlvdXQgIT09ICdmaWxsJyAmJiAod2lkdGhJbnQgfHwgMCkgKiAoaGVpZ2h0SW50IHx8IDApIDwgMTYwMCkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBpcyBzbWFsbGVyIHRoYW4gNDB4NDAuIENvbnNpZGVyIHJlbW92aW5nIHRoZSBcInBsYWNlaG9sZGVyPSdibHVyJ1wiIHByb3BlcnR5IHRvIGltcHJvdmUgcGVyZm9ybWFuY2UuYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWJsdXJEYXRhVVJMKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgVkFMSURfQkxVUl9FWFQgPSBbXG4gICAgICAgICAgICAgICAgICAgICdqcGVnJyxcbiAgICAgICAgICAgICAgICAgICAgJ3BuZycsXG4gICAgICAgICAgICAgICAgICAgICd3ZWJwJ1xuICAgICAgICAgICAgICAgIF0gLy8gc2hvdWxkIG1hdGNoIG5leHQtaW1hZ2UtbG9hZGVyXG4gICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgXCJwbGFjZWhvbGRlcj0nYmx1cidcIiBwcm9wZXJ0eSBidXQgaXMgbWlzc2luZyB0aGUgXCJibHVyRGF0YVVSTFwiIHByb3BlcnR5LlxuICAgICAgICAgIFBvc3NpYmxlIHNvbHV0aW9uczpcbiAgICAgICAgICAgIC0gQWRkIGEgXCJibHVyRGF0YVVSTFwiIHByb3BlcnR5LCB0aGUgY29udGVudHMgc2hvdWxkIGJlIGEgc21hbGwgRGF0YSBVUkwgdG8gcmVwcmVzZW50IHRoZSBpbWFnZVxuICAgICAgICAgICAgLSBDaGFuZ2UgdGhlIFwic3JjXCIgcHJvcGVydHkgdG8gYSBzdGF0aWMgaW1wb3J0IHdpdGggb25lIG9mIHRoZSBzdXBwb3J0ZWQgZmlsZSB0eXBlczogJHtWQUxJRF9CTFVSX0VYVC5qb2luKCcsJyl9XG4gICAgICAgICAgICAtIFJlbW92ZSB0aGUgXCJwbGFjZWhvbGRlclwiIHByb3BlcnR5LCBlZmZlY3RpdmVseSBubyBibHVyIGVmZmVjdFxuICAgICAgICAgIFJlYWQgbW9yZTogaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvcGxhY2Vob2xkZXItYmx1ci1kYXRhLXVybGApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmICgncmVmJyBpbiByZXN0KSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaXMgdXNpbmcgdW5zdXBwb3J0ZWQgXCJyZWZcIiBwcm9wZXJ0eS4gQ29uc2lkZXIgdXNpbmcgdGhlIFwib25Mb2FkaW5nQ29tcGxldGVcIiBwcm9wZXJ0eSBpbnN0ZWFkLmApO1xuICAgICAgICB9XG4gICAgICAgIGlmICgnc3R5bGUnIGluIHJlc3QpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBpcyB1c2luZyB1bnN1cHBvcnRlZCBcInN0eWxlXCIgcHJvcGVydHkuIFBsZWFzZSB1c2UgdGhlIFwiY2xhc3NOYW1lXCIgcHJvcGVydHkgaW5zdGVhZC5gKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByYW5kID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwMCkgKyAxMDA7XG4gICAgICAgIGlmICghdW5vcHRpbWl6ZWQgJiYgIWxvYWRlcih7XG4gICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICB3aWR0aDogcmFuZCxcbiAgICAgICAgICAgIHF1YWxpdHk6IDc1XG4gICAgICAgIH0pLmluY2x1ZGVzKHJhbmQudG9TdHJpbmcoKSkpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgYSBcImxvYWRlclwiIHByb3BlcnR5IHRoYXQgZG9lcyBub3QgaW1wbGVtZW50IHdpZHRoLiBQbGVhc2UgaW1wbGVtZW50IGl0IG9yIHVzZSB0aGUgXCJ1bm9wdGltaXplZFwiIHByb3BlcnR5IGluc3RlYWQuYCArIGBcXG5SZWFkIG1vcmU6IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL25leHQtaW1hZ2UtbWlzc2luZy1sb2FkZXItd2lkdGhgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBbc2V0UmVmLCBpc0ludGVyc2VjdGVkXSA9ICgwLCBfdXNlSW50ZXJzZWN0aW9uKS51c2VJbnRlcnNlY3Rpb24oe1xuICAgICAgICByb290TWFyZ2luOiBsYXp5Qm91bmRhcnksXG4gICAgICAgIGRpc2FibGVkOiAhaXNMYXp5XG4gICAgfSk7XG4gICAgY29uc3QgaXNWaXNpYmxlID0gIWlzTGF6eSB8fCBpc0ludGVyc2VjdGVkO1xuICAgIGxldCB3cmFwcGVyU3R5bGU7XG4gICAgbGV0IHNpemVyU3R5bGU7XG4gICAgbGV0IHNpemVyU3ZnO1xuICAgIGxldCBpbWdTdHlsZSA9IHtcbiAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICAgIHRvcDogMCxcbiAgICAgICAgbGVmdDogMCxcbiAgICAgICAgYm90dG9tOiAwLFxuICAgICAgICByaWdodDogMCxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIHBhZGRpbmc6IDAsXG4gICAgICAgIGJvcmRlcjogJ25vbmUnLFxuICAgICAgICBtYXJnaW46ICdhdXRvJyxcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgd2lkdGg6IDAsXG4gICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgbWluV2lkdGg6ICcxMDAlJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgbWluSGVpZ2h0OiAnMTAwJScsXG4gICAgICAgIG1heEhlaWdodDogJzEwMCUnLFxuICAgICAgICBvYmplY3RGaXQsXG4gICAgICAgIG9iamVjdFBvc2l0aW9uXG4gICAgfTtcbiAgICBjb25zdCBibHVyU3R5bGUgPSBwbGFjZWhvbGRlciA9PT0gJ2JsdXInID8ge1xuICAgICAgICBmaWx0ZXI6ICdibHVyKDIwcHgpJyxcbiAgICAgICAgYmFja2dyb3VuZFNpemU6IG9iamVjdEZpdCB8fCAnY292ZXInLFxuICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoXCIke2JsdXJEYXRhVVJMfVwiKWAsXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogb2JqZWN0UG9zaXRpb24gfHwgJzAlIDAlJ1xuICAgIH0gOiB7XG4gICAgfTtcbiAgICBpZiAobGF5b3V0ID09PSAnZmlsbCcpIHtcbiAgICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgbGF5b3V0PVwiZmlsbFwiIC8+XG4gICAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgICAgICAgIHRvcDogMCxcbiAgICAgICAgICAgIGxlZnQ6IDAsXG4gICAgICAgICAgICBib3R0b206IDAsXG4gICAgICAgICAgICByaWdodDogMCxcbiAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICAgICAgbWFyZ2luOiAwXG4gICAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0eXBlb2Ygd2lkdGhJbnQgIT09ICd1bmRlZmluZWQnICYmIHR5cGVvZiBoZWlnaHRJbnQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgLz5cbiAgICAgICAgY29uc3QgcXVvdGllbnQgPSBoZWlnaHRJbnQgLyB3aWR0aEludDtcbiAgICAgICAgY29uc3QgcGFkZGluZ1RvcCA9IGlzTmFOKHF1b3RpZW50KSA/ICcxMDAlJyA6IGAke3F1b3RpZW50ICogMTAwfSVgO1xuICAgICAgICBpZiAobGF5b3V0ID09PSAncmVzcG9uc2l2ZScpIHtcbiAgICAgICAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwicmVzcG9uc2l2ZVwiIC8+XG4gICAgICAgICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgICAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgc2l6ZXJTdHlsZSA9IHtcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICAgICAgICAgIHBhZGRpbmdUb3BcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnaW50cmluc2ljJykge1xuICAgICAgICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJpbnRyaW5zaWNcIiAvPlxuICAgICAgICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICAgICAgICAgIG1hcmdpbjogMFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHNpemVyU3R5bGUgPSB7XG4gICAgICAgICAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzEwMCUnXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgc2l6ZXJTdmcgPSBgPHN2ZyB3aWR0aD1cIiR7d2lkdGhJbnR9XCIgaGVpZ2h0PVwiJHtoZWlnaHRJbnR9XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZlcnNpb249XCIxLjFcIi8+YDtcbiAgICAgICAgfSBlbHNlIGlmIChsYXlvdXQgPT09ICdmaXhlZCcpIHtcbiAgICAgICAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiZml4ZWRcIiAvPlxuICAgICAgICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiBoZWlnaHRJbnRcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiAvPlxuICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIG11c3QgdXNlIFwid2lkdGhcIiBhbmQgXCJoZWlnaHRcIiBwcm9wZXJ0aWVzIG9yIFwibGF5b3V0PSdmaWxsJ1wiIHByb3BlcnR5LmApO1xuICAgICAgICB9XG4gICAgfVxuICAgIGxldCBpbWdBdHRyaWJ1dGVzID0ge1xuICAgICAgICBzcmM6ICdkYXRhOmltYWdlL2dpZjtiYXNlNjQsUjBsR09EbGhBUUFCQUlBQUFBQUFBUC8vL3lINUJBRUFBQUFBTEFBQUFBQUJBQUVBQUFJQlJBQTcnLFxuICAgICAgICBzcmNTZXQ6IHVuZGVmaW5lZCxcbiAgICAgICAgc2l6ZXM6IHVuZGVmaW5lZFxuICAgIH07XG4gICAgaWYgKGlzVmlzaWJsZSkge1xuICAgICAgICBpbWdBdHRyaWJ1dGVzID0gZ2VuZXJhdGVJbWdBdHRycyh7XG4gICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICB1bm9wdGltaXplZCxcbiAgICAgICAgICAgIGxheW91dCxcbiAgICAgICAgICAgIHdpZHRoOiB3aWR0aEludCxcbiAgICAgICAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICAgICAgICBzaXplcyxcbiAgICAgICAgICAgIGxvYWRlclxuICAgICAgICB9KTtcbiAgICB9XG4gICAgbGV0IHNyY1N0cmluZyA9IHNyYztcbiAgICByZXR1cm4oLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHtcbiAgICAgICAgc3R5bGU6IHdyYXBwZXJTdHlsZVxuICAgIH0sIHNpemVyU3R5bGUgPyAvKiNfX1BVUkVfXyovIF9yZWFjdC5kZWZhdWx0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgICAgICBzdHlsZTogc2l6ZXJTdHlsZVxuICAgIH0sIHNpemVyU3ZnID8gLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiaW1nXCIsIHtcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgbWFyZ2luOiAwLFxuICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICBwYWRkaW5nOiAwXG4gICAgICAgIH0sXG4gICAgICAgIGFsdDogXCJcIixcbiAgICAgICAgXCJhcmlhLWhpZGRlblwiOiB0cnVlLFxuICAgICAgICBzcmM6IGBkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LCR7KDAsIF90b0Jhc2U2NCkudG9CYXNlNjQoc2l6ZXJTdmcpfWBcbiAgICB9KSA6IG51bGwpIDogbnVsbCwgLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KFwiaW1nXCIsIE9iamVjdC5hc3NpZ24oe1xuICAgIH0sIHJlc3QsIGltZ0F0dHJpYnV0ZXMsIHtcbiAgICAgICAgZGVjb2Rpbmc6IFwiYXN5bmNcIixcbiAgICAgICAgXCJkYXRhLW5pbWdcIjogbGF5b3V0LFxuICAgICAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSxcbiAgICAgICAgcmVmOiAoaW1nKT0+e1xuICAgICAgICAgICAgc2V0UmVmKGltZyk7XG4gICAgICAgICAgICBoYW5kbGVMb2FkaW5nKGltZywgc3JjU3RyaW5nLCBsYXlvdXQsIHBsYWNlaG9sZGVyLCBvbkxvYWRpbmdDb21wbGV0ZSk7XG4gICAgICAgIH0sXG4gICAgICAgIHN0eWxlOiBfb2JqZWN0U3ByZWFkKHtcbiAgICAgICAgfSwgaW1nU3R5bGUsIGJsdXJTdHlsZSlcbiAgICB9KSksIC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcIm5vc2NyaXB0XCIsIG51bGwsIC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImltZ1wiLCBPYmplY3QuYXNzaWduKHtcbiAgICB9LCByZXN0LCBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgICAgc3JjLFxuICAgICAgICB1bm9wdGltaXplZCxcbiAgICAgICAgbGF5b3V0LFxuICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICAgIHNpemVzLFxuICAgICAgICBsb2FkZXJcbiAgICB9KSwge1xuICAgICAgICBkZWNvZGluZzogXCJhc3luY1wiLFxuICAgICAgICBcImRhdGEtbmltZ1wiOiBsYXlvdXQsXG4gICAgICAgIHN0eWxlOiBpbWdTdHlsZSxcbiAgICAgICAgY2xhc3NOYW1lOiBjbGFzc05hbWUsXG4gICAgICAgIGxvYWRpbmc6IGxvYWRpbmcgfHwgJ2xhenknXG4gICAgfSkpKSwgcHJpb3JpdHkgPyAvLyBOb3RlIGhvdyB3ZSBvbWl0IHRoZSBgaHJlZmAgYXR0cmlidXRlLCBhcyBpdCB3b3VsZCBvbmx5IGJlIHJlbGV2YW50XG4gICAgLy8gZm9yIGJyb3dzZXJzIHRoYXQgZG8gbm90IHN1cHBvcnQgYGltYWdlc3Jjc2V0YCwgYW5kIGluIHRob3NlIGNhc2VzXG4gICAgLy8gaXQgd291bGQgbGlrZWx5IGNhdXNlIHRoZSBpbmNvcnJlY3QgaW1hZ2UgdG8gYmUgcHJlbG9hZGVkLlxuICAgIC8vXG4gICAgLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvc2VtYW50aWNzLmh0bWwjYXR0ci1saW5rLWltYWdlc3Jjc2V0XG4gICAgLyojX19QVVJFX18qLyBfcmVhY3QuZGVmYXVsdC5jcmVhdGVFbGVtZW50KF9oZWFkLmRlZmF1bHQsIG51bGwsIC8qI19fUFVSRV9fKi8gX3JlYWN0LmRlZmF1bHQuY3JlYXRlRWxlbWVudChcImxpbmtcIiwge1xuICAgICAgICBrZXk6ICdfX25pbWctJyArIGltZ0F0dHJpYnV0ZXMuc3JjICsgaW1nQXR0cmlidXRlcy5zcmNTZXQgKyBpbWdBdHRyaWJ1dGVzLnNpemVzLFxuICAgICAgICByZWw6IFwicHJlbG9hZFwiLFxuICAgICAgICBhczogXCJpbWFnZVwiLFxuICAgICAgICBocmVmOiBpbWdBdHRyaWJ1dGVzLnNyY1NldCA/IHVuZGVmaW5lZCA6IGltZ0F0dHJpYnV0ZXMuc3JjLFxuICAgICAgICAvLyBAdHMtaWdub3JlOiBpbWFnZXNyY3NldCBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZS5cbiAgICAgICAgaW1hZ2VzcmNzZXQ6IGltZ0F0dHJpYnV0ZXMuc3JjU2V0LFxuICAgICAgICAvLyBAdHMtaWdub3JlOiBpbWFnZXNpemVzIGlzIG5vdCB5ZXQgaW4gdGhlIGxpbmsgZWxlbWVudCB0eXBlLlxuICAgICAgICBpbWFnZXNpemVzOiBpbWdBdHRyaWJ1dGVzLnNpemVzXG4gICAgfSkpIDogbnVsbCkpO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplU3JjKHNyYykge1xuICAgIHJldHVybiBzcmNbMF0gPT09ICcvJyA/IHNyYy5zbGljZSgxKSA6IHNyYztcbn1cbmZ1bmN0aW9uIGltZ2l4TG9hZGVyKHsgcm9vdCAsIHNyYyAsIHdpZHRoICwgcXVhbGl0eSAgfSkge1xuICAgIC8vIERlbW86IGh0dHBzOi8vc3RhdGljLmltZ2l4Lm5ldC9kYWlzeS5wbmc/YXV0bz1mb3JtYXQmZml0PW1heCZ3PTMwMFxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwoYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfWApO1xuICAgIGNvbnN0IHBhcmFtcyA9IHVybC5zZWFyY2hQYXJhbXM7XG4gICAgcGFyYW1zLnNldCgnYXV0bycsIHBhcmFtcy5nZXQoJ2F1dG8nKSB8fCAnZm9ybWF0Jyk7XG4gICAgcGFyYW1zLnNldCgnZml0JywgcGFyYW1zLmdldCgnZml0JykgfHwgJ21heCcpO1xuICAgIHBhcmFtcy5zZXQoJ3cnLCBwYXJhbXMuZ2V0KCd3JykgfHwgd2lkdGgudG9TdHJpbmcoKSk7XG4gICAgaWYgKHF1YWxpdHkpIHtcbiAgICAgICAgcGFyYW1zLnNldCgncScsIHF1YWxpdHkudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIHJldHVybiB1cmwuaHJlZjtcbn1cbmZ1bmN0aW9uIGFrYW1haUxvYWRlcih7IHJvb3QgLCBzcmMgLCB3aWR0aCAgfSkge1xuICAgIHJldHVybiBgJHtyb290fSR7bm9ybWFsaXplU3JjKHNyYyl9P2ltd2lkdGg9JHt3aWR0aH1gO1xufVxuZnVuY3Rpb24gY2xvdWRpbmFyeUxvYWRlcih7IHJvb3QgLCBzcmMgLCB3aWR0aCAsIHF1YWxpdHkgIH0pIHtcbiAgICAvLyBEZW1vOiBodHRwczovL3Jlcy5jbG91ZGluYXJ5LmNvbS9kZW1vL2ltYWdlL3VwbG9hZC93XzMwMCxjX2xpbWl0LHFfYXV0by90dXJ0bGVzLmpwZ1xuICAgIGNvbnN0IHBhcmFtcyA9IFtcbiAgICAgICAgJ2ZfYXV0bycsXG4gICAgICAgICdjX2xpbWl0JyxcbiAgICAgICAgJ3dfJyArIHdpZHRoLFxuICAgICAgICAncV8nICsgKHF1YWxpdHkgfHwgJ2F1dG8nKVxuICAgIF07XG4gICAgbGV0IHBhcmFtc1N0cmluZyA9IHBhcmFtcy5qb2luKCcsJykgKyAnLyc7XG4gICAgcmV0dXJuIGAke3Jvb3R9JHtwYXJhbXNTdHJpbmd9JHtub3JtYWxpemVTcmMoc3JjKX1gO1xufVxuZnVuY3Rpb24gY3VzdG9tTG9hZGVyKHsgc3JjICB9KSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGlzIG1pc3NpbmcgXCJsb2FkZXJcIiBwcm9wLmAgKyBgXFxuUmVhZCBtb3JlOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uZXh0LWltYWdlLW1pc3NpbmctbG9hZGVyYCk7XG59XG5mdW5jdGlvbiBkZWZhdWx0TG9hZGVyKHsgcm9vdCAsIHNyYyAsIHdpZHRoICwgcXVhbGl0eSAgfSkge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IG1pc3NpbmdWYWx1ZXMgPSBbXTtcbiAgICAgICAgLy8gdGhlc2Ugc2hvdWxkIGFsd2F5cyBiZSBwcm92aWRlZCBidXQgbWFrZSBzdXJlIHRoZXkgYXJlXG4gICAgICAgIGlmICghc3JjKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3NyYycpO1xuICAgICAgICBpZiAoIXdpZHRoKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3dpZHRoJyk7XG4gICAgICAgIGlmIChtaXNzaW5nVmFsdWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTmV4dCBJbWFnZSBPcHRpbWl6YXRpb24gcmVxdWlyZXMgJHttaXNzaW5nVmFsdWVzLmpvaW4oJywgJyl9IHRvIGJlIHByb3ZpZGVkLiBNYWtlIHN1cmUgeW91IHBhc3MgdGhlbSBhcyBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBzcmMsXG4gICAgICAgICAgICAgICAgd2lkdGgsXG4gICAgICAgICAgICAgICAgcXVhbGl0eVxuICAgICAgICAgICAgfSl9YCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNyYy5zdGFydHNXaXRoKCcvLycpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBwYXJzZSBzcmMgXCIke3NyY31cIiBvbiBcXGBuZXh0L2ltYWdlXFxgLCBwcm90b2NvbC1yZWxhdGl2ZSBVUkwgKC8vKSBtdXN0IGJlIGNoYW5nZWQgdG8gYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWApO1xuICAgICAgICB9XG4gICAgICAgIGlmICghc3JjLnN0YXJ0c1dpdGgoJy8nKSAmJiBjb25maWdEb21haW5zKSB7XG4gICAgICAgICAgICBsZXQgcGFyc2VkU3JjO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBwYXJzZWRTcmMgPSBuZXcgVVJMKHNyYyk7XG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgaWYgdXNpbmcgcmVsYXRpdmUgaW1hZ2UgaXQgbXVzdCBzdGFydCB3aXRoIGEgbGVhZGluZyBzbGFzaCBcIi9cIiBvciBiZSBhbiBhYnNvbHV0ZSBVUkwgKGh0dHA6Ly8gb3IgaHR0cHM6Ly8pYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICd0ZXN0JyAmJiAhY29uZmlnRG9tYWlucy5pbmNsdWRlcyhwYXJzZWRTcmMuaG9zdG5hbWUpKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIHNyYyBwcm9wICgke3NyY30pIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGhvc3RuYW1lIFwiJHtwYXJzZWRTcmMuaG9zdG5hbWV9XCIgaXMgbm90IGNvbmZpZ3VyZWQgdW5kZXIgaW1hZ2VzIGluIHlvdXIgXFxgbmV4dC5jb25maWcuanNcXGBcXG5gICsgYFNlZSBtb3JlIGluZm86IGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL25leHQtaW1hZ2UtdW5jb25maWd1cmVkLWhvc3RgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gYCR7cm9vdH0/dXJsPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNyYyl9Jnc9JHt3aWR0aH0mcT0ke3F1YWxpdHkgfHwgNzV9YDtcbn1cblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW1hZ2UuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHtcbiAgICB2YWx1ZTogdHJ1ZVxufSk7XG5leHBvcnRzLnJlcXVlc3RJZGxlQ2FsbGJhY2sgPSBleHBvcnRzLmNhbmNlbElkbGVDYWxsYmFjayA9IHZvaWQgMDtcbmNvbnN0IHJlcXVlc3RJZGxlQ2FsbGJhY2sgPSB0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrICYmIHNlbGYucmVxdWVzdElkbGVDYWxsYmFjay5iaW5kKHdpbmRvdykgfHwgZnVuY3Rpb24oY2IpIHtcbiAgICBsZXQgc3RhcnQgPSBEYXRlLm5vdygpO1xuICAgIHJldHVybiBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICBjYih7XG4gICAgICAgICAgICBkaWRUaW1lb3V0OiBmYWxzZSxcbiAgICAgICAgICAgIHRpbWVSZW1haW5pbmc6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBNYXRoLm1heCgwLCA1MCAtIChEYXRlLm5vdygpIC0gc3RhcnQpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSwgMSk7XG59O1xuZXhwb3J0cy5yZXF1ZXN0SWRsZUNhbGxiYWNrID0gcmVxdWVzdElkbGVDYWxsYmFjaztcbmNvbnN0IGNhbmNlbElkbGVDYWxsYmFjayA9IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLmNhbmNlbElkbGVDYWxsYmFjayAmJiBzZWxmLmNhbmNlbElkbGVDYWxsYmFjay5iaW5kKHdpbmRvdykgfHwgZnVuY3Rpb24oaWQpIHtcbiAgICByZXR1cm4gY2xlYXJUaW1lb3V0KGlkKTtcbn07XG5leHBvcnRzLmNhbmNlbElkbGVDYWxsYmFjayA9IGNhbmNlbElkbGVDYWxsYmFjaztcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVxdWVzdC1pZGxlLWNhbGxiYWNrLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7XG4gICAgdmFsdWU6IHRydWVcbn0pO1xuZXhwb3J0cy51c2VJbnRlcnNlY3Rpb24gPSB1c2VJbnRlcnNlY3Rpb247XG52YXIgX3JlYWN0ID0gcmVxdWlyZShcInJlYWN0XCIpO1xudmFyIF9yZXF1ZXN0SWRsZUNhbGxiYWNrID0gcmVxdWlyZShcIi4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrXCIpO1xuY29uc3QgaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgIT09ICd1bmRlZmluZWQnO1xuZnVuY3Rpb24gdXNlSW50ZXJzZWN0aW9uKHsgcm9vdE1hcmdpbiAsIGRpc2FibGVkICB9KSB7XG4gICAgY29uc3QgaXNEaXNhYmxlZCA9IGRpc2FibGVkIHx8ICFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlcjtcbiAgICBjb25zdCB1bm9ic2VydmUgPSAoMCwgX3JlYWN0KS51c2VSZWYoKTtcbiAgICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSAoMCwgX3JlYWN0KS51c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3Qgc2V0UmVmID0gKDAsIF9yZWFjdCkudXNlQ2FsbGJhY2soKGVsKT0+e1xuICAgICAgICBpZiAodW5vYnNlcnZlLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50KCk7XG4gICAgICAgICAgICB1bm9ic2VydmUuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNEaXNhYmxlZCB8fCB2aXNpYmxlKSByZXR1cm47XG4gICAgICAgIGlmIChlbCAmJiBlbC50YWdOYW1lKSB7XG4gICAgICAgICAgICB1bm9ic2VydmUuY3VycmVudCA9IG9ic2VydmUoZWwsIChpc1Zpc2libGUpPT5pc1Zpc2libGUgJiYgc2V0VmlzaWJsZShpc1Zpc2libGUpXG4gICAgICAgICAgICAsIHtcbiAgICAgICAgICAgICAgICByb290TWFyZ2luXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sIFtcbiAgICAgICAgaXNEaXNhYmxlZCxcbiAgICAgICAgcm9vdE1hcmdpbixcbiAgICAgICAgdmlzaWJsZVxuICAgIF0pO1xuICAgICgwLCBfcmVhY3QpLnVzZUVmZmVjdCgoKT0+e1xuICAgICAgICBpZiAoIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyKSB7XG4gICAgICAgICAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpZGxlQ2FsbGJhY2sgPSAoMCwgX3JlcXVlc3RJZGxlQ2FsbGJhY2spLnJlcXVlc3RJZGxlQ2FsbGJhY2soKCk9PnNldFZpc2libGUodHJ1ZSlcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIHJldHVybiAoKT0+KDAsIF9yZXF1ZXN0SWRsZUNhbGxiYWNrKS5jYW5jZWxJZGxlQ2FsbGJhY2soaWRsZUNhbGxiYWNrKVxuICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIFtcbiAgICAgICAgdmlzaWJsZVxuICAgIF0pO1xuICAgIHJldHVybiBbXG4gICAgICAgIHNldFJlZixcbiAgICAgICAgdmlzaWJsZVxuICAgIF07XG59XG5mdW5jdGlvbiBvYnNlcnZlKGVsZW1lbnQsIGNhbGxiYWNrLCBvcHRpb25zKSB7XG4gICAgY29uc3QgeyBpZCAsIG9ic2VydmVyICwgZWxlbWVudHMgIH0gPSBjcmVhdGVPYnNlcnZlcihvcHRpb25zKTtcbiAgICBlbGVtZW50cy5zZXQoZWxlbWVudCwgY2FsbGJhY2spO1xuICAgIG9ic2VydmVyLm9ic2VydmUoZWxlbWVudCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIHVub2JzZXJ2ZSgpIHtcbiAgICAgICAgZWxlbWVudHMuZGVsZXRlKGVsZW1lbnQpO1xuICAgICAgICBvYnNlcnZlci51bm9ic2VydmUoZWxlbWVudCk7XG4gICAgICAgIC8vIERlc3Ryb3kgb2JzZXJ2ZXIgd2hlbiB0aGVyZSdzIG5vdGhpbmcgbGVmdCB0byB3YXRjaDpcbiAgICAgICAgaWYgKGVsZW1lbnRzLnNpemUgPT09IDApIHtcbiAgICAgICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgIG9ic2VydmVycy5kZWxldGUoaWQpO1xuICAgICAgICB9XG4gICAgfTtcbn1cbmNvbnN0IG9ic2VydmVycyA9IG5ldyBNYXAoKTtcbmZ1bmN0aW9uIGNyZWF0ZU9ic2VydmVyKG9wdGlvbnMpIHtcbiAgICBjb25zdCBpZCA9IG9wdGlvbnMucm9vdE1hcmdpbiB8fCAnJztcbiAgICBsZXQgaW5zdGFuY2UgPSBvYnNlcnZlcnMuZ2V0KGlkKTtcbiAgICBpZiAoaW5zdGFuY2UpIHtcbiAgICAgICAgcmV0dXJuIGluc3RhbmNlO1xuICAgIH1cbiAgICBjb25zdCBlbGVtZW50cyA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcigoZW50cmllcyk9PntcbiAgICAgICAgZW50cmllcy5mb3JFYWNoKChlbnRyeSk9PntcbiAgICAgICAgICAgIGNvbnN0IGNhbGxiYWNrID0gZWxlbWVudHMuZ2V0KGVudHJ5LnRhcmdldCk7XG4gICAgICAgICAgICBjb25zdCBpc1Zpc2libGUgPSBlbnRyeS5pc0ludGVyc2VjdGluZyB8fCBlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA+IDA7XG4gICAgICAgICAgICBpZiAoY2FsbGJhY2sgJiYgaXNWaXNpYmxlKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2soaXNWaXNpYmxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSwgb3B0aW9ucyk7XG4gICAgb2JzZXJ2ZXJzLnNldChpZCwgaW5zdGFuY2UgPSB7XG4gICAgICAgIGlkLFxuICAgICAgICBvYnNlcnZlcixcbiAgICAgICAgZWxlbWVudHNcbiAgICB9KTtcbiAgICByZXR1cm4gaW5zdGFuY2U7XG59XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZS1pbnRlcnNlY3Rpb24uanMubWFwIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBUaGVtZVByb3ZpZGVyIH0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4vcGFydHMvTmF2YmFyXCI7XHJcbmltcG9ydCBIZXJvIGZyb20gXCIuL3BhcnRzL0hlcm9cIjtcclxuaW1wb3J0IFNlY3Rpb24gZnJvbSBcIi4vcGFydHMvU2VjdGlvblwiO1xyXG5pbXBvcnQgQ2F0ZWdvcmllcyBmcm9tIFwiLi9wYXJ0cy9jYXRlZ29yaWVzXCI7XHJcbmltcG9ydCBMb2NhdGlvbnMgZnJvbSBcIi4vcGFydHMvbG9jYXRpb25zXCI7XHJcbmltcG9ydCBDb250YWN0dXMgZnJvbSBcIi4vcGFydHMvQ29udGFjdHVzXCI7XHJcbmltcG9ydCBBYm91dFVzIGZyb20gXCIuL3BhcnRzL0Fib3V0VXNcIjtcclxuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSBcIi4vcGFydHMvc3R5bGVzL0NvbnRhaW5lci5zdHlsZWRcIjtcclxuaW1wb3J0IEZvdW5kZXIgZnJvbSBcIi4vcGFydHMvRm91bmRlclwiO1xyXG5pbXBvcnQge0ZvdW5kZXJjb250YWluZXJ9IGZyb20gXCIuL3BhcnRzL3N0eWxlcy9Gb3VuZGVyY29udGFpbmVyLnN0eWxlZFwiO1xyXG5cclxuXHJcbmNvbnN0IHRoZW1lID0ge1xyXG4gIG1vYmlsZTogJzU4OXB4JyxcclxuICBmb250RmFtaWx5OiAnSW50ZXInXHJcbn1cclxuXHJcbmZ1bmN0aW9uIEhvbWUoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXt0aGVtZX0+XHJcbiAgICA8PlxyXG4gICAgICA8TmF2YmFyIC8+XHJcbiAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgPEFib3V0VXMgLz5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgIDxGb3VuZGVyY29udGFpbmVyPlxyXG4gICAgICAgIDxGb3VuZGVyIC8+XHJcbiAgICAgIDwvRm91bmRlcmNvbnRhaW5lcj5cclxuICAgICAgPEhlcm8gLz5cclxuICAgICAgPFNlY3Rpb24gLz5cclxuICAgICAgPENhdGVnb3JpZXMgLz5cclxuICAgICAgPExvY2F0aW9ucyAvPlxyXG4gICAgICA8Q29udGFjdHVzIC8+XHJcbiAgICA8Lz5cclxuICAgIDwvVGhlbWVQcm92aWRlcj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb21lO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IEFib3V0dXNjYXJkIH0gZnJvbSAnLi9zdHlsZXMvQWJvdXR1cy5zdHlsZWQnXHJcblxyXG5cclxuY29uc3QgQWJvdXRVcyA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEFib3V0dXNjYXJkPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyPkFib3V0IFVzPC9oMj5cclxuICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgIExvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNjaW5nIGVsaXQuIE51bmMgb2RpbyBpbiBldCwgbGVjdHVzIHNpdCBsb3JlbSBpZCBpbnRlZ2VyIGRvbG9yIHNpdCBhbWV0LCBjb25zZWN0ZXR1ciBhZGlwaXNjaW5nIGVsaXQuIE51bmMgb2RpbyBpbiBldC4gaWQgaW50ZWdlciBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXIgYWRpcGlzY2luZyBlbGl0LiBOZXQuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmMgPSAnLi4vLi4vLi4vLi4vYWJvdXR1cy5wbmcnPjwvaW1nPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0Fib3V0dXNjYXJkPlxyXG4gICAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBYm91dFVzIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSBcIm5leHQvaW1hZ2VcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgQ29udGFpbmVyLFxyXG4gIENvbnRhaW5lcjEsXHJcbiAgTGVmdGRpdixcclxuICBSaWdodGRpdixcclxuICBCdXR0b24sXHJcbiAgQnV0dG9uMSxcclxuICBIZWFkaW5nLFxyXG4gIFRleHQsXHJcbiAgTG9nbyxcclxufSBmcm9tIFwiLi9zdHlsZXMvQ29udGFjdHVzLnN0eWxlZFwiO1xyXG5cclxuaW1wb3J0IGhlbHAgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9oZWxwLnN2Z1wiO1xyXG5pbXBvcnQgbWFpbmltZyBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL2NvbnRhY3R1czEuc3ZnXCI7XHJcblxyXG5mdW5jdGlvbiBDb250YWN0dXMoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDb250YWluZXI+XHJcbiAgICAgIDxDb250YWluZXIxPlxyXG4gICAgICAgIDxMZWZ0ZGl2PlxyXG4gICAgICAgICAgPEhlYWRpbmc+Q29udGFjdCB1czwvSGVhZGluZz5cclxuICAgICAgICAgIDxUZXh0PlxyXG4gICAgICAgICAgICBMb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXIgYWRpcGlzY2luZyBlbGl0LiBOdW5jIG9kaW9cclxuICAgICAgICAgICAgaW4gZXQsIGxlY3R1cyBzaXQgbG9yZW0gaWQgaW50ZWdlciBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXJcclxuICAgICAgICAgICAgYWRpcGlzY2luZyBlbGl0LiBOdW5jIG9kaW8gaW4gZXQuIGlkIGludGVnZXIgZG9sb3Igc2l0IGFtZXQsXHJcbiAgICAgICAgICAgIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gTmV0LlxyXG4gICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgPEJ1dHRvbj5Kb2luIFNraWx6ZW48L0J1dHRvbj5cclxuICAgICAgICAgIDxMb2dvPjwvTG9nbz5cclxuICAgICAgICA8L0xlZnRkaXY+XHJcbiAgICAgICAgPFJpZ2h0ZGl2PlxyXG4gICAgICAgICAgPEltYWdlIHNyYz17bWFpbmltZ30gYWx0PVwicmlnaHRpbWdcIiAvPlxyXG4gICAgICAgICAgPEJ1dHRvbjE+Sm9pbiBTa2lsemVuPC9CdXR0b24xPlxyXG4gICAgICAgIDwvUmlnaHRkaXY+XHJcbiAgICAgIDwvQ29udGFpbmVyMT5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbnRhY3R1cztcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBGb3VuZGVybm90ZSwgVGVhbSB9IGZyb20gJy4vc3R5bGVzL0ZvdW5kZXJub3RlLnN0eWxlZCdcclxuXHJcblxyXG5jb25zdCBGb3VuZGVyID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgIDxGb3VuZGVybm90ZT5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDE+Rm91bmRlcidzIE5vdGU8L2gxPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1haW50ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYyA9IFwiLi4vLi4vLi4vLi4vcXVvdGVzLnBuZ1wiIGNsYXNzTmFtZT0ncXVvdGVzJz48L2ltZz4gICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj4gXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+IFdlIGhhZCBhbiBpbmNyZWRpYmxlIGV4cGVyaWVuY2Ugd29ya2luZyB3aXRoIFNraWx6ZW4gYW5kIHdlcmUgaW1wcmVzc2VkIHRoZXkgbWFkZSBzdWNoIGEgYmlnIGRpZmZlcmVuY2UgaW4gb25seSB0aHJlZSB3ZWVrcy4gT3VyIHRlYW0gaXMgc28gZ3JhdGVmdWwgZm9yIHRoZSB3b25kZXJmdWwgaW1wcm92ZW1lbnRzIHRoZXkgbWFkZSBhbmQgdGhlaXIgYWJpbGl0eSB0byBnZXQgZmFtaWxpYXIgd2l0aCB0aGUgcHJvZHVjdCBjb25jZXB0IHNvIHF1aWNrbHkuIEl0IGFjdGVkIGFzIGEgY2F0YWx5c3QgdG8gdGFrZSBvdXIgZGVzaWduIHRvIHRoZSBuZXh0IGxldmVsIGFuZCBnZXQgbW9yZSBleWVzIG9uIG91ciBwcm9kdWN0LiBPdXIgdGVhbSBpcyBzbyBncmF0ZWZ1bCBmb3IgdGhlIHdvbmRlcmZ1bCBpbXByb3ZlbWVudHMgdGhleSBtYWRlIGFuZCB0aGVpciBhYmlsaXR5IHRvIGdldCBmYW1pbGlhciB3aXRoIHRoZSBwcm9kdWN0IGNvbmNlcHQgc28gcXVpY2tseS4gSXQgYWN0ZWQgYXMgYSBjYXRhbHlzdCB0byB0YWtlIG91ciBkZXNpZ24gdG8gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZnVsbG5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZ1bGwgbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNlb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBDRU8gYXQgU2tpbGx6ZW4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjID0gJy4uLy4uLy4uLy4uL0ZvdW5kZXIucG5nJz48L2ltZz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Gb3VuZGVybm90ZT5cclxuICAgICAgICA8VGVhbT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9IFwidGVhbVwiPlxyXG4gICAgICAgICAgICA8aDQ+T3VyIFRlYW08L2g0PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwidGVhbWltZ1wiIHNyYyA9ICcuLi8uLi8uLi8uLi90ZWFtMS5wbmcnPjwvaW1nPlxyXG4gICAgICAgICAgICAgICAgICAgIDxmaWdjYXB0aW9uPkNFTyBhdCBTa2lsemVuPC9maWdjYXB0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZmlndXJlPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxmaWd1cmU+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9XCJ0ZWFtaW1nXCIgc3JjID0gJy4uLy4uLy4uLy4uL3RlYW0yLnBuZyc+PC9pbWc+XHJcbiAgICAgICAgICAgICAgICAgICAgPGZpZ2NhcHRpb24+RGVzaWduZXIgYXQgU2tpbHplbjwvZmlnY2FwdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwidGVhbWltZ1wiIHNyYyA9ICcuLi8uLi8uLi8uLi90ZWFtMy5wbmcnPjwvaW1nPlxyXG4gICAgICAgICAgICAgICAgICAgIDxmaWdjYXB0aW9uPkRlc2lnbmVyIGF0IFNraWx6ZW48L2ZpZ2NhcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9maWd1cmU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZmlndXJlPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPVwidGVhbWltZ1wiIHNyYyA9ICcuLi8uLi8uLi8uLi90ZWFtNC5wbmcnPjwvaW1nPlxyXG4gICAgICAgICAgICAgICAgICAgIDxmaWdjYXB0aW9uPkRlc2lnbmVyIGF0IFNraWx6ZW48L2ZpZ2NhcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L2ZpZ3VyZT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L1RlYW0+XHJcbiAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm91bmRlciIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBIZXJvQ29udGFpbmVyLFxyXG4gIEhlcm9EaXYsXHJcbiAgSGVyb1NlYXJjaCxcclxuICBIZXJvTGVmdCxcclxuICBIZXJvUmlnaHQsXHJcbiAgSGVhZGluZyxcclxuICBCdXR0b24sXHJcbiAgV3JpdGVyLFxyXG4gIFBhcmEsXHJcbiAgSW1hZ2UsXHJcbiAgSGVhZCxcclxuICBIZXJvU2VhcmNoTGVmdCxcclxuICBIZXJvU2VhcmNoUmlnaHQsXHJcbiAgSW1nLFxyXG4gIFNlYXJjaEljb24sXHJcbiAgU2VhcmNoRmllbGQsXHJcbiAgU2VhcmNoLFxyXG4gIElucHV0LFxyXG4gIEJ1dHRvblNlYXJjaCxcclxuICBTZWFyY2hJbWdcclxufSBmcm9tIFwiLi9zdHlsZXMvSGVyby5zdHlsZWRcIjtcclxuaW1wb3J0IHtTZWFyY2hCdXR0b259IGZyb20gXCIuL3N0eWxlcy9Db21tb25Db21wb25lbnRzL1NlYXJjaEJ1dHRvbi5zdHlsZWRcIjtcclxuXHJcbmZ1bmN0aW9uIEhlcm8oKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxIZXJvQ29udGFpbmVyPlxyXG4gICAgICA8SGVyb0Rpdj5cclxuICAgICAgICA8SGVyb0xlZnQ+XHJcbiAgICAgICAgICA8SGVhZGluZz5cclxuICAgICAgICAgICAgRmluZCB5b3VyIGRyZWFtIDxiciAvPlxyXG4gICAgICAgICAgICA8SGVhZD5JbnRlcm5zaGlwPC9IZWFkPlxyXG4gICAgICAgICAgPC9IZWFkaW5nPlxyXG4gICAgICAgICAgPEJ1dHRvbj5HZXQgU3RhcnRlZDwvQnV0dG9uPlxyXG4gICAgICAgICAgPFBhcmE+XHJcbiAgICAgICAgICAgIFRoZSBvbmx5IHdheSB0byBkbyBncmVhdCB3b3JrIGlzIHRvIGxvdmUgd2hhdCB5b3UgZG8uIElmIHlvdSBoYXZlbuKAmXRcclxuICAgICAgICAgICAgZm91bmQgaXQgeWV0LCBrZWVwIGxvb2tpbmcuIERvbuKAmXQgc2V0dGxlLiBBcyB3aXRoIGFsbCBtYXR0ZXJzIG9mIHRoZVxyXG4gICAgICAgICAgICBoZWFydCwgeW914oCZbGwga25vdyB3aGVuIHlvdSBmaW5kIGl0LuKAnVxyXG4gICAgICAgICAgPC9QYXJhPlxyXG4gICAgICAgICAgPFdyaXRlcj4tU3RldmUgSm9iczwvV3JpdGVyPlxyXG4gICAgICAgIDwvSGVyb0xlZnQ+XHJcbiAgICAgICAgPEhlcm9SaWdodD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9XCIuL2hvbWUucG5nXCIgLz5cclxuICAgICAgICA8L0hlcm9SaWdodD5cclxuICAgICAgPC9IZXJvRGl2PlxyXG4gICAgICA8SGVyb1NlYXJjaD5cclxuICAgICAgICA8SGVyb1NlYXJjaExlZnQ+XHJcbiAgICAgICAgICA8SW1nIHNyYz1cIi4vZWFyYnVncy5zdmdcIiAvPlxyXG4gICAgICAgIDwvSGVyb1NlYXJjaExlZnQ+XHJcbiAgICAgICAgPEhlcm9TZWFyY2hSaWdodD5cclxuICAgICAgICAgIDxTZWFyY2g+XHJcbiAgICAgICAgICAgIDxTZWFyY2hJY29uPlxyXG4gICAgICAgICAgICAgIDxTZWFyY2hJbWcgc3JjPVwiLi9zZWFyY2guc3ZnXCIgLz5cclxuICAgICAgICAgICAgPC9TZWFyY2hJY29uPlxyXG4gICAgICAgICAgICA8U2VhcmNoRmllbGQ+XHJcbiAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiU2VhcmNoIEludGVybnNoaXBzIGhlcmUuLi5cIj48L0lucHV0PlxyXG4gICAgICAgICAgICA8L1NlYXJjaEZpZWxkPlxyXG4gICAgICAgICAgICAgIDxTZWFyY2hCdXR0b24+U2VhcmNoPC9TZWFyY2hCdXR0b24+XHJcbiAgICAgICAgICA8L1NlYXJjaD5cclxuICAgICAgICA8L0hlcm9TZWFyY2hSaWdodD5cclxuICAgICAgPC9IZXJvU2VhcmNoPlxyXG4gICAgPC9IZXJvQ29udGFpbmVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhlcm87XHJcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIENvbnRhaW5lcixcclxuICBMaW5rcyxcclxuICBMaW5rLFxyXG4gIEJ1dHRvbixcclxuICBJbWFnZSxcclxuICBJbWFnZUNvbnRhaW5lcixcclxuICBMaW5rQ29udGFpbmVyLFxyXG4gIE1lbnUsXHJcbn0gZnJvbSBcIi4vc3R5bGVzL05hdmJhci5zdHlsZWRcIjtcclxuXHJcbmZ1bmN0aW9uIE5hdmJhcigpIHtcclxuICBjb25zdCBbY2xpY2ssIHNldENsaWNrXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICBzZXRDbGljayghY2xpY2spO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGFpbmVyPlxyXG4gICAgICA8SW1hZ2VDb250YWluZXI+XHJcbiAgICAgICAgPEltYWdlIHNyYz1cIi9sb2dvLnN2Z1wiIC8+XHJcbiAgICAgIDwvSW1hZ2VDb250YWluZXI+XHJcbiAgICAgIDxMaW5rQ29udGFpbmVyPlxyXG4gICAgICAgIDxNZW51IHNyYz1cIi4vbWVudS5zdmdcIiBvbkNsaWNrPXtoYW5kbGVDbGlja30+PC9NZW51PlxyXG5cclxuICAgICAgICA8TGlua3Mgb25DbGljaz17aGFuZGxlQ2xpY2t9IGNsaWNrPXtjbGlja30+XHJcbiAgICAgICAgICA8TGluaz5Qb3N0IGFuIEludGVybnNoaXA8L0xpbms+XHJcbiAgICAgICAgICA8TGluaz5GaW5kIEludGVybnNoaXBzPC9MaW5rPlxyXG4gICAgICAgICAgPExpbms+U2lnbiBJbjwvTGluaz5cclxuICAgICAgICAgIDxCdXR0b24+U2lnbiBVcDwvQnV0dG9uPlxyXG4gICAgICAgIDwvTGlua3M+XHJcbiAgICAgIDwvTGlua0NvbnRhaW5lcj5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdmJhcjtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSBcIm5leHQvaW1hZ2VcIjtcclxuaW1wb3J0IHsgQm90dG9tLCBDb250YWluZXIsIFRvcCwgV3JhcCB9IGZyb20gXCIuL3N0eWxlcy9TZWN0aW9uLnN0eWxlZFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi9zdHlsZXMvQ29tbW9uQ29tcG9uZW50cy9CdXR0b24uc3R5bGVkXCI7XHJcbmltcG9ydCB7IEhlYWRpbmcgfSBmcm9tIFwiLi9zdHlsZXMvQ29tbW9uQ29tcG9uZW50cy9IZWFkaW5nLnN0eWxlZFwiO1xyXG5pbXBvcnQge0NhcmR9IGZyb20gXCIuL3N0eWxlcy9Db21tb25Db21wb25lbnRzL0NhcmQuc3R5bGVkXCJcclxuXHJcbmNvbnN0IFNlY3Rpb24gPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDb250YWluZXI+XHJcbiAgICAgIDxUb3A+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZWZ0XCI+XHJcbiAgICAgICAgICA8SGVhZGluZz5Ib3cgZG9lcyBpdCB3b3JrPzwvSGVhZGluZz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJpZ2h0XCI+XHJcbiAgICAgICAgICA8aDU+XHJcbiAgICAgICAgICAgIExvcmVtIGlwc3VtIGRvbG9yIHNpdCBhbWV0IGNvbnNlY3RldHVyIGFkaXBpc2ljaW5nIGVsaXQuIFNlZCBhdHF1ZVxyXG4gICAgICAgICAgICBuaWhpbCBsYWJvcmUgcmVwdWRpYW5kYWUgZWxpZ2VuZGksIGFuaW1pIGFjY3VzYW11cyBmYWNlcmUuXHJcbiAgICAgICAgICAgIFBlcmZlcmVuZGlzIGV0IHF1YWVyYXQgZW9zIG1hZ25pIHZlcml0YXRpcywgaXRhcXVlIHVuZGUsIHF1aXMgcXVhcyBhXHJcbiAgICAgICAgICAgIG1haW9yZXMgZmFjZXJlLlxyXG4gICAgICAgICAgPC9oNT5cclxuICAgICAgICAgIDxCdXR0b24+QXBwbHkgTm93PC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvVG9wPlxyXG4gICAgICA8Qm90dG9tPlxyXG4gICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgPEltYWdlIHNyYz1cIi9pbWFnZXMvMS5wbmdcIiBhbHQ9XCJ1bml2ZXJzZVwiIHdpZHRoPXs0MDB9IGhlaWdodD17NDAwfSAvPlxyXG4gICAgICAgICAgPGgzPlNpZ24gSW48L2gzPlxyXG4gICAgICAgICAgPHA+Q3JlYXRlIGFuIGFjY291bnQgdG8gZ2V0IHN0YXJ0ZWQ8L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICA8Q2FyZD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaW1hZ2VzLzIucG5nXCIgYWx0PVwidW5pdmVyc2VcIiB3aWR0aD17MzUwfSBoZWlnaHQ9ezM1MH0gLz5cclxuICAgICAgICAgIDxoMz5TZWFyY2ggZm9yIGludGVybnNoaXBzPC9oMz5cclxuICAgICAgICAgIDxwPkxvb2sgdGhvcnVnaCBvdXIgY2FyZWZ1bGx5IGhhbmRwaWNrZWQgYnVuY2ggb2YgaW50ZXJuc2hpcHM8L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG5cclxuICAgICAgICA8Q2FyZD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaW1hZ2VzLzMucG5nXCIgYWx0PVwidW5pdmVyc2VcIiB3aWR0aD17MzUwfSBoZWlnaHQ9ezM1MH0gLz5cclxuICAgICAgICAgIDxoMz5BcHBseSBhbmQgZm9sbG93IHByb2NlZHVyZTwvaDM+XHJcbiAgICAgICAgICA8cD5Ob3cgc2l0IGJhY2sgYW5kIHdhaXQgZm9yIHRoZSBjYWxsIGJhY2sgYW5kIGZvbGxvdyBzaW1wbGUgc3RlcHM8L3A+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICA8L0JvdHRvbT5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWN0aW9uO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQ29udGFpbmVyLFxyXG4gIERpdnN0YXJ0LFxyXG4gIElubmVyZGl2MSxcclxuICBJbm5lcmRpdjIsXHJcbiAgU3BhbjUwLFxyXG4gIFNwYW5yaWdodCxcclxuICBTcGFucmlnaHQyLFxyXG4gIExvd2VyZGl2LFxyXG4gIENhdGVnb3J5Y2FyZCxcclxuICBCdXR0b24sXHJcbiAgQ2F0ZWdvcnljYXJkMSxcclxuICBTcGFuMSxcclxufSBmcm9tIFwiLi9zdHlsZXMvQ2F0ZWdvcmllcy5zdHlsZWRcIjtcclxuaW1wb3J0IEltYWdlIGZyb20gXCJuZXh0L2ltYWdlXCI7XHJcbmltcG9ydCBlbmdnIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvZW5nZy5zdmdcIjtcclxuaW1wb3J0IGNvbW1lcmNlIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvY29tbWVyY2Uuc3ZnXCI7XHJcbmltcG9ydCBtYW5hZ2UgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9sZXZlbC5zdmdcIjtcclxuaW1wb3J0IG1lZGljYWwgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9tZWRpY2FsLnN2Z1wiO1xyXG5pbXBvcnQgc2NpZW5jZSBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL3NjaWVuY2Uuc3ZnXCI7XHJcbmltcG9ydCBMVCBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL0xULnN2Z1wiO1xyXG5pbXBvcnQgaHVtYW5pdGllcyBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL2h1bWFuaXRpZXMuc3ZnXCI7XHJcbmltcG9ydCBsYXcgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9sYXcuc3ZnXCI7XHJcbmltcG9ydCBhcnRzIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvYXJ0cy5zdmdcIjtcclxuXHJcbmZ1bmN0aW9uIENhdGVnb3JpZXMoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxDb250YWluZXI+XHJcbiAgICAgIDxEaXZzdGFydD5cclxuICAgICAgICA8SW5uZXJkaXYxPlxyXG4gICAgICAgICAgPFNwYW41MD41MCs8L1NwYW41MD5cclxuICAgICAgICAgIDxTcGFuMT5DYXRlZ29yaWVzPC9TcGFuMT5cclxuICAgICAgICA8L0lubmVyZGl2MT5cclxuICAgICAgICA8SW5uZXJkaXYyPlxyXG4gICAgICAgICAgPFNwYW5yaWdodD5cclxuICAgICAgICAgICAgRXhwbG9yZSBvdXIgaGFuZHBpY2tlZCBjYXRhZ29yeSBvZiBJbnRlcm5zaGlwcyBhbmQgdW5sb2NrIHlvdXJcclxuICAgICAgICAgICAgam91cm5leSB3aXRoIHVzIHRvZGF5ISBTZWxlY3Qgb25lIHRvIHZpZXcgdGhlIGludGVybnNoaXBzXHJcbiAgICAgICAgICA8L1NwYW5yaWdodD5cclxuICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgPFNwYW5yaWdodDI+VmlldyBhbGwgSW50ZXJuc2hpcHM8L1NwYW5yaWdodDI+XHJcbiAgICAgICAgPC9Jbm5lcmRpdjI+XHJcbiAgICAgIDwvRGl2c3RhcnQ+XHJcblxyXG4gICAgICA8TG93ZXJkaXY+XHJcbiAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIHsvKiA8TG9nbyBzcmM9Jy4uLy4uL3B1YmxpYy9lbmdnLnN2ZycgYWx0PVwiZW5nZ1wiLz4gKi99XHJcbiAgICAgICAgICA8SW1hZ2Ugc3JjPXtlbmdnfSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgIDxzcGFuPkVuZ2luZWVyaW5nPC9zcGFuPlxyXG4gICAgICAgIDwvQ2F0ZWdvcnljYXJkPlxyXG4gICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICA8SW1hZ2Ugc3JjPXtjb21tZXJjZX0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5Db21tZXJjZTwvc3Bhbj5cclxuICAgICAgICA8L0NhdGVnb3J5Y2FyZD5cclxuICAgICAgICA8Q2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgPEltYWdlIHNyYz17bWFuYWdlfSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgIDxzcGFuPk1hbmFnZW1lbnQ8L3NwYW4+XHJcbiAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9e21lZGljYWx9IGFsdD1cImVuZ2dcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+TWVkaWNhbDwvc3Bhbj5cclxuICAgICAgICA8L0NhdGVnb3J5Y2FyZD5cclxuICAgICAgICA8Q2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgPEltYWdlIHNyYz17c2NpZW5jZX0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5TY2llbmNlPC9zcGFuPlxyXG4gICAgICAgIDwvQ2F0ZWdvcnljYXJkPlxyXG4gICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICA8SW1hZ2Ugc3JjPXtMVH0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5MLlQuPC9zcGFuPlxyXG4gICAgICAgIDwvQ2F0ZWdvcnljYXJkPlxyXG4gICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICA8SW1hZ2Ugc3JjPXtodW1hbml0aWVzfSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgIDxzcGFuPkh1bWFuaXRpZXM8L3NwYW4+XHJcbiAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9e2xhd30gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICA8c3Bhbj5MYXc8L3NwYW4+XHJcbiAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIDxJbWFnZSBzcmM9e2FydHN9IGFsdD1cImVuZ2dcIiAvPlxyXG4gICAgICAgICAgPHNwYW4+QXJ0czwvc3Bhbj5cclxuICAgICAgICA8L0NhdGVnb3J5Y2FyZD5cclxuICAgICAgICA8Q2F0ZWdvcnljYXJkMT5cclxuICAgICAgICAgIDxCdXR0b24+VmlldyBtb3JlPC9CdXR0b24+XHJcbiAgICAgICAgPC9DYXRlZ29yeWNhcmQxPlxyXG4gICAgICA8L0xvd2VyZGl2PlxyXG4gICAgPC9Db250YWluZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2F0ZWdvcmllcztcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEhlcm9TZWFyY2gsXHJcbiAgSGVyb1NlYXJjaExlZnQsXHJcbiAgSGVyb1NlYXJjaFJpZ2h0LFxyXG4gIFNlYXJjaEljb24sXHJcbiAgU2VhcmNoRmllbGQsXHJcbiAgU2VhcmNoQnV0dG9uLFxyXG4gIFNlYXJjaCxcclxuICBCdXR0b25TZWFyY2gsXHJcbiAgSW1nLFxyXG4gIElucHV0LFxyXG4gIFNlYXJjaEltZyxcclxufSBmcm9tIFwiLi9zdHlsZXMvSGVyby5zdHlsZWRcIjtcclxuaW1wb3J0IHtcclxuICBDb250YWluZXIsXHJcbiAgRGl2c3RhcnQsXHJcbiAgSW5uZXJkaXYxLFxyXG4gIElubmVyZGl2MixcclxuICBTcGFuNTAsXHJcbiAgU3BhbnJpZ2h0LFxyXG4gIFNwYW5yaWdodDIsXHJcbiAgTG93ZXJkaXYsXHJcbiAgQ2F0ZWdvcnljYXJkLFxyXG4gIEJ1dHRvbixcclxuICBDYXRlZ29yeWNhcmQxLFxyXG4gIFNwYW4xLFxyXG59IGZyb20gXCIuL3N0eWxlcy9Mb2NhdGlvbnMuc3R5bGVkXCI7XHJcbmltcG9ydCBJbWFnZSBmcm9tIFwibmV4dC9pbWFnZVwiO1xyXG5pbXBvcnQgbmNyIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvZGVsaGluY3Iuc3ZnXCI7XHJcbmltcG9ydCBiZW5nYWx1cnUgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9iZW5nYWx1cnUuc3ZnXCI7XHJcbmltcG9ydCBjaGVubmFpIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvY2hlbm5haS5zdmdcIjtcclxuaW1wb3J0IGh5ZGVyYWJhZCBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL2h5ZGVyYWJhZC5zdmdcIjtcclxuaW1wb3J0IGtvbGthdGEgZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy9rb2xrYXRhLnN2Z1wiO1xyXG5pbXBvcnQgbXVtYmFpIGZyb20gXCIuLi8uLi8uLi8uLi9wdWJsaWMvbXVtYmFpLnN2Z1wiO1xyXG5pbXBvcnQgcHVuZSBmcm9tIFwiLi4vLi4vLi4vLi4vcHVibGljL3B1bmUuc3ZnXCI7XHJcbmltcG9ydCB3ZmggZnJvbSBcIi4uLy4uLy4uLy4uL3B1YmxpYy93Zmguc3ZnXCI7XHJcblxyXG5mdW5jdGlvbiBMb2NhdGlvbnMoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgPERpdnN0YXJ0PlxyXG4gICAgICAgICAgPElubmVyZGl2MT5cclxuICAgICAgICAgICAgPFNwYW4xPkxvY2F0aW9uczwvU3BhbjE+XHJcbiAgICAgICAgICA8L0lubmVyZGl2MT5cclxuICAgICAgICAgIDxJbm5lcmRpdjI+XHJcbiAgICAgICAgICAgIDxTcGFucmlnaHQ+XHJcbiAgICAgICAgICAgICAgV2UgYXJlIGN1cnJlbnRseSBlbmNvdXJhZ2luZyBXb3JrIEZyb20gSG9tZSBJbnRlcm5zaGlwcyBmb3IgdGhlXHJcbiAgICAgICAgICAgICAgc2FmZXR5IGZvciBhbGwgb3VyIGxvdmVkIG9uZXMuIEZpbmQgdGhlIGJlc3QgaW50ZXJuc2hpcFxyXG4gICAgICAgICAgICAgIG9wcG9ydHVuaXRpZXMgaGVyZSB0byBsYXVuY2ggeW91ciBwcm9mZXNzaW9uYWwgY2FyZWVyLlxyXG4gICAgICAgICAgICA8L1NwYW5yaWdodD5cclxuICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICA8L0lubmVyZGl2Mj5cclxuICAgICAgICA8L0RpdnN0YXJ0PlxyXG5cclxuICAgICAgICA8TG93ZXJkaXY+XHJcbiAgICAgICAgICA8Q2F0ZWdvcnljYXJkMT5cclxuICAgICAgICAgICAgPEltYWdlIHNyYz17bmNyfSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+TmV3IERlbGhpIE5DUjwvc3Bhbj5cclxuICAgICAgICAgIDwvQ2F0ZWdvcnljYXJkMT5cclxuICAgICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICAgIDxJbWFnZSBzcmM9e211bWJhaX0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPk11bWJhaTwvc3Bhbj5cclxuICAgICAgICAgIDwvQ2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgICAgPEltYWdlIHNyYz17cHVuZX0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPlB1bmU8L3NwYW4+XHJcbiAgICAgICAgICA8L0NhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICAgIDxJbWFnZSBzcmM9e2tvbGthdGF9IGFsdD1cImVuZ2dcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5Lb2xrYXRhPC9zcGFuPlxyXG4gICAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICA8Q2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPXtjaGVubmFpfSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+Q2hlbm5haTwvc3Bhbj5cclxuICAgICAgICAgIDwvQ2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgPENhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgICAgPEltYWdlIHNyYz17YmVuZ2FsdXJ1fSBhbHQ9XCJlbmdnXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4+QmVuZ2FsdXJ1PC9zcGFuPlxyXG4gICAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICA8Q2F0ZWdvcnljYXJkPlxyXG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoeWRlcmFiYWR9IGFsdD1cImVuZ2dcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5IeWRlcmFiYWQ8L3NwYW4+XHJcbiAgICAgICAgICA8L0NhdGVnb3J5Y2FyZD5cclxuICAgICAgICAgIDxDYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgICAgIDxJbWFnZSBzcmM9e3dmaH0gYWx0PVwiZW5nZ1wiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuPldvcmsgRnJvbSBIb21lPC9zcGFuPlxyXG4gICAgICAgICAgPC9DYXRlZ29yeWNhcmQ+XHJcbiAgICAgICAgPC9Mb3dlcmRpdj5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgIDxIZXJvU2VhcmNoPlxyXG4gICAgICAgIDxIZXJvU2VhcmNoTGVmdD5cclxuICAgICAgICAgIDxJbWcgc3JjPVwiLi9lYXJidWdzLnN2Z1wiIC8+XHJcbiAgICAgICAgPC9IZXJvU2VhcmNoTGVmdD5cclxuICAgICAgICA8SGVyb1NlYXJjaFJpZ2h0PlxyXG4gICAgICAgICAgPFNlYXJjaD5cclxuICAgICAgICAgICAgPFNlYXJjaEljb24+XHJcbiAgICAgICAgICAgICAgPFNlYXJjaEltZyBzcmM9XCIuL3NlYXJjaC5zdmdcIiAvPlxyXG4gICAgICAgICAgICA8L1NlYXJjaEljb24+XHJcbiAgICAgICAgICAgIDxTZWFyY2hGaWVsZD5cclxuICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJTZWFyY2ggTG9jYXRpb24gaGVyZS4uLlwiPjwvSW5wdXQ+XHJcbiAgICAgICAgICAgIDwvU2VhcmNoRmllbGQ+XHJcbiAgICAgICAgICAgIDxTZWFyY2hCdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblNlYXJjaD5TZWFyY2g8L0J1dHRvblNlYXJjaD5cclxuICAgICAgICAgICAgPC9TZWFyY2hCdXR0b24+XHJcbiAgICAgICAgICA8L1NlYXJjaD5cclxuICAgICAgICA8L0hlcm9TZWFyY2hSaWdodD5cclxuICAgICAgPC9IZXJvU2VhcmNoPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9jYXRpb25zO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEFib3V0dXNjYXJkID0gc3R5bGVkLmRpdmBcclxuZGlzcGxheTogZmxleDtcclxuYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuanVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbmJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcblxyXG5kaXYge1xyXG4gICAgd2lkdGg6MTAwJVxyXG59XHJcblxyXG5pbWcge1xyXG4gICAgd2lkdGggOiA0NDdweDtcclxuICAgIGhlaWdodCA6IDQ4MHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQwcHg7XHJcbiAgfVxyXG5cclxuaDIge1xyXG4gICAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDQwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA2MHB4O1xyXG4gICAgd2lkdGggOiAyMjBweDtcclxuICAgIGJvcmRlci1ib3R0b20gOiAjRjI2QTdFIHNvbGlkIDVweDtcclxuICAgIC8vIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gICAgXHJcbiAgICAvKiBpZGVudGljYWwgdG8gYm94IGhlaWdodCwgb3IgMjQ1JSAqL1xyXG4gICAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiAnc2FsdCcgb24sICdsaWdhJyBvZmY7XHJcbiAgICBcclxuICAgIGNvbG9yOiAjNDA0MzY2O1xyXG59XHJcblxyXG5cclxucCB7XHJcbiAgICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgICB3aWR0aDogNjAwcHg7XHJcblxyXG4gICAgLyogb3IgMTYwJSAqL1xyXG4gICAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiAnc2FsdCcgb24sICdsaWdhJyBvZmY7XHJcblxyXG4gICAgY29sb3I6ICMxODE5MUY7XHJcbn1cclxuXHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogJHsoeyB0aGVtZSB9KSA9PiB0aGVtZS5tb2JpbGV9KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgd2lkdGggOiAxMDAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwMHB4O1xyXG4gICAgaW1nIHtcclxuICAgICAgICB3aWR0aCA6IDQwMHB4O1xyXG4gICAgICAgIGhlaWdodCA6IDQyMHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMDBweDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gICAgfVxyXG5gIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgRGl2c3RhcnQgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgLy8gYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjpjb2x1bW47XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IElubmVyZGl2MSA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogXCJmbGV4XCI7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG5gO1xyXG5leHBvcnQgY29uc3QgSW5uZXJkaXYyID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBcImZsZXhcIjtcclxuICB3aWR0aDogNTAlO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFuNTAgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBmb250LXNpemU6IDcycHg7XHJcbiAgbGluZS1oZWlnaHQ6IDk4cHg7XHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG5gO1xyXG5leHBvcnQgY29uc3QgU3BhbjEgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBmb250LXNpemU6IDcycHg7XHJcbiAgbGluZS1oZWlnaHQ6IDk4cHg7XHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzZweDtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNwYW5yaWdodCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsaW5lLWhlaWdodDogMzJweDtcclxuXHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG5cclxuICBjb2xvcjogIzE4MTkxZjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMXB4O1xyXG4gICAgd2lkdGg6IDM3MHB4O1xyXG4gICAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNwYW5yaWdodDIgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcblxyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuXHJcbiAgY29sb3I6ICMxODE5MWY7XHJcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gIG1hcmdpbi10b3A6IDYlO1xyXG4gIGJvcmRlci1ib3R0b206IDEuNzZweCBzb2xpZCAjMTgxOTFmO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xyXG4gICAgd2lkdGg6IDE3MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMb3dlcmRpdiA9IHN0eWxlZC5kaXZgXHJcbmRpc3BsYXk6IGZsZXg7XHJcbmhlaWdodDogNzAlO1xyXG53aWR0aDogODAlO1xyXG5mbGV4LXdyYXA6IHdyYXA7XHJcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5tYXJnaW4tdG9wOiA0JTtcclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiAzODFweCkge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWxlZnQ6IDM1cHg7XHJcbn0gIFxyXG5cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBDYXRlZ29yeWNhcmQgPSBzdHlsZWQuZGl2YFxyXG53aWR0aDogMTc0cHg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICAgIGJhY2tkcm9wLWZpbHRlcjogYmx1cig0MHB4KTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgaGVpZ2h0OiAxNDBweDtcclxuICAgIGZsZXg6IDAgMCAxNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkMSA9IHN0eWxlZC5kaXZgXHJcbndpZHRoOiAxNzRweDtcclxuXHJcbmhlaWdodDogMTNlbTtcclxuYm9yZGVyOiAwcHggc29saWQgcmdiYSg3NSwgNzUsIDc1LCAwLjMpO1xyXG5ib3JkZXItcmFkaXVzOiA4cHg7XHJcbmZsZXg6IDAgMCAxNGVtO1xyXG5tYXJnaW4tdG9wOiAyJTtcclxuYm94LXNpemluZzogYm9yZGVyLWJveDtcclxubWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5tYXJnaW4tbGVmdDogMTBweDtcclxuXHJcbmRpc3BsYXk6IGZsZXg7XHJcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG5mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuJjpob3ZlciB7XHJcbiAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gIHdpZHRoOiAxNDBweDtcclxuICBoZWlnaHQ6IDE0MHB4O1xyXG4gIGZsZXg6IDAgMCAxNDBweDtcclxufVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmMjZhN2U7XHJcbiAgYmFja2dyb3VuZDogbm9uZTtcclxuXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogMTlweDtcclxuXHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuXHJcbiAgbWFyZ2luOiAwcHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogI2YyNmE3ZTtcclxuICB9XHJcbmA7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcclxuY3Vyc29yOiBwb2ludGVyO1xyXG5iYWNrZ3JvdW5kLWNvbG9yOiAjZjI2YTdlO1xyXG5tYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbmNvbG9yOiAjZmZmO1xyXG5mb250LXNpemU6IDE2cHg7XHJcbmJvcmRlcjogbm9uZTtcclxucGFkZGluZzogMTBweCAyNnB4O1xyXG5ib3JkZXItcmFkaXVzOiA0cHg7XHJcbiY6aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmYzViNzM7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxufVxyXG5gOyIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgQ2FyZCA9IHN0eWxlZC5kaXZgXHJcbmJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbmJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxucGFkZGluZzogMTVweDtcclxudGV4dC1hbGlnbjogY2VudGVyO1xyXG5ib3JkZXItcmFkaXVzOiA3cHg7XHJcbmRpc3BsYXk6IGZsZXg7XHJcbmZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbmp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG5pbWcge1xyXG4gIG9iamVjdC1maXQ6IGNvbnRhaW47XHJcbiAgbWF4LWhlaWdodDogMjQwcHg7XHJcbn1cclxuaDMge1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcbmAiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBIZWFkaW5nID0gc3R5bGVkLmgxYFxyXG5mb250LWZhbWlseTogSW50ZXI7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbmZvbnQtc2l6ZTogNjBweDtcclxuXHJcbi8qIGlkZW50aWNhbCB0byBib3ggaGVpZ2h0LCBvciAyNDUlICovXHJcbmZvbnQtZmVhdHVyZS1zZXR0aW5nczogJ3NhbHQnIG9uLCAnbGlnYScgb2ZmO1xyXG5cclxuY29sb3I6ICM0MDQzNjY7XHJcbmAiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEJ1dHRvbiA9IHN0eWxlZC5kaXZgXHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzY2O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICB3aWR0aDogMzAlO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgcGFkZGluZzogMTNweCAzOHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgJjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzU1O1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICAgIH1cclxuICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZzogMTRweCAzMHB4O1xyXG4gICAgfVxyXG5gIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIG1heC13aWR0aDogMTAwMHB4O1xyXG4gICAgbWluLXdpZHRoOiA3ODBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ29udGFpbmVyMSA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICB3aWR0aDogODAlO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExlZnRkaXYgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgd2lkdGg6IDUwJTtcclxuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIG1hcmdpbi10b3A6IDE1JTtcclxuYDtcclxuZXhwb3J0IGNvbnN0IFJpZ2h0ZGl2ID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWFyZ2luLXRvcDogMTUlO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZWFkaW5nID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGZvbnQtc2l6ZTogNDBweDtcclxuICBsaW5lLWhlaWdodDogNjBweDtcclxuICAvKiBpZGVudGljYWwgdG8gYm94IGhlaWdodCwgb3IgMjQ1JSAqL1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcbiAgYm9yZGVyLWJvdHRvbTogNXB4IHNvbGlkICNmMjZhN2U7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG5cclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDUyOXB4KSB7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgZm9udC1zaXplOiAyMnB4O1xyXG4gIH1cclxuYDtcclxuZXhwb3J0IGNvbnN0IFRleHQgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgLyogb3IgMTYwJSAqL1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcblxyXG4gIGNvbG9yOiAjMTgxOTFmO1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxuICB3aWR0aDogNzAlO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xyXG4gICAgd2lkdGg6IDIwMCU7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuZGl2YFxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogNjlweDtcclxuICBoZWlnaHQ6IDY5cHg7XHJcbiAgbGVmdDogNjhweDtcclxuICB0b3A6IDY2OXB4O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNjAwcHgpIHtcclxuICAgIHdpZHRoOiA0MnB4O1xyXG4gICAgaGVpZ2h0OiA0MnB4O1xyXG4gICAgbGVmdDogODAlO1xyXG4gICAgdG9wOiAyMHJlbTtcclxuXHJcbiAgICBmaWx0ZXI6IGRyb3Atc2hhZG93KC00LjI2MDg3cHggMHB4IDE0LjYwODdweCByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuNDQpKTtcclxuICB9XHJcbmA7XHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIHBhZGRpbmc6IDE3cHggMzVweDtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBiYWNrZ3JvdW5kOiAjZjI2YTdlO1xyXG4gIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICBib3JkZXI6IDBweDtcclxuICBtYXJnaW4tdG9wOiA1JTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuYDtcclxuZXhwb3J0IGNvbnN0IEJ1dHRvbjEgPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGRpc3BsYXk6IG5vbmU7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgcGFkZGluZzogMTdweCAzNXB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgYmFja2dyb3VuZDogI2YyNmE3ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcclxuICAgIGJvcmRlcjogMHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgfVxyXG5gO1xyXG4iLCJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5cclxuZXhwb3J0IGNvbnN0IENvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMDBweDtcclxuICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMCAyMHB4O1xyXG4gIG1hcmdpbjogMjBweCBhdXRvO1xyXG5gIiwiaW1wb3J0IHN0eWxlZCBmcm9tICdzdHlsZWQtY29tcG9uZW50cydcclxuXHJcbmV4cG9ydCBjb25zdCBGb3VuZGVyY29udGFpbmVyID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMjBweCA4MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLm1vYmlsZX0pIHtcclxuICAgIC8vIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIC8vIHdpZHRoOiAxMDAlO1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gICAgbGVmdDogMDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI7XHJcbiAgICBtYXJnaW46IDQwcHggNDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICBwYWRkaW5nOiA0MHB4IDgwcHg7XHJcbiAgICBwIHtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiA1MHB4O1xyXG4gICAgfVxyXG59XHJcbmAiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEZvdW5kZXJub3RlID0gc3R5bGVkLmRpdmBcclxuZGlzcGxheTogZmxleDtcclxuanVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbmJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI7XHJcbmRpdiB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI7XHJcbn1cclxuXHJcbmgxIHtcclxuICAgIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgZm9udC1zaXplOiA0MHB4O1xyXG4gICAgd2lkdGggOiA0MDBweDtcclxuICAgIC8qIGlkZW50aWNhbCB0byBib3ggaGVpZ2h0LCBvciAyNDUlICovXHJcbiAgICBmb250LWZlYXR1cmUtc2V0dGluZ3M6ICdzYWx0JyBvbiwgJ2xpZ2EnIG9mZjtcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogODBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDMwcHg7XHJcbiAgICBjb2xvcjogIzQwNDM2NjtcclxufVxyXG5cclxucCB7XHJcblxyXG4gICAgd2lkdGg6IDY0MHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogNjBweDtcclxuXHJcbiAgICAvKiBvciAxMzMlICovXHJcbiAgICBmb250LWZlYXR1cmUtc2V0dGluZ3M6ICdzYWx0JyBvbiwgJ2xpZ2EnIG9mZjtcclxuXHJcbiAgICBjb2xvcjogIzQwNDM2NjtcclxufVxyXG5cclxuaW1nIHtcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICAgIGhlaWdodDogNDI4cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxOXB4O1xyXG59XHJcblxyXG4ubWFpbnRleHQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxufVxyXG5cclxuLmZ1bGxuYW1le1xyXG4gICAgY29sb3I6ICNGMjZBN0U7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4XHJcbn1cclxuXHJcbi5jZW97XHJcbiAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgbWFyZ2luOiBub25lO1xyXG4gICAgbGluZS1oZWlnaHQ6IDBcclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUubW9iaWxlfSkge1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbi1yZXZlcnNlO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI4QTtcclxuICAgIHdpZHRoOiBkZXZpY2Utd2lkdGg7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDI3JTtcclxuICAgIH1cclxuICAgIGgxe1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OjI0JTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAzMHB4XHJcbiAgICB9XHJcbnB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDYwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG59XHJcbn1cclxuLnF1b3Rlc3tcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgb3BhY2l0eTogMC40XHJcbn1cclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IFRlYW0gPSBzdHlsZWQuZGl2YFxyXG4udGVhbXtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgbWFyZ2luLWxlZnQ6MTAwcHg7XHJcbn1cclxuXHJcbi50ZWFtaW1ne1xyXG4gICAgaGVpZ2h0OjEwMHB4O1xyXG4gICAgd2lkdGg6MTAwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOjUwJTtcclxuICAgIG1hcmdpbi1sZWZ0OiA2MHB4O1xyXG59XHJcblxyXG5oNHtcclxuICAgIGZvbnQtZmFtaWx5OiAkeyh7IHRoZW1lIH0pID0+IHRoZW1lLmZvbnRGYW1pbHl9O1xyXG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDIxLjI0NDJweDtcclxuICAgIGNvbG9yOiAjNDA0MzY2O1xyXG4gICAgbWFyZ2luLXRvcDogODBweDtcclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6ICR7KHsgdGhlbWUgfSkgPT4gdGhlbWUubW9iaWxlfSkge1xyXG4gICAgLnRlYW0ge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNDOUNCRTI7XHJcbiAgICB9XHJcbn1cclxuXHJcbmZpZ2NhcHRpb24ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQ1cHg7XHJcbiAgICBtYXJnaW4tdG9wOjEwcHg7XHJcbiAgICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xyXG4gICAgLyogb3IgMTYyJSAqL1xyXG5cclxuICAgIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogJ3NhbHQnIG9uLCAnbGlnYScgb2ZmO1xyXG5cclxuICAgIGNvbG9yOiAjNDA0MzY2O1xyXG59XHJcbmAiLCJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9EaXYgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIC8vIEBtZWRpYSAobWF4LXdpZHRoOiA4NjZweCkge1xyXG4gIC8vICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAvLyB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcclxuICBwYWRkaW5nLWxlZnQ6IDQwcHg7XHJcbiAgcGFkZGluZy1yaWdodDogNDBweDtcclxuICBwYWRkaW5nLWJvdHRvbTogMjBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmNWY1O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIHBhZGRpbmctbGVmdDogMjVweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDI1cHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gIH1cclxuXHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb0xlZnQgPSBzdHlsZWQuZGl2YFxyXG4gICR7XCJcIiAvKiBoZWlnaHQ6IDY1dmg7ICovfVxyXG4gIGhlaWdodDogNDUwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICR7XCJcIiAvKiBhbGlnbi1pdGVtczogY2VudGVyOyAqL31cclxuICAke1wiXCIgLyogdGV4dC1hbGlnbjogY2VudGVyOyAqL31cclxuICAgIG1hcmdpbi1sZWZ0OiAxMzBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIGhlaWdodDogMzUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTI5cHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogOTAzcHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvUmlnaHQgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNDAwcHg7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogLTMwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAtMzBweDtcclxuICAgIGhlaWdodDogbWluLWNvbnRlbnQ7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEltYWdlID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogNTM4cHg7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAxMTI5cHgpIHtcclxuICAgIHdpZHRoOiA0MzlweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICB3aWR0aDogMzY1cHg7XHJcbiAgICBoZWlnaHQ6IDM1NHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMzkycHgpIHtcclxuICAgIHdpZHRoOiAyNjVweDtcclxuICAgIGhlaWdodDogMjU0cHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5NTRweCkge1xyXG4gICAgd2lkdGg6IDM5MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjI2YTdlO1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDEwcHggMjZweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgJjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmM1YjczO1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgUGFyYSA9IHN0eWxlZC5wYFxyXG4gIHdpZHRoOiA0MjBweDtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuICBsaW5lLWhlaWdodDogMjVweDtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBwYWRkaW5nOiAxNXB4IDA7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICB3aWR0aDogMzMycHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIxcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAzOTJweCkge1xyXG4gICAgd2lkdGg6IDMwMHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMzQxcHgpIHtcclxuICAgIHdpZHRoOiAyODBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgV3JpdGVyID0gc3R5bGVkLnNwYW5gXHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZWFkaW5nID0gc3R5bGVkLmgxYFxyXG4gIGZvbnQtc2l6ZTogNDVweDtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuICBtYXJnaW4tYm90dG9tOiA1MHB4O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMzZweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEzcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNDA0cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVhZCA9IHN0eWxlZC5zcGFuYFxyXG4gIGZvbnQtc2l6ZTogNTFweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBmb250LXNpemU6IDQ0cHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA0MDRweCkge1xyXG4gICAgZm9udC1zaXplOiAzNnB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvU2VhcmNoID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIG1hcmdpbi1sZWZ0OiA0MHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMTcwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNDBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb1NlYXJjaExlZnQgPSBzdHlsZWQuZGl2YFxyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmOWJmYzI7XHJcbiAgcGFkZGluZzogMTBweCA5cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIG1hcmdpbi1yaWdodDogNjBweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIG1hcmdpbi1yaWdodDogMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDEwcHg7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGJveC1zaGFkb3c6IHJnYmEoMjQyLCAxMDYsIDEyNiwgMC4yNSkgMHB4IDU0cHggNTVweCxcclxuICAgICAgcmdiYSgyNDIsIDEwNiwgMTI2LCAwLjEyKSAwcHggLTEycHggMzBweCxcclxuICAgICAgcmdiYSgyNDIsIDEwNiwgMTI2LCAwLjEyKSAwcHggNHB4IDZweCxcclxuICAgICAgcmdiYSgyNDIsIDEwNiwgMTI2LCAwLjE3KSAwcHggOXB4IDEzcHgsXHJcbiAgICAgIHJnYmEoMjQyLCAxMDYsIDEyNiwgMC4wOSkgMHB4IC0zcHggNXB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvU2VhcmNoUmlnaHQgPSBzdHlsZWQuZGl2YFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjOWNiZTI7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGhlaWdodDogNDVweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgZmxleDogMTtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTZWFyY2ggPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiA4MDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMzVweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW1nID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzRweDtcclxuICBoZWlnaHQ6IDI1cHg7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU2VhcmNoSW1nID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzRweDtcclxuICBoZWlnaHQ6IDI1cHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIGNvbG9yOiAjZjI2YTdlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTZWFyY2hJY29uID0gc3R5bGVkLmRpdmBcclxuICBtYXJnaW4tbGVmdDogNDBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDQwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAwO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEZpZWxkID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTAwJTtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbnB1dCA9IHN0eWxlZC5pbnB1dGBcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgb3V0bGluZTogbm9uZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAxMHB4IDA7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICNjOWNiZTI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgICY6OnBsYWNlaG9sZGVyIHtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b25TZWFyY2ggPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzY2O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDEzcHggMzhweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgJjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzU1O1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBwYWRkaW5nOiAxNHB4IDMwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEJ1dHRvbiA9IHN0eWxlZC5kaXZgYDtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbi10b3A6IDEwMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDgwcHg7XHJcbiAgcGFkZGluZzogMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IERpdnN0YXJ0ID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uIDogY29sdW1uO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbm5lcmRpdjEgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IFwiZmxleFwiO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuYDtcclxuZXhwb3J0IGNvbnN0IElubmVyZGl2MiA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogXCJmbGV4XCI7XHJcbiAgd2lkdGg6IDUwJTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU3BhbjUwID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuYDtcclxuZXhwb3J0IGNvbnN0IFNwYW4xID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDM2cHg7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcblxyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuXHJcbiAgY29sb3I6ICMxODE5MWY7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjFweDtcclxuICAgIHdpZHRoOiAzNzBweDtcclxuICAgIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICAgIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQyID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcblxyXG4gIGNvbG9yOiAjMTgxOTFmO1xyXG4gIHdpZHRoOiBmaXQtY29udGVudDtcclxuICBtYXJnaW4tdG9wOiA2JTtcclxuICBib3JkZXItYm90dG9tOiAxLjc2cHggc29saWQgIzE4MTkxZjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiAxNzBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTG93ZXJkaXYgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgaGVpZ2h0OiA3MCU7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBtYXJnaW4tdG9wOiA0JTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDM4MXB4KSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tbGVmdDogMzVweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTc0cHg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICAgIGJhY2tkcm9wLWZpbHRlcjogYmx1cig0MHB4KTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgaGVpZ2h0OiAxNDBweDtcclxuICAgIGZsZXg6IDAgMCAxNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkMSA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDE3NHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY4Zjg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcblxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuICAmOmhvdmVyIHtcclxuICAgIGJveC1zaGFkb3c6IDBweCA4cHggMjRweCByZ2JhKDIxNiwgMjE2LCAyMTYsIDAuMyk7XHJcbiAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIHdpZHRoOiAxNDBweDtcclxuICAgIGhlaWdodDogMTQwcHg7XHJcbiAgICBmbGV4OiAwIDAgMTQwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmMjZhN2U7XHJcbiAgYmFja2dyb3VuZDogbm9uZTtcclxuXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogMTlweDtcclxuXHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuXHJcbiAgbWFyZ2luOiAwcHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogI2YyNmE3ZTtcclxuICB9XHJcbmA7XHJcbiIsImltcG9ydCBzdHlsZWQgZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcclxuICBtYXgtd2lkdGg6IDEyMDBweDtcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBoZWlnaHQ6IDc3cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTE1OHB4KSB7XHJcbiAgICBtYXJnaW4tbGVmdDogNDBweDtcclxuICAgIG1hcmdpbi1yaWdodDogNDBweDtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA0MDBweCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEltYWdlID0gc3R5bGVkLmltZ2BgO1xyXG5cclxuZXhwb3J0IGNvbnN0IE1lbnUgPSBzdHlsZWQuaW1nYFxyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjJzO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMaW5rcyA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDUwMHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgcGFkZGluZzogMTBweCAwO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDMwMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDgwcHg7XHJcbiAgICBsZWZ0OiAkeyh7IGNsaWNrIH0pID0+IChjbGljayA/IDAgOiBcIi0xMDAlXCIpfTtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC41cyBlYXNlO1xyXG4gICAgYmFja2dyb3VuZDogI2U1ZTVlNTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTGluayA9IHN0eWxlZC5hYFxyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgICY6aG92ZXIge1xyXG4gICAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgIzRiNTlmNztcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YyNmE3ZTtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBwYWRkaW5nOiAxMHB4IDI2cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMnB4O1xyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZjNWI3MztcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgIHBhZGRpbmc6IDEycHggNjRweDtcclxuICAgICR7XCJcIiAvKiB3aWR0aDogODAlOyAgKi99XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEltYWdlQ29udGFpbmVyID0gc3R5bGVkLmRpdmBcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExpbmtDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxuYDtcclxuIiwiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IENvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZjZmNmYztcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBwYWRkaW5nOiAxMDBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogOTMycHgpIHtcclxuICAgIHBhZGRpbmc6IDUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBUb3AgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDkzMnB4KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuICAubGVmdCB7XHJcbiAgICBmbGV4OiAwLjU7XHJcbiAgICBoMSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogNzJweDtcclxuICAgICAgY29sb3I6ICM0MDQzNjY7XHJcbiAgICAgIG1heC13aWR0aDogNTAwcHg7XHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogNTJweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAucmlnaHQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBmbGV4OiAwLjU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogOTMycHgpIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA5MzJweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMjJweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgYnV0dG9uIHtcclxuICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YyNmE3ZTtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBCb3R0b20gPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgbWFyZ2luLXRvcDogMTAwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMywgbWlubWF4KDAsIDFmcikpO1xyXG4gIGdyaWQtZ2FwOiAyMHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5MzJweCkge1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMiwgbWlubWF4KDAsIDFmcikpO1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDYwMHB4KSB7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgxLCBtaW5tYXgoMCwgMWZyKSk7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBXcmFwID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA3cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGltZyB7XHJcbiAgICBvYmplY3QtZml0OiBjb250YWluO1xyXG4gICAgbWF4LWhlaWdodDogMjQwcHg7XHJcbiAgfVxyXG4gIGgzIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IHsgQ29udGFpbmVyLCBUb3AsIEJvdHRvbSwgV3JhcCB9O1xyXG4iLCJpbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XHJcbmltcG9ydCBIb21lUGFnZSBmcm9tIFwiLi9jb21wb25lbnRzL2hvbWVwYWdlL0hvbWVcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxIZWFkPlxyXG4gICAgICAgIDx0aXRsZT5Ib21lPC90aXRsZT5cclxuICAgICAgICA8bWV0YSBuYW1lPVwiZGVzY3JpcHRpb25cIiBjb250ZW50PVwiR2VuZXJhdGVkIGJ5IGNyZWF0ZSBuZXh0IGFwcFwiIC8+XHJcbiAgICAgICAgPGxpbmsgcmVsPVwiaWNvblwiIGhyZWY9XCIvZmF2aWNvbi5pY29cIiAvPlxyXG4gICAgICA8L0hlYWQ+XHJcblxyXG4gICAgICA8SG9tZVBhZ2UgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9MVC43ZDVlMmRkYzBiZWFlZGViNmNkYjZhNDMzYzllZTRlNi5zdmdcIixcImhlaWdodFwiOjgwLFwid2lkdGhcIjo4MX07IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9hcnRzLjIzYzgzYjliNTBjNzFjM2YyY2EzM2M4NWU2N2FkMWM1LnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjgxfTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL2JlbmdhbHVydS5mOTU5MjUwNmJlYjc4ZWEzYzI2OTYyNzczMTlhMTY2Ni5zdmdcIixcImhlaWdodFwiOjgwLFwid2lkdGhcIjo4OH07IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9jaGVubmFpLmY2NTgwNGVmZmI3MzJjZTNmODVkMWE4NTVmMmIxNzAyLnN2Z1wiLFwiaGVpZ2h0XCI6ODAsXCJ3aWR0aFwiOjU4fTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL2NvbW1lcmNlLjM2NDI4ZWJmZDU5YWVkYWJjNGQ2ZjBhMjU5OTBhNmZmLnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjgxfTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL2NvbnRhY3R1czEuZDQ4YjY2MjlkOTcwNWQ2ZjM5YmU1NWMyYjI1MDBjYzUuc3ZnXCIsXCJoZWlnaHRcIjo1MDgsXCJ3aWR0aFwiOjQ3M307IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9kZWxoaW5jci5jMjBmMzk1OGVlZGQ3NjliNjFlZDNlZWVjMzE1M2I4ZC5zdmdcIixcImhlaWdodFwiOjgwLFwid2lkdGhcIjo3OH07IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9lbmdnLmZiYTM0OGY4NWEzM2IzNGU3ZDAzZjkwODZkZTU4MTM4LnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjgxfTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL2hlbHAuMzc0NzU5ZmI2YmE1YWZmYjRlNzI0Y2UwNTEyYzNiYzQuc3ZnXCIsXCJoZWlnaHRcIjo2OSxcIndpZHRoXCI6Njl9OyIsImV4cG9ydCBkZWZhdWx0IHtcInNyY1wiOlwiL19uZXh0L3N0YXRpYy9pbWFnZS9wdWJsaWMvaHVtYW5pdGllcy4zNzJlZDA5YzU5MmI4MTAzMjBkY2Y3YmQ0MTI4MDUwZC5zdmdcIixcImhlaWdodFwiOjgxLFwid2lkdGhcIjo4MX07IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9oeWRlcmFiYWQuNWNlYzA2MTUxOGY5ODI1NWRhNmFkMTQ5MWIzNDY3ZTIuc3ZnXCIsXCJoZWlnaHRcIjo4MCxcIndpZHRoXCI6OTZ9OyIsImV4cG9ydCBkZWZhdWx0IHtcInNyY1wiOlwiL19uZXh0L3N0YXRpYy9pbWFnZS9wdWJsaWMva29sa2F0YS4wYjdjNzY4YTk1MDYwNDA0Yzc1OTAxODk0YWRlMjliMS5zdmdcIixcImhlaWdodFwiOjgwLFwid2lkdGhcIjoxMzV9OyIsImV4cG9ydCBkZWZhdWx0IHtcInNyY1wiOlwiL19uZXh0L3N0YXRpYy9pbWFnZS9wdWJsaWMvbGF3Ljg2NjZiOTVlOTkxZWNmODUxMGZmNmZjY2QzNzRlZDhiLnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjgxfTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL2xldmVsLmFjMThiNjczNDE1M2JlYzc0Njc4M2I1YTNiNWVkZDU1LnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjgxfTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL21lZGljYWwuMGQ5OWY5ZDBiOTAyOWYzOWY2MmFiMzVhOGFkOTE2ZDcuc3ZnXCIsXCJoZWlnaHRcIjo4MSxcIndpZHRoXCI6ODF9OyIsImV4cG9ydCBkZWZhdWx0IHtcInNyY1wiOlwiL19uZXh0L3N0YXRpYy9pbWFnZS9wdWJsaWMvbXVtYmFpLmVjODdhMWI3MDU1MzkyNTBlYWJjN2ZiOWUzYWQ2MTIyLnN2Z1wiLFwiaGVpZ2h0XCI6ODAsXCJ3aWR0aFwiOjEwNH07IiwiZXhwb3J0IGRlZmF1bHQge1wic3JjXCI6XCIvX25leHQvc3RhdGljL2ltYWdlL3B1YmxpYy9wdW5lLjQxM2VlYmNjMjUwYTUyNTIyYWIzN2U2NzZhOTQyYTUyLnN2Z1wiLFwiaGVpZ2h0XCI6ODEsXCJ3aWR0aFwiOjM3fTsiLCJleHBvcnQgZGVmYXVsdCB7XCJzcmNcIjpcIi9fbmV4dC9zdGF0aWMvaW1hZ2UvcHVibGljL3NjaWVuY2UuZGM4NTQzOWM4M2ViYjQ4NWE1YzQxOTQzOTAxNjdmOWMuc3ZnXCIsXCJoZWlnaHRcIjo4MSxcIndpZHRoXCI6ODF9OyIsImV4cG9ydCBkZWZhdWx0IHtcInNyY1wiOlwiL19uZXh0L3N0YXRpYy9pbWFnZS9wdWJsaWMvd2ZoLjcwMGUwYTUwOGZhY2VhYmY3ZGQ4MTZhYjIzOTg2MGU3LnN2Z1wiLFwiaGVpZ2h0XCI6ODAsXCJ3aWR0aFwiOjk5fTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9jbGllbnQvaW1hZ2UnKVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NlcnZlci9pbWFnZS1jb25maWcuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L3NoYXJlZC9saWIvaGVhZC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3Qvc2hhcmVkL2xpYi90by1iYXNlLTY0LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWNvbXBvbmVudHNcIik7Il0sIm5hbWVzIjpbIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwiZXhwb3J0cyIsInZhbHVlIiwiZGVmYXVsdCIsIkltYWdlMSIsIl9yZWFjdCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2hlYWQiLCJfdG9CYXNlNjQiLCJfaW1hZ2VDb25maWciLCJfdXNlSW50ZXJzZWN0aW9uIiwiX2RlZmluZVByb3BlcnR5Iiwib2JqIiwia2V5IiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiX19lc01vZHVsZSIsIl9vYmplY3RTcHJlYWQiLCJ0YXJnZXQiLCJpIiwiYXJndW1lbnRzIiwibGVuZ3RoIiwic291cmNlIiwib3duS2V5cyIsImtleXMiLCJnZXRPd25Qcm9wZXJ0eVN5bWJvbHMiLCJjb25jYXQiLCJmaWx0ZXIiLCJzeW0iLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJmb3JFYWNoIiwiX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzIiwiZXhjbHVkZWQiLCJfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZSIsInNvdXJjZVN5bWJvbEtleXMiLCJpbmRleE9mIiwicHJvdG90eXBlIiwicHJvcGVydHlJc0VudW1lcmFibGUiLCJjYWxsIiwic291cmNlS2V5cyIsImxvYWRlZEltYWdlVVJMcyIsIlNldCIsImdsb2JhbCIsIl9fTkVYVF9JTUFHRV9JTVBPUlRFRCIsIlZBTElEX0xPQURJTkdfVkFMVUVTIiwidW5kZWZpbmVkIiwibG9hZGVycyIsIk1hcCIsImRlZmF1bHRMb2FkZXIiLCJpbWdpeExvYWRlciIsImNsb3VkaW5hcnlMb2FkZXIiLCJha2FtYWlMb2FkZXIiLCJjdXN0b21Mb2FkZXIiLCJWQUxJRF9MQVlPVVRfVkFMVUVTIiwiaXNTdGF0aWNSZXF1aXJlIiwic3JjIiwiaXNTdGF0aWNJbWFnZURhdGEiLCJpc1N0YXRpY0ltcG9ydCIsImRldmljZVNpemVzIiwiY29uZmlnRGV2aWNlU2l6ZXMiLCJpbWFnZVNpemVzIiwiY29uZmlnSW1hZ2VTaXplcyIsImxvYWRlciIsImNvbmZpZ0xvYWRlciIsInBhdGgiLCJjb25maWdQYXRoIiwiZG9tYWlucyIsImNvbmZpZ0RvbWFpbnMiLCJwcm9jZXNzIiwiZW52IiwiX19ORVhUX0lNQUdFX09QVFMiLCJpbWFnZUNvbmZpZ0RlZmF1bHQiLCJhbGxTaXplcyIsInNvcnQiLCJhIiwiYiIsImdldFdpZHRocyIsIndpZHRoIiwibGF5b3V0Iiwic2l6ZXMiLCJ2aWV3cG9ydFdpZHRoUmUiLCJwZXJjZW50U2l6ZXMiLCJtYXRjaCIsImV4ZWMiLCJwdXNoIiwicGFyc2VJbnQiLCJzbWFsbGVzdFJhdGlvIiwiTWF0aCIsIm1pbiIsIndpZHRocyIsInMiLCJraW5kIiwibWFwIiwidyIsImZpbmQiLCJwIiwiZ2VuZXJhdGVJbWdBdHRycyIsInVub3B0aW1pemVkIiwicXVhbGl0eSIsInNyY1NldCIsImxhc3QiLCJqb2luIiwiZ2V0SW50IiwieCIsImRlZmF1bHRJbWFnZUxvYWRlciIsImxvYWRlclByb3BzIiwibG9hZCIsImdldCIsInJvb3QiLCJFcnJvciIsIlZBTElEX0xPQURFUlMiLCJoYW5kbGVMb2FkaW5nIiwiaW1nIiwicGxhY2Vob2xkZXIiLCJvbkxvYWRpbmdDb21wbGV0ZSIsImhhbmRsZUxvYWQiLCJzdGFydHNXaXRoIiwiZGVjb2RlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJjYXRjaCIsInRoZW4iLCJzdHlsZSIsImJhY2tncm91bmRTaXplIiwiYmFja2dyb3VuZEltYWdlIiwiYWRkIiwibmF0dXJhbFdpZHRoIiwibmF0dXJhbEhlaWdodCIsInJlZiIsInBhcmVudEVsZW1lbnQiLCJwYXJlbnQiLCJnZXRDb21wdXRlZFN0eWxlIiwiZGlzcGxheSIsImNvbnNvbGUiLCJ3YXJuIiwicG9zaXRpb24iLCJjb21wbGV0ZSIsIm9ubG9hZCIsIl9wYXJhbSIsInByaW9yaXR5IiwibG9hZGluZyIsImxhenlCb3VuZGFyeSIsImNsYXNzTmFtZSIsImhlaWdodCIsIm9iamVjdEZpdCIsIm9iamVjdFBvc2l0aW9uIiwiYmx1ckRhdGFVUkwiLCJhbGwiLCJyZXN0Iiwic3RhdGljU3JjIiwic3RhdGljSW1hZ2VEYXRhIiwiSlNPTiIsInN0cmluZ2lmeSIsIndpZHRoSW50IiwiaGVpZ2h0SW50IiwicXVhbGl0eUludCIsImlzTGF6eSIsImhhcyIsImluY2x1ZGVzIiwiU3RyaW5nIiwiaXNOYU4iLCJWQUxJRF9CTFVSX0VYVCIsInJhbmQiLCJmbG9vciIsInJhbmRvbSIsInRvU3RyaW5nIiwic2V0UmVmIiwiaXNJbnRlcnNlY3RlZCIsInVzZUludGVyc2VjdGlvbiIsInJvb3RNYXJnaW4iLCJkaXNhYmxlZCIsImlzVmlzaWJsZSIsIndyYXBwZXJTdHlsZSIsInNpemVyU3R5bGUiLCJzaXplclN2ZyIsImltZ1N0eWxlIiwidG9wIiwibGVmdCIsImJvdHRvbSIsInJpZ2h0IiwiYm94U2l6aW5nIiwicGFkZGluZyIsImJvcmRlciIsIm1hcmdpbiIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJtaW5IZWlnaHQiLCJtYXhIZWlnaHQiLCJibHVyU3R5bGUiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJvdmVyZmxvdyIsInF1b3RpZW50IiwicGFkZGluZ1RvcCIsImltZ0F0dHJpYnV0ZXMiLCJzcmNTdHJpbmciLCJjcmVhdGVFbGVtZW50IiwiYWx0IiwidG9CYXNlNjQiLCJhc3NpZ24iLCJkZWNvZGluZyIsInJlbCIsImFzIiwiaHJlZiIsImltYWdlc3Jjc2V0IiwiaW1hZ2VzaXplcyIsIm5vcm1hbGl6ZVNyYyIsInNsaWNlIiwidXJsIiwiVVJMIiwicGFyYW1zIiwic2VhcmNoUGFyYW1zIiwic2V0IiwicGFyYW1zU3RyaW5nIiwibWlzc2luZ1ZhbHVlcyIsInBhcnNlZFNyYyIsImVyciIsImVycm9yIiwiaG9zdG5hbWUiLCJlbmNvZGVVUklDb21wb25lbnQiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwiY2FuY2VsSWRsZUNhbGxiYWNrIiwic2VsZiIsImJpbmQiLCJ3aW5kb3ciLCJjYiIsInN0YXJ0IiwiRGF0ZSIsIm5vdyIsInNldFRpbWVvdXQiLCJkaWRUaW1lb3V0IiwidGltZVJlbWFpbmluZyIsIm1heCIsImlkIiwiY2xlYXJUaW1lb3V0IiwiX3JlcXVlc3RJZGxlQ2FsbGJhY2siLCJoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiaXNEaXNhYmxlZCIsInVub2JzZXJ2ZSIsInVzZVJlZiIsInZpc2libGUiLCJzZXRWaXNpYmxlIiwidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsImVsIiwiY3VycmVudCIsInRhZ05hbWUiLCJvYnNlcnZlIiwidXNlRWZmZWN0IiwiaWRsZUNhbGxiYWNrIiwiZWxlbWVudCIsImNhbGxiYWNrIiwib3B0aW9ucyIsIm9ic2VydmVyIiwiZWxlbWVudHMiLCJjcmVhdGVPYnNlcnZlciIsImRlbGV0ZSIsInNpemUiLCJkaXNjb25uZWN0Iiwib2JzZXJ2ZXJzIiwiaW5zdGFuY2UiLCJlbnRyaWVzIiwiZW50cnkiLCJpc0ludGVyc2VjdGluZyIsImludGVyc2VjdGlvblJhdGlvIiwiUmVhY3QiLCJUaGVtZVByb3ZpZGVyIiwiTmF2YmFyIiwiSGVybyIsIlNlY3Rpb24iLCJDYXRlZ29yaWVzIiwiTG9jYXRpb25zIiwiQ29udGFjdHVzIiwiQWJvdXRVcyIsIkNvbnRhaW5lciIsIkZvdW5kZXIiLCJGb3VuZGVyY29udGFpbmVyIiwidGhlbWUiLCJtb2JpbGUiLCJmb250RmFtaWx5IiwiSG9tZSIsIkFib3V0dXNjYXJkIiwiSW1hZ2UiLCJDb250YWluZXIxIiwiTGVmdGRpdiIsIlJpZ2h0ZGl2IiwiQnV0dG9uIiwiQnV0dG9uMSIsIkhlYWRpbmciLCJUZXh0IiwiTG9nbyIsImhlbHAiLCJtYWluaW1nIiwiRm91bmRlcm5vdGUiLCJUZWFtIiwiSGVyb0NvbnRhaW5lciIsIkhlcm9EaXYiLCJIZXJvU2VhcmNoIiwiSGVyb0xlZnQiLCJIZXJvUmlnaHQiLCJXcml0ZXIiLCJQYXJhIiwiSGVhZCIsIkhlcm9TZWFyY2hMZWZ0IiwiSGVyb1NlYXJjaFJpZ2h0IiwiSW1nIiwiU2VhcmNoSWNvbiIsIlNlYXJjaEZpZWxkIiwiU2VhcmNoIiwiSW5wdXQiLCJCdXR0b25TZWFyY2giLCJTZWFyY2hJbWciLCJTZWFyY2hCdXR0b24iLCJMaW5rcyIsIkxpbmsiLCJJbWFnZUNvbnRhaW5lciIsIkxpbmtDb250YWluZXIiLCJNZW51IiwiY2xpY2siLCJzZXRDbGljayIsImhhbmRsZUNsaWNrIiwiQm90dG9tIiwiVG9wIiwiV3JhcCIsIkNhcmQiLCJEaXZzdGFydCIsIklubmVyZGl2MSIsIklubmVyZGl2MiIsIlNwYW41MCIsIlNwYW5yaWdodCIsIlNwYW5yaWdodDIiLCJMb3dlcmRpdiIsIkNhdGVnb3J5Y2FyZCIsIkNhdGVnb3J5Y2FyZDEiLCJTcGFuMSIsImVuZ2ciLCJjb21tZXJjZSIsIm1hbmFnZSIsIm1lZGljYWwiLCJzY2llbmNlIiwiTFQiLCJodW1hbml0aWVzIiwibGF3IiwiYXJ0cyIsIm5jciIsImJlbmdhbHVydSIsImNoZW5uYWkiLCJoeWRlcmFiYWQiLCJrb2xrYXRhIiwibXVtYmFpIiwicHVuZSIsIndmaCIsInN0eWxlZCIsImRpdiIsImJ1dHRvbiIsImgxIiwic3BhbiIsImlucHV0IiwiSG9tZVBhZ2UiXSwic291cmNlUm9vdCI6IiJ9