"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Section.styled.js":
/*!******************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Section.styled.js ***!
  \******************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": function() { return /* binding */ Container; },
/* harmony export */   "Top": function() { return /* binding */ Top; },
/* harmony export */   "Bottom": function() { return /* binding */ Bottom; },
/* harmony export */   "Wrap": function() { return /* binding */ Wrap; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Sectionstyled__Container",
  componentId: "sc-1rrpk2a-0"
})(["background-color:#fcfcfc;margin:0 auto;padding:100px;display:flex;flex-direction:column;align-items:center;@media (max-width:932px){padding:50px;}@media (max-width:600px){padding:10px;}@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
var Top = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Sectionstyled__Top",
  componentId: "sc-1rrpk2a-1"
})(["display:flex;@media (max-width:932px){flex-direction:column;}.left{flex:0.5;h1{font-size:72px;color:#404366;max-width:500px;@media (max-width:600px){font-size:52px;}}}.right{margin-left:20px;flex:0.5;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;@media (max-width:932px){margin-left:0;margin-top:20px;}h5{font-weight:500;font-size:20px;line-height:32px;@media (max-width:932px){font-size:15px;line-height:22px;}}button{margin-top:30px;background-color:#f26a7e;color:#fff;border:none;padding:10px;cursor:pointer;border-radius:4px;}}"]);
var Bottom = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Sectionstyled__Bottom",
  componentId: "sc-1rrpk2a-2"
})(["display:grid;margin-top:100px;width:100%;grid-template-columns:repeat(3,minmax(0,1fr));grid-gap:20px;@media (max-width:932px){grid-template-columns:repeat(2,minmax(0,1fr));margin-top:30px;}@media (max-width:600px){grid-template-columns:repeat(1,minmax(0,1fr));}"]);
var Wrap = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Sectionstyled__Wrap",
  componentId: "sc-1rrpk2a-3"
})(["background-color:#fff;border:1px solid lightgray;padding:15px;text-align:center;border-radius:7px;display:flex;flex-direction:column;justify-content:space-evenly;img{object-fit:contain;max-height:240px;}h3{font-weight:600;font-size:24px;}"]);


;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguM2RhOWU2OGZjOTFjM2Q4MDdlOTEuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVBLElBQU1DLFNBQVMsR0FBR0QscUVBQUg7QUFBQTtBQUFBO0FBQUEsNFBBQWY7QUFrQkEsSUFBTUcsR0FBRyxHQUFHSCxxRUFBSDtBQUFBO0FBQUE7QUFBQSw4akJBQVQ7QUErQ0EsSUFBTUksTUFBTSxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSw2UUFBWjtBQWNBLElBQU1LLElBQUksR0FBR0wscUVBQUg7QUFBQTtBQUFBO0FBQUEsc1BBQVY7QUFtQkEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvU2VjdGlvbi5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmNvbnN0IENvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZjZmNmYztcclxuICBtYXJnaW46IDAgYXV0bztcclxuICBwYWRkaW5nOiAxMDBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogOTMycHgpIHtcclxuICAgIHBhZGRpbmc6IDUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBUb3AgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDkzMnB4KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIH1cclxuICAubGVmdCB7XHJcbiAgICBmbGV4OiAwLjU7XHJcbiAgICBoMSB7XHJcbiAgICAgIGZvbnQtc2l6ZTogNzJweDtcclxuICAgICAgY29sb3I6ICM0MDQzNjY7XHJcbiAgICAgIG1heC13aWR0aDogNTAwcHg7XHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA2MDBweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogNTJweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICAucmlnaHQge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICBmbGV4OiAwLjU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBAbWVkaWEgKG1heC13aWR0aDogOTMycHgpIHtcclxuICAgICAgbWFyZ2luLWxlZnQ6IDA7XHJcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB9XHJcbiAgICBoNSB7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgbGluZS1oZWlnaHQ6IDMycHg7XHJcbiAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA5MzJweCkge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogMjJweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgYnV0dG9uIHtcclxuICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YyNmE3ZTtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgcGFkZGluZzogMTBweDtcclxuICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBCb3R0b20gPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgbWFyZ2luLXRvcDogMTAwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMywgbWlubWF4KDAsIDFmcikpO1xyXG4gIGdyaWQtZ2FwOiAyMHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5MzJweCkge1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMiwgbWlubWF4KDAsIDFmcikpO1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDYwMHB4KSB7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgxLCBtaW5tYXgoMCwgMWZyKSk7XHJcbiAgfVxyXG5gO1xyXG5jb25zdCBXcmFwID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBwYWRkaW5nOiAxNXB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA3cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGltZyB7XHJcbiAgICBvYmplY3QtZml0OiBjb250YWluO1xyXG4gICAgbWF4LWhlaWdodDogMjQwcHg7XHJcbiAgfVxyXG4gIGgzIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDI0cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IHsgQ29udGFpbmVyLCBUb3AsIEJvdHRvbSwgV3JhcCB9O1xyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiQ29udGFpbmVyIiwiZGl2IiwiVG9wIiwiQm90dG9tIiwiV3JhcCJdLCJzb3VyY2VSb290IjoiIn0=