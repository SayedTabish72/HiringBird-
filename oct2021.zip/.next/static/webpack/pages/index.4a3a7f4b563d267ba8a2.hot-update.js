"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Hero.styled.js":
/*!***************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Hero.styled.js ***!
  \***************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeroDiv": function() { return /* binding */ HeroDiv; },
/* harmony export */   "HeroContainer": function() { return /* binding */ HeroContainer; },
/* harmony export */   "HeroLeft": function() { return /* binding */ HeroLeft; },
/* harmony export */   "HeroRight": function() { return /* binding */ HeroRight; },
/* harmony export */   "Image": function() { return /* binding */ Image; },
/* harmony export */   "Button": function() { return /* binding */ Button; },
/* harmony export */   "Para": function() { return /* binding */ Para; },
/* harmony export */   "Writer": function() { return /* binding */ Writer; },
/* harmony export */   "Heading": function() { return /* binding */ Heading; },
/* harmony export */   "Head": function() { return /* binding */ Head; },
/* harmony export */   "HeroSearch": function() { return /* binding */ HeroSearch; },
/* harmony export */   "HeroSearchLeft": function() { return /* binding */ HeroSearchLeft; },
/* harmony export */   "HeroSearchRight": function() { return /* binding */ HeroSearchRight; },
/* harmony export */   "Search": function() { return /* binding */ Search; },
/* harmony export */   "Img": function() { return /* binding */ Img; },
/* harmony export */   "SearchImg": function() { return /* binding */ SearchImg; },
/* harmony export */   "SearchIcon": function() { return /* binding */ SearchIcon; },
/* harmony export */   "SearchField": function() { return /* binding */ SearchField; },
/* harmony export */   "Input": function() { return /* binding */ Input; },
/* harmony export */   "ButtonSearch": function() { return /* binding */ ButtonSearch; },
/* harmony export */   "SearchButton": function() { return /* binding */ SearchButton; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var HeroDiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroDiv",
  componentId: "sc-yjfsrr-0"
})(["display:flex;justify-content:space-between;@media (max-width:589px){max-width:1000px;min-width:780px;flex-direction:column;}"]);
var HeroContainer = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroContainer",
  componentId: "sc-yjfsrr-1"
})(["padding-left:40px;padding-right:40px;padding-bottom:20px;background-color:#f5f5f5;@media (max-width:783px){padding-left:25px;padding-right:25px;}@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
var HeroLeft = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroLeft",
  componentId: "sc-yjfsrr-2"
})(["", " height:450px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;", " ", " margin-left:130px;@media (max-width:783px){height:350px;}@media (max-width:1129px){margin-left:50px;}@media (max-width:903px){margin-left:30px;}"], ""
/* height: 65vh; */
, ""
/* align-items: center; */
, ""
/* text-align: center; */
);
var HeroRight = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroRight",
  componentId: "sc-yjfsrr-3"
})(["height:400px;@media (max-width:783px){text-align:center;margin-top:-30px;margin-bottom:-30px;height:min-content;}"]);
var Image = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__Image",
  componentId: "sc-yjfsrr-4"
})(["width:538px;height:100%;@media (max-width:1129px){width:439px;}@media (max-width:783px){width:365px;height:354px;}@media (max-width:392px){width:265px;height:254px;}@media (max-width:954px){width:390px;}"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Herostyled__Button",
  componentId: "sc-yjfsrr-5"
})(["cursor:pointer;background-color:#f26a7e;margin-right:20px;color:#fff;font-size:16px;border:none;padding:10px 26px;border-radius:4px;&:hover{background-color:#fc5b73;transition:all 0.3s ease;}"]);
var Para = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.p.withConfig({
  displayName: "Herostyled__Para",
  componentId: "sc-yjfsrr-6"
})(["width:420px;color:#404366;line-height:25px;font-style:italic;font-weight:500;padding:15px 0;@media (max-width:783px){width:332px;font-weight:500;font-size:14px;line-height:21px;}@media (max-width:392px){width:300px;}@media (max-width:341px){width:280px;}"]);
var Writer = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.span.withConfig({
  displayName: "Herostyled__Writer",
  componentId: "sc-yjfsrr-7"
})(["font-weight:500;"]);
var Heading = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.h1.withConfig({
  displayName: "Herostyled__Heading",
  componentId: "sc-yjfsrr-8"
})(["font-size:45px;color:#404366;margin-bottom:50px;@media (max-width:783px){font-size:36px;margin-bottom:13px;margin-top:0;}@media (max-width:404px){font-size:30px;}"]);
var Head = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.span.withConfig({
  displayName: "Herostyled__Head",
  componentId: "sc-yjfsrr-9"
})(["font-size:51px;font-weight:bold;@media (max-width:783px){font-size:44px;}@media (max-width:404px){font-size:36px;}"]);
var HeroSearch = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearch",
  componentId: "sc-yjfsrr-10"
})(["display:flex;margin-left:40px;margin-right:170px;margin-bottom:40px;@media (max-width:783px){margin-left:0px;margin-right:0px;}"]);
var HeroSearchLeft = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearchLeft",
  componentId: "sc-yjfsrr-11"
})(["background-color:#f9bfc2;padding:10px 9px;border-radius:50%;margin-right:60px;@media (max-width:783px){margin-right:0px;position:absolute;right:10px;top:50%;box-shadow:rgba(242,106,126,0.25) 0px 54px 55px,rgba(242,106,126,0.12) 0px -12px 30px,rgba(242,106,126,0.12) 0px 4px 6px,rgba(242,106,126,0.17) 0px 9px 13px,rgba(242,106,126,0.09) 0px -3px 5px;}"]);
var HeroSearchRight = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearchRight",
  componentId: "sc-yjfsrr-12"
})(["border:1px solid #c9cbe2;border-radius:4px;height:45px;margin-top:5px;flex:1;"]);
var Search = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__Search",
  componentId: "sc-yjfsrr-13"
})(["display:flex;align-items:center;height:100%;justify-content:flex-start;background-color:#fff;border-radius:4px;@media (max-width:589px){max-width:800px;min-width:780px;margin-left:35px;}"]);
var Img = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__Img",
  componentId: "sc-yjfsrr-14"
})(["width:34px;height:25px;"]);
var SearchImg = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__SearchImg",
  componentId: "sc-yjfsrr-15"
})(["width:34px;height:25px;@media (max-width:783px){width:24px;height:16px;color:#f26a7e;}"]);
var SearchIcon = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchIcon",
  componentId: "sc-yjfsrr-16"
})(["margin-left:40px;margin-right:40px;background-color:#fff;@media (max-width:783px){margin-left:0;margin-right:5px;}"]);
var SearchField = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchField",
  componentId: "sc-yjfsrr-17"
})(["width:100%;"]);
var Input = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.input.withConfig({
  displayName: "Herostyled__Input",
  componentId: "sc-yjfsrr-18"
})(["border:none;outline:none;width:100%;padding:10px 0;color:#404366;font-size:16px;font-weight:400;&::placeholder{color:#c9cbe2;font-size:16px;font-weight:400;}@media (max-width:783px){&::placeholder{font-size:13px;}}"]);
var ButtonSearch = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Herostyled__ButtonSearch",
  componentId: "sc-yjfsrr-19"
})(["cursor:pointer;background-color:#404366;margin-right:20px;color:#fff;font-size:16px;width:100%;border:none;padding:13px 38px;border-radius:4px;&:hover{background-color:#404355;transition:all 0.3s ease;}@media (max-width:783px){margin-right:0;font-size:14px;padding:14px 30px;}"]);
var SearchButton = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchButton",
  componentId: "sc-yjfsrr-20"
})([""]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNGEzYTdmNGI1NjNkMjY3YmE4YTIuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRU8sSUFBTUMsT0FBTyxHQUFHRCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxvSUFBYjtBQWFBLElBQU1HLGFBQWEsR0FBR0gscUVBQUg7QUFBQTtBQUFBO0FBQUEsb05BQW5CO0FBaUJBLElBQU1JLFFBQVEsR0FBR0oscUVBQUg7QUFBQTtBQUFBO0FBQUEsc1FBQ2pCO0FBQUc7QUFEYyxFQU9qQjtBQUFHO0FBUGMsRUFRakI7QUFBRztBQVJjLENBQWQ7QUFxQkEsSUFBTUssU0FBUyxHQUFHTCxxRUFBSDtBQUFBO0FBQUE7QUFBQSx5SEFBZjtBQVdBLElBQU1NLEtBQUssR0FBR04scUVBQUg7QUFBQTtBQUFBO0FBQUEsbU5BQVg7QUFtQkEsSUFBTVEsTUFBTSxHQUFHUix3RUFBSDtBQUFBO0FBQUE7QUFBQSx1TUFBWjtBQWVBLElBQU1VLElBQUksR0FBR1YsbUVBQUg7QUFBQTtBQUFBO0FBQUEsc1FBQVY7QUFxQkEsSUFBTVksTUFBTSxHQUFHWixzRUFBSDtBQUFBO0FBQUE7QUFBQSx3QkFBWjtBQUlBLElBQU1jLE9BQU8sR0FBR2Qsb0VBQUg7QUFBQTtBQUFBO0FBQUEsMEtBQWI7QUFlQSxJQUFNZ0IsSUFBSSxHQUFHaEIsc0VBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQVY7QUFZQSxJQUFNaUIsVUFBVSxHQUFHakIscUVBQUg7QUFBQTtBQUFBO0FBQUEsdUlBQWhCO0FBV0EsSUFBTWtCLGNBQWMsR0FBR2xCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLHVXQUFwQjtBQWtCQSxJQUFNbUIsZUFBZSxHQUFHbkIscUVBQUg7QUFBQTtBQUFBO0FBQUEscUZBQXJCO0FBUUEsSUFBTW9CLE1BQU0sR0FBR3BCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGtNQUFaO0FBY0EsSUFBTXFCLEdBQUcsR0FBR3JCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLCtCQUFUO0FBS0EsSUFBTXNCLFNBQVMsR0FBR3RCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDhGQUFmO0FBVUEsSUFBTXVCLFVBQVUsR0FBR3ZCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDBIQUFoQjtBQVVBLElBQU13QixXQUFXLEdBQUd4QixxRUFBSDtBQUFBO0FBQUE7QUFBQSxtQkFBakI7QUFJQSxJQUFNeUIsS0FBSyxHQUFHekIsdUVBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVg7QUFvQkEsSUFBTTJCLFlBQVksR0FBRzNCLHdFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFsQjtBQXFCQSxJQUFNNEIsWUFBWSxHQUFHNUIscUVBQUg7QUFBQTtBQUFBO0FBQUEsUUFBbEIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvSGVyby5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvRGl2ID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAvLyBAbWVkaWEgKG1heC13aWR0aDogODY2cHgpIHtcclxuICAvLyAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgLy8gfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb0NvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgcGFkZGluZy1sZWZ0OiA0MHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDQwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI1cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNXB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIG1heC13aWR0aDogMTAwMHB4O1xyXG4gICAgbWluLXdpZHRoOiA3ODBweDtcclxuICB9XHJcblxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9MZWZ0ID0gc3R5bGVkLmRpdmBcclxuICAke1wiXCIgLyogaGVpZ2h0OiA2NXZoOyAqL31cclxuICBoZWlnaHQ6IDQ1MHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAke1wiXCIgLyogYWxpZ24taXRlbXM6IGNlbnRlcjsgKi99XHJcbiAgJHtcIlwiIC8qIHRleHQtYWxpZ246IGNlbnRlcjsgKi99XHJcbiAgICBtYXJnaW4tbGVmdDogMTMwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBoZWlnaHQ6IDM1MHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMTEyOXB4KSB7XHJcbiAgICBtYXJnaW4tbGVmdDogNTBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDkwM3B4KSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMzBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb1JpZ2h0ID0gc3R5bGVkLmRpdmBcclxuICBoZWlnaHQ6IDQwMHB4O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IC0zMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTMwcHg7XHJcbiAgICBoZWlnaHQ6IG1pbi1jb250ZW50O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbWFnZSA9IHN0eWxlZC5pbWdgXHJcbiAgd2lkdGg6IDUzOHB4O1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogMTEyOXB4KSB7XHJcbiAgICB3aWR0aDogNDM5cHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgd2lkdGg6IDM2NXB4O1xyXG4gICAgaGVpZ2h0OiAzNTRweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDM5MnB4KSB7XHJcbiAgICB3aWR0aDogMjY1cHg7XHJcbiAgICBoZWlnaHQ6IDI1NHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogOTU0cHgpIHtcclxuICAgIHdpZHRoOiAzOTBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2YyNmE3ZTtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBwYWRkaW5nOiAxMHB4IDI2cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZjNWI3MztcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFBhcmEgPSBzdHlsZWQucGBcclxuICB3aWR0aDogNDIwcHg7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgbGluZS1oZWlnaHQ6IDI1cHg7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgcGFkZGluZzogMTVweCAwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgd2lkdGg6IDMzMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMXB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogMzkycHgpIHtcclxuICAgIHdpZHRoOiAzMDBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDM0MXB4KSB7XHJcbiAgICB3aWR0aDogMjgwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFdyaXRlciA9IHN0eWxlZC5zcGFuYFxyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVhZGluZyA9IHN0eWxlZC5oMWBcclxuICBmb250LXNpemU6IDQ1cHg7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBmb250LXNpemU6IDM2cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxM3B4O1xyXG4gICAgbWFyZ2luLXRvcDogMDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDQwNHB4KSB7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlYWQgPSBzdHlsZWQuc3BhbmBcclxuICBmb250LXNpemU6IDUxcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgZm9udC1zaXplOiA0NHB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNDA0cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMzZweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb1NlYXJjaCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBtYXJnaW4tbGVmdDogNDBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDE3MHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9TZWFyY2hMZWZ0ID0gc3R5bGVkLmRpdmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjliZmMyO1xyXG4gIHBhZGRpbmc6IDEwcHggOXB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBtYXJnaW4tcmlnaHQ6IDYwcHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxMHB4O1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBib3gtc2hhZG93OiByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuMjUpIDBweCA1NHB4IDU1cHgsXHJcbiAgICAgIHJnYmEoMjQyLCAxMDYsIDEyNiwgMC4xMikgMHB4IC0xMnB4IDMwcHgsXHJcbiAgICAgIHJnYmEoMjQyLCAxMDYsIDEyNiwgMC4xMikgMHB4IDRweCA2cHgsXHJcbiAgICAgIHJnYmEoMjQyLCAxMDYsIDEyNiwgMC4xNykgMHB4IDlweCAxM3B4LFxyXG4gICAgICByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuMDkpIDBweCAtM3B4IDVweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb1NlYXJjaFJpZ2h0ID0gc3R5bGVkLmRpdmBcclxuICBib3JkZXI6IDFweCBzb2xpZCAjYzljYmUyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBoZWlnaHQ6IDQ1cHg7XHJcbiAgbWFyZ2luLXRvcDogNXB4O1xyXG4gIGZsZXg6IDE7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU2VhcmNoID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIG1heC13aWR0aDogODAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDM1cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEltZyA9IHN0eWxlZC5pbWdgXHJcbiAgd2lkdGg6IDM0cHg7XHJcbiAgaGVpZ2h0OiAyNXB4O1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEltZyA9IHN0eWxlZC5pbWdgXHJcbiAgd2lkdGg6IDM0cHg7XHJcbiAgaGVpZ2h0OiAyNXB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgd2lkdGg6IDI0cHg7XHJcbiAgICBoZWlnaHQ6IDE2cHg7XHJcbiAgICBjb2xvcjogI2YyNmE3ZTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU2VhcmNoSWNvbiA9IHN0eWxlZC5kaXZgXHJcbiAgbWFyZ2luLWxlZnQ6IDQwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiA0MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTZWFyY2hGaWVsZCA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDEwMCU7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW5wdXQgPSBzdHlsZWQuaW5wdXRgXHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gICY6OnBsYWNlaG9sZGVyIHtcclxuICAgIGNvbG9yOiAjYzljYmUyO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICAmOjpwbGFjZWhvbGRlciB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQnV0dG9uU2VhcmNoID0gc3R5bGVkLmJ1dHRvbmBcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQwNDM2NjtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBwYWRkaW5nOiAxM3B4IDM4cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzQwNDM1NTtcclxuICAgIHRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2U7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgcGFkZGluZzogMTRweCAzMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTZWFyY2hCdXR0b24gPSBzdHlsZWQuZGl2YGA7XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJIZXJvRGl2IiwiZGl2IiwiSGVyb0NvbnRhaW5lciIsIkhlcm9MZWZ0IiwiSGVyb1JpZ2h0IiwiSW1hZ2UiLCJpbWciLCJCdXR0b24iLCJidXR0b24iLCJQYXJhIiwicCIsIldyaXRlciIsInNwYW4iLCJIZWFkaW5nIiwiaDEiLCJIZWFkIiwiSGVyb1NlYXJjaCIsIkhlcm9TZWFyY2hMZWZ0IiwiSGVyb1NlYXJjaFJpZ2h0IiwiU2VhcmNoIiwiSW1nIiwiU2VhcmNoSW1nIiwiU2VhcmNoSWNvbiIsIlNlYXJjaEZpZWxkIiwiSW5wdXQiLCJpbnB1dCIsIkJ1dHRvblNlYXJjaCIsIlNlYXJjaEJ1dHRvbiJdLCJzb3VyY2VSb290IjoiIn0=