"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Locations.styled.js":
/*!********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Locations.styled.js ***!
  \********************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": function() { return /* binding */ Container; },
/* harmony export */   "Divstart": function() { return /* binding */ Divstart; },
/* harmony export */   "Innerdiv1": function() { return /* binding */ Innerdiv1; },
/* harmony export */   "Innerdiv2": function() { return /* binding */ Innerdiv2; },
/* harmony export */   "Span50": function() { return /* binding */ Span50; },
/* harmony export */   "Span1": function() { return /* binding */ Span1; },
/* harmony export */   "Spanright": function() { return /* binding */ Spanright; },
/* harmony export */   "Spanright2": function() { return /* binding */ Spanright2; },
/* harmony export */   "Lowerdiv": function() { return /* binding */ Lowerdiv; },
/* harmony export */   "Categorycard": function() { return /* binding */ Categorycard; },
/* harmony export */   "Categorycard1": function() { return /* binding */ Categorycard1; },
/* harmony export */   "Logo": function() { return /* binding */ Logo; },
/* harmony export */   "Button": function() { return /* binding */ Button; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Container",
  componentId: "sc-1w9848a-0"
})(["width:100%;margin-top:100px;margin-bottom:80px;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
var Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Divstart",
  componentId: "sc-1w9848a-1"
})(["display:flex;justify-content:space-between;flex-wrap:wrap;width:80%;@media (max-width:589px){flex-direction:column;}"]);
var Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Innerdiv1",
  componentId: "sc-1w9848a-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
var Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Innerdiv2",
  componentId: "sc-1w9848a-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
var Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Span50",
  componentId: "sc-1w9848a-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
var Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Span1",
  componentId: "sc-1w9848a-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
var Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Spanright",
  componentId: "sc-1w9848a-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
var Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Spanright2",
  componentId: "sc-1w9848a-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
var Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Lowerdiv",
  componentId: "sc-1w9848a-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
var Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Categorycard",
  componentId: "sc-1w9848a-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Locationsstyled__Categorycard1",
  componentId: "sc-1w9848a-10"
})(["width:174px;background-color:#fff8f8;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Logo = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Locationsstyled__Logo",
  componentId: "sc-1w9848a-11"
})(["width:30px;height:30px;"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Locationsstyled__Button",
  componentId: "sc-1w9848a-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguODVkZDZiNWFhYzNiYTg4YWU5MjcuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVPLElBQU1DLFNBQVMsR0FBR0QscUVBQUg7QUFBQTtBQUFBO0FBQUEscU5BQWY7QUFnQkEsSUFBTUcsUUFBUSxHQUFHSCxxRUFBSDtBQUFBO0FBQUE7QUFBQSw0SEFBZDtBQVVBLElBQU1JLFNBQVMsR0FBR0oscUVBQUg7QUFBQTtBQUFBO0FBQUEsd0NBQWY7QUFJQSxJQUFNSyxTQUFTLEdBQUdMLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGtEQUFmO0FBTUEsSUFBTU0sTUFBTSxHQUFHTixxRUFBSDtBQUFBO0FBQUE7QUFBQSxnTUFBWjtBQWFBLElBQU1PLEtBQUssR0FBR1AscUVBQUg7QUFBQTtBQUFBO0FBQUEsNk9BQVg7QUFpQkEsSUFBTVEsU0FBUyxHQUFHUixxRUFBSDtBQUFBO0FBQUE7QUFBQSw0UkFBZjtBQW1CQSxJQUFNUyxVQUFVLEdBQUdULHFFQUFIO0FBQUE7QUFBQTtBQUFBLGtTQUFoQjtBQXFCQSxJQUFNVSxRQUFRLEdBQUdWLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDBMQUFkO0FBZ0JBLElBQU1XLFlBQVksR0FBR1gscUVBQUg7QUFBQTtBQUFBO0FBQUEsa1pBQWxCO0FBMkJBLElBQU1ZLGFBQWEsR0FBR1oscUVBQUg7QUFBQTtBQUFBO0FBQUEsMmFBQW5CO0FBNkJBLElBQU1hLElBQUksR0FBR2IscUVBQUg7QUFBQTtBQUFBO0FBQUEsK0JBQVY7QUFLQSxJQUFNZSxNQUFNLEdBQUdmLHdFQUFIO0FBQUE7QUFBQTtBQUFBLDhOQUFaIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2NvbXBvbmVudHMvaG9tZXBhZ2UvcGFydHMvc3R5bGVzL0xvY2F0aW9ucy5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIG1hcmdpbi10b3A6IDEwMHB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDgwcHg7XHJcbiAgcGFkZGluZzogMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IERpdnN0YXJ0ID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uIDogY29sdW1uO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbm5lcmRpdjEgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IFwiZmxleFwiO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuYDtcclxuZXhwb3J0IGNvbnN0IElubmVyZGl2MiA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogXCJmbGV4XCI7XHJcbiAgd2lkdGg6IDUwJTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU3BhbjUwID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuYDtcclxuZXhwb3J0IGNvbnN0IFNwYW4xID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDM2cHg7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcblxyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuXHJcbiAgY29sb3I6ICMxODE5MWY7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjFweDtcclxuICAgIHdpZHRoOiAzNzBweDtcclxuICAgIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICAgIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQyID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcblxyXG4gIGNvbG9yOiAjMTgxOTFmO1xyXG4gIHdpZHRoOiBmaXQtY29udGVudDtcclxuICBtYXJnaW4tdG9wOiA2JTtcclxuICBib3JkZXItYm90dG9tOiAxLjc2cHggc29saWQgIzE4MTkxZjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiAxNzBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTG93ZXJkaXYgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgaGVpZ2h0OiA3MCU7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBtYXJnaW4tdG9wOiA0JTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDM4MXB4KSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tbGVmdDogMzVweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTc0cHg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICAgIGJhY2tkcm9wLWZpbHRlcjogYmx1cig0MHB4KTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgaGVpZ2h0OiAxNDBweDtcclxuICAgIGZsZXg6IDAgMCAxNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkMSA9IHN0eWxlZC5kaXZgXHJcbiAgd2lkdGg6IDE3NHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY4Zjg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcblxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuICAmOmhvdmVyIHtcclxuICAgIGJveC1zaGFkb3c6IDBweCA4cHggMjRweCByZ2JhKDIxNiwgMjE2LCAyMTYsIDAuMyk7XHJcbiAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIHdpZHRoOiAxNDBweDtcclxuICAgIGhlaWdodDogMTQwcHg7XHJcbiAgICBmbGV4OiAwIDAgMTQwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmMjZhN2U7XHJcbiAgYmFja2dyb3VuZDogbm9uZTtcclxuXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogMTlweDtcclxuXHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuXHJcbiAgbWFyZ2luOiAwcHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogI2YyNmE3ZTtcclxuICB9XHJcbmA7XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJDb250YWluZXIiLCJkaXYiLCJEaXZzdGFydCIsIklubmVyZGl2MSIsIklubmVyZGl2MiIsIlNwYW41MCIsIlNwYW4xIiwiU3BhbnJpZ2h0IiwiU3BhbnJpZ2h0MiIsIkxvd2VyZGl2IiwiQ2F0ZWdvcnljYXJkIiwiQ2F0ZWdvcnljYXJkMSIsIkxvZ28iLCJpbWciLCJCdXR0b24iLCJidXR0b24iXSwic291cmNlUm9vdCI6IiJ9