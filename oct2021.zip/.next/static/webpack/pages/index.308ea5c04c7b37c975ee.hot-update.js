"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Categories.styled.js":
/*!*********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Categories.styled.js ***!
  \*********************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": function() { return /* binding */ Container; },
/* harmony export */   "Divstart": function() { return /* binding */ Divstart; },
/* harmony export */   "Innerdiv1": function() { return /* binding */ Innerdiv1; },
/* harmony export */   "Innerdiv2": function() { return /* binding */ Innerdiv2; },
/* harmony export */   "Span50": function() { return /* binding */ Span50; },
/* harmony export */   "Span1": function() { return /* binding */ Span1; },
/* harmony export */   "Spanright": function() { return /* binding */ Spanright; },
/* harmony export */   "Spanright2": function() { return /* binding */ Spanright2; },
/* harmony export */   "Lowerdiv": function() { return /* binding */ Lowerdiv; },
/* harmony export */   "Categorycard": function() { return /* binding */ Categorycard; },
/* harmony export */   "Categorycard1": function() { return /* binding */ Categorycard1; },
/* harmony export */   "Logo": function() { return /* binding */ Logo; },
/* harmony export */   "Button": function() { return /* binding */ Button; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Container",
  componentId: "sc-1tyy3ex-0"
})(["width:100%;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;margin-top:40px;}"]);
var Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Divstart",
  componentId: "sc-1tyy3ex-1"
})(["display:flex;justify-content:space-between;flex-wrap:wrap;width:80%;@media (max-width:589px){flex-direction:column;}"]);
var Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv1",
  componentId: "sc-1tyy3ex-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
var Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv2",
  componentId: "sc-1tyy3ex-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
var Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span50",
  componentId: "sc-1tyy3ex-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
var Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span1",
  componentId: "sc-1tyy3ex-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
var Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright",
  componentId: "sc-1tyy3ex-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
var Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright2",
  componentId: "sc-1tyy3ex-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
var Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Lowerdiv",
  componentId: "sc-1tyy3ex-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
var Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard",
  componentId: "sc-1tyy3ex-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard1",
  componentId: "sc-1tyy3ex-10"
})(["width:174px;height:13em;border:0px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Logo = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Categoriesstyled__Logo",
  componentId: "sc-1tyy3ex-11"
})(["width:30px;height:30px;"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Categoriesstyled__Button",
  componentId: "sc-1tyy3ex-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMzA4ZWE1YzA0YzdiMzdjOTc1ZWUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVPLElBQU1DLFNBQVMsR0FBR0QscUVBQUg7QUFBQTtBQUFBO0FBQUEsaU1BQWY7QUFlQSxJQUFNRyxRQUFRLEdBQUdILHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRIQUFkO0FBV0EsSUFBTUksU0FBUyxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSx3Q0FBZjtBQUlBLElBQU1LLFNBQVMsR0FBR0wscUVBQUg7QUFBQTtBQUFBO0FBQUEsa0RBQWY7QUFNQSxJQUFNTSxNQUFNLEdBQUdOLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGdNQUFaO0FBYUEsSUFBTU8sS0FBSyxHQUFHUCxxRUFBSDtBQUFBO0FBQUE7QUFBQSw2T0FBWDtBQWlCQSxJQUFNUSxTQUFTLEdBQUdSLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFmO0FBbUJBLElBQU1TLFVBQVUsR0FBR1QscUVBQUg7QUFBQTtBQUFBO0FBQUEsa1NBQWhCO0FBcUJBLElBQU1VLFFBQVEsR0FBR1YscUVBQUg7QUFBQTtBQUFBO0FBQUEsMExBQWQ7QUFpQkEsSUFBTVcsWUFBWSxHQUFHWCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbEI7QUEyQkEsSUFBTVksYUFBYSxHQUFHWixxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbkI7QUE2QkEsSUFBTWEsSUFBSSxHQUFHYixxRUFBSDtBQUFBO0FBQUE7QUFBQSwrQkFBVjtBQUtBLElBQU1lLE1BQU0sR0FBR2Ysd0VBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVoiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvQ2F0ZWdvcmllcy5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgRGl2c3RhcnQgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgLy8gYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjpjb2x1bW47XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IElubmVyZGl2MSA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogXCJmbGV4XCI7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG5gO1xyXG5leHBvcnQgY29uc3QgSW5uZXJkaXYyID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBcImZsZXhcIjtcclxuICB3aWR0aDogNTAlO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFuNTAgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBmb250LXNpemU6IDcycHg7XHJcbiAgbGluZS1oZWlnaHQ6IDk4cHg7XHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgfVxyXG5gO1xyXG5leHBvcnQgY29uc3QgU3BhbjEgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBmb250LXNpemU6IDcycHg7XHJcbiAgbGluZS1oZWlnaHQ6IDk4cHg7XHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzZweDtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNwYW5yaWdodCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsaW5lLWhlaWdodDogMzJweDtcclxuXHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG5cclxuICBjb2xvcjogIzE4MTkxZjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMXB4O1xyXG4gICAgd2lkdGg6IDM3MHB4O1xyXG4gICAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNwYW5yaWdodDIgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcblxyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuXHJcbiAgY29sb3I6ICMxODE5MWY7XHJcbiAgd2lkdGg6IGZpdC1jb250ZW50O1xyXG4gIG1hcmdpbi10b3A6IDYlO1xyXG4gIGJvcmRlci1ib3R0b206IDEuNzZweCBzb2xpZCAjMTgxOTFmO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZvbnQtc2l6ZTogMTdweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNHB4O1xyXG4gICAgd2lkdGg6IDE3MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMb3dlcmRpdiA9IHN0eWxlZC5kaXZgXHJcbmRpc3BsYXk6IGZsZXg7XHJcbmhlaWdodDogNzAlO1xyXG53aWR0aDogODAlO1xyXG5mbGV4LXdyYXA6IHdyYXA7XHJcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5tYXJnaW4tdG9wOiA0JTtcclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiAzODFweCkge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLWxlZnQ6IDM1cHg7XHJcbn0gIFxyXG5cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBDYXRlZ29yeWNhcmQgPSBzdHlsZWQuZGl2YFxyXG53aWR0aDogMTc0cHg7XHJcbiAgaGVpZ2h0OiAxM2VtO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgZmxleDogMCAwIDE0ZW07XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICAgIGJhY2tkcm9wLWZpbHRlcjogYmx1cig0MHB4KTtcclxuICB9XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgd2lkdGg6IDE0MHB4O1xyXG4gICAgaGVpZ2h0OiAxNDBweDtcclxuICAgIGZsZXg6IDAgMCAxNDBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkMSA9IHN0eWxlZC5kaXZgXHJcbndpZHRoOiAxNzRweDtcclxuXHJcbmhlaWdodDogMTNlbTtcclxuYm9yZGVyOiAwcHggc29saWQgcmdiYSg3NSwgNzUsIDc1LCAwLjMpO1xyXG5ib3JkZXItcmFkaXVzOiA4cHg7XHJcbmZsZXg6IDAgMCAxNGVtO1xyXG5tYXJnaW4tdG9wOiAyJTtcclxuYm94LXNpemluZzogYm9yZGVyLWJveDtcclxubWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5tYXJnaW4tbGVmdDogMTBweDtcclxuXHJcbmRpc3BsYXk6IGZsZXg7XHJcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG5mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuJjpob3ZlciB7XHJcbiAgYm94LXNoYWRvdzogMHB4IDhweCAyNHB4IHJnYmEoMjE2LCAyMTYsIDIxNiwgMC4zKTtcclxuICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XHJcbn1cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gIHdpZHRoOiAxNDBweDtcclxuICBoZWlnaHQ6IDE0MHB4O1xyXG4gIGZsZXg6IDAgMCAxNDBweDtcclxufVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAzMHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b24gPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmMjZhN2U7XHJcbiAgYmFja2dyb3VuZDogbm9uZTtcclxuXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogMTlweDtcclxuXHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuXHJcbiAgbWFyZ2luOiAwcHggMTBweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcblxyXG4gICY6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogI2YyNmE3ZTtcclxuICB9XHJcbmA7XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJDb250YWluZXIiLCJkaXYiLCJEaXZzdGFydCIsIklubmVyZGl2MSIsIklubmVyZGl2MiIsIlNwYW41MCIsIlNwYW4xIiwiU3BhbnJpZ2h0IiwiU3BhbnJpZ2h0MiIsIkxvd2VyZGl2IiwiQ2F0ZWdvcnljYXJkIiwiQ2F0ZWdvcnljYXJkMSIsIkxvZ28iLCJpbWciLCJCdXR0b24iLCJidXR0b24iXSwic291cmNlUm9vdCI6IiJ9