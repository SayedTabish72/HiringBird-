"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Categories.styled.js":
/*!*********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Categories.styled.js ***!
  \*********************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": function() { return /* binding */ Container; },
/* harmony export */   "Divstart": function() { return /* binding */ Divstart; },
/* harmony export */   "Innerdiv1": function() { return /* binding */ Innerdiv1; },
/* harmony export */   "Innerdiv2": function() { return /* binding */ Innerdiv2; },
/* harmony export */   "Span50": function() { return /* binding */ Span50; },
/* harmony export */   "Span1": function() { return /* binding */ Span1; },
/* harmony export */   "Spanright": function() { return /* binding */ Spanright; },
/* harmony export */   "Spanright2": function() { return /* binding */ Spanright2; },
/* harmony export */   "Lowerdiv": function() { return /* binding */ Lowerdiv; },
/* harmony export */   "Categorycard": function() { return /* binding */ Categorycard; },
/* harmony export */   "Categorycard1": function() { return /* binding */ Categorycard1; },
/* harmony export */   "Logo": function() { return /* binding */ Logo; },
/* harmony export */   "Button": function() { return /* binding */ Button; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Container",
  componentId: "sc-1tyy3ex-0"
})(["width:100%;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
var Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Divstart",
  componentId: "sc-1tyy3ex-1"
})(["display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;width:80%;"]);
var Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv1",
  componentId: "sc-1tyy3ex-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
var Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv2",
  componentId: "sc-1tyy3ex-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
var Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span50",
  componentId: "sc-1tyy3ex-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
var Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span1",
  componentId: "sc-1tyy3ex-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
var Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright",
  componentId: "sc-1tyy3ex-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
var Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright2",
  componentId: "sc-1tyy3ex-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
var Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Lowerdiv",
  componentId: "sc-1tyy3ex-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
var Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard",
  componentId: "sc-1tyy3ex-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard1",
  componentId: "sc-1tyy3ex-10"
})(["width:174px;height:13em;border:0px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Logo = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Categoriesstyled__Logo",
  componentId: "sc-1tyy3ex-11"
})(["width:30px;height:30px;"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Categoriesstyled__Button",
  componentId: "sc-1tyy3ex-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMTI5NjJlNTlkMThjODg4YjBmNDkuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVPLElBQU1DLFNBQVMsR0FBR0QscUVBQUg7QUFBQTtBQUFBO0FBQUEsaUxBQWY7QUFjQSxJQUFNRyxRQUFRLEdBQUdILHFFQUFIO0FBQUE7QUFBQTtBQUFBLCtGQUFkO0FBUUEsSUFBTUksU0FBUyxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSx3Q0FBZjtBQUlBLElBQU1LLFNBQVMsR0FBR0wscUVBQUg7QUFBQTtBQUFBO0FBQUEsa0RBQWY7QUFNQSxJQUFNTSxNQUFNLEdBQUdOLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGdNQUFaO0FBYUEsSUFBTU8sS0FBSyxHQUFHUCxxRUFBSDtBQUFBO0FBQUE7QUFBQSw2T0FBWDtBQWlCQSxJQUFNUSxTQUFTLEdBQUdSLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFmO0FBbUJBLElBQU1TLFVBQVUsR0FBR1QscUVBQUg7QUFBQTtBQUFBO0FBQUEsa1NBQWhCO0FBcUJBLElBQU1VLFFBQVEsR0FBR1YscUVBQUg7QUFBQTtBQUFBO0FBQUEsMExBQWQ7QUFpQkEsSUFBTVcsWUFBWSxHQUFHWCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbEI7QUEyQkEsSUFBTVksYUFBYSxHQUFHWixxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbkI7QUE2QkEsSUFBTWEsSUFBSSxHQUFHYixxRUFBSDtBQUFBO0FBQUE7QUFBQSwrQkFBVjtBQUtBLElBQU1lLE1BQU0sR0FBR2Ysd0VBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVoiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvQ2F0ZWdvcmllcy5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBEaXZzdGFydCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgd2lkdGg6IDgwJTtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbm5lcmRpdjEgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IFwiZmxleFwiO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxuYDtcclxuZXhwb3J0IGNvbnN0IElubmVyZGl2MiA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogXCJmbGV4XCI7XHJcbiAgd2lkdGg6IDUwJTtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU3BhbjUwID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuYDtcclxuZXhwb3J0IGNvbnN0IFNwYW4xID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgZm9udC1zaXplOiA3MnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA5OHB4O1xyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICBjb2xvcjogIzQwNDM2NjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDM2cHg7XHJcbiAgICB3aWR0aDogNTAlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQgPSBzdHlsZWQuZGl2YFxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDMycHg7XHJcblxyXG4gIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuXHJcbiAgY29sb3I6ICMxODE5MWY7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjFweDtcclxuICAgIHdpZHRoOiAzNzBweDtcclxuICAgIGZvbnQtZmVhdHVyZS1zZXR0aW5nczogXCJzYWx0XCIgb24sIFwibGlnYVwiIG9mZjtcclxuICAgIG1hcmdpbi10b3A6IDUlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTcGFucmlnaHQyID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcblxyXG4gIGNvbG9yOiAjMTgxOTFmO1xyXG4gIHdpZHRoOiBmaXQtY29udGVudDtcclxuICBtYXJnaW4tdG9wOiA2JTtcclxuICBib3JkZXItYm90dG9tOiAxLjc2cHggc29saWQgIzE4MTkxZjtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjRweDtcclxuICAgIHdpZHRoOiAxNzBweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTG93ZXJkaXYgPSBzdHlsZWQuZGl2YFxyXG5kaXNwbGF5OiBmbGV4O1xyXG5oZWlnaHQ6IDcwJTtcclxud2lkdGg6IDgwJTtcclxuZmxleC13cmFwOiB3cmFwO1xyXG5hbGlnbi1pdGVtczogY2VudGVyO1xyXG5qdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxubWFyZ2luLXRvcDogNCU7XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogMzgxcHgpIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIG1hcmdpbi1sZWZ0OiAzNXB4O1xyXG59ICBcclxuXHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQ2F0ZWdvcnljYXJkID0gc3R5bGVkLmRpdmBcclxud2lkdGg6IDE3NHB4O1xyXG4gIGhlaWdodDogMTNlbTtcclxuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDc1LCA3NSwgNzUsIDAuMyk7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIGZsZXg6IDAgMCAxNGVtO1xyXG4gIG1hcmdpbi10b3A6IDIlO1xyXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuICAmOmhvdmVyIHtcclxuICAgIGJveC1zaGFkb3c6IDBweCA4cHggMjRweCByZ2JhKDIxNiwgMjE2LCAyMTYsIDAuMyk7XHJcbiAgICBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNDBweCk7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIHdpZHRoOiAxNDBweDtcclxuICAgIGhlaWdodDogMTQwcHg7XHJcbiAgICBmbGV4OiAwIDAgMTQwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IENhdGVnb3J5Y2FyZDEgPSBzdHlsZWQuZGl2YFxyXG53aWR0aDogMTc0cHg7XHJcblxyXG5oZWlnaHQ6IDEzZW07XHJcbmJvcmRlcjogMHB4IHNvbGlkIHJnYmEoNzUsIDc1LCA3NSwgMC4zKTtcclxuYm9yZGVyLXJhZGl1czogOHB4O1xyXG5mbGV4OiAwIDAgMTRlbTtcclxubWFyZ2luLXRvcDogMiU7XHJcbmJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbm1hcmdpbi1yaWdodDogMTBweDtcclxubWFyZ2luLWxlZnQ6IDEwcHg7XHJcblxyXG5kaXNwbGF5OiBmbGV4O1xyXG5hbGlnbi1pdGVtczogY2VudGVyO1xyXG5qdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcclxuZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiY6aG92ZXIge1xyXG4gIGJveC1zaGFkb3c6IDBweCA4cHggMjRweCByZ2JhKDIxNiwgMjE2LCAyMTYsIDAuMyk7XHJcbiAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKDQwcHgpO1xyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICB3aWR0aDogMTQwcHg7XHJcbiAgaGVpZ2h0OiAxNDBweDtcclxuICBmbGV4OiAwIDAgMTQwcHg7XHJcbn1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dvID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgQnV0dG9uID0gc3R5bGVkLmJ1dHRvbmBcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZjI2YTdlO1xyXG4gIGJhY2tncm91bmQ6IG5vbmU7XHJcblxyXG4gIGZvbnQtZmFtaWx5OiBJbnRlcjtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDE5cHg7XHJcblxyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcblxyXG4gIG1hcmdpbjogMHB4IDEwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG5cclxuICAmOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICNmMjZhN2U7XHJcbiAgfVxyXG5gO1xyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiQ29udGFpbmVyIiwiZGl2IiwiRGl2c3RhcnQiLCJJbm5lcmRpdjEiLCJJbm5lcmRpdjIiLCJTcGFuNTAiLCJTcGFuMSIsIlNwYW5yaWdodCIsIlNwYW5yaWdodDIiLCJMb3dlcmRpdiIsIkNhdGVnb3J5Y2FyZCIsIkNhdGVnb3J5Y2FyZDEiLCJMb2dvIiwiaW1nIiwiQnV0dG9uIiwiYnV0dG9uIl0sInNvdXJjZVJvb3QiOiIifQ==