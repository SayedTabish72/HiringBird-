"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Hero.styled.js":
/*!***************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Hero.styled.js ***!
  \***************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeroDiv": function() { return /* binding */ HeroDiv; },
/* harmony export */   "HeroContainer": function() { return /* binding */ HeroContainer; },
/* harmony export */   "HeroLeft": function() { return /* binding */ HeroLeft; },
/* harmony export */   "HeroRight": function() { return /* binding */ HeroRight; },
/* harmony export */   "Image": function() { return /* binding */ Image; },
/* harmony export */   "Button": function() { return /* binding */ Button; },
/* harmony export */   "Para": function() { return /* binding */ Para; },
/* harmony export */   "Writer": function() { return /* binding */ Writer; },
/* harmony export */   "Heading": function() { return /* binding */ Heading; },
/* harmony export */   "Head": function() { return /* binding */ Head; },
/* harmony export */   "HeroSearch": function() { return /* binding */ HeroSearch; },
/* harmony export */   "HeroSearchLeft": function() { return /* binding */ HeroSearchLeft; },
/* harmony export */   "HeroSearchRight": function() { return /* binding */ HeroSearchRight; },
/* harmony export */   "Search": function() { return /* binding */ Search; },
/* harmony export */   "Img": function() { return /* binding */ Img; },
/* harmony export */   "SearchImg": function() { return /* binding */ SearchImg; },
/* harmony export */   "SearchIcon": function() { return /* binding */ SearchIcon; },
/* harmony export */   "SearchField": function() { return /* binding */ SearchField; },
/* harmony export */   "Input": function() { return /* binding */ Input; },
/* harmony export */   "ButtonSearch": function() { return /* binding */ ButtonSearch; },
/* harmony export */   "SearchButton": function() { return /* binding */ SearchButton; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var HeroDiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroDiv",
  componentId: "sc-yjfsrr-0"
})(["display:flex;justify-content:space-between;@media (max-width:866px){flex-direction:column;}"]);
var HeroContainer = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroContainer",
  componentId: "sc-yjfsrr-1"
})(["padding-left:40px;padding-right:40px;padding-bottom:20px;background-color:#f5f5f5;@media (max-width:783px){padding-left:25px;padding-right:25px;}"]);
var HeroLeft = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroLeft",
  componentId: "sc-yjfsrr-2"
})(["", " height:450px;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;", " ", " margin-left:130px;@media (max-width:783px){height:350px;}@media (max-width:1129px){margin-left:50px;}@media (max-width:903px){margin-left:30px;}"], ""
/* height: 65vh; */
, ""
/* align-items: center; */
, ""
/* text-align: center; */
);
var HeroRight = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroRight",
  componentId: "sc-yjfsrr-3"
})(["height:400px;@media (max-width:783px){text-align:center;margin-top:-30px;margin-bottom:-30px;height:min-content;}"]);
var Image = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__Image",
  componentId: "sc-yjfsrr-4"
})(["width:538px;height:100%;@media (max-width:1129px){width:439px;}@media (max-width:783px){width:365px;height:354px;}@media (max-width:392px){width:265px;height:254px;}@media (max-width:954px){width:390px;}"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Herostyled__Button",
  componentId: "sc-yjfsrr-5"
})(["cursor:pointer;background-color:#f26a7e;margin-right:20px;color:#fff;font-size:16px;border:none;padding:10px 26px;border-radius:4px;&:hover{background-color:#fc5b73;transition:all 0.3s ease;}"]);
var Para = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.p.withConfig({
  displayName: "Herostyled__Para",
  componentId: "sc-yjfsrr-6"
})(["width:420px;color:#404366;line-height:25px;font-style:italic;font-weight:500;padding:15px 0;@media (max-width:783px){width:332px;font-weight:500;font-size:14px;line-height:21px;}@media (max-width:392px){width:300px;}@media (max-width:341px){width:280px;}"]);
var Writer = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.span.withConfig({
  displayName: "Herostyled__Writer",
  componentId: "sc-yjfsrr-7"
})(["font-weight:500;"]);
var Heading = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.h1.withConfig({
  displayName: "Herostyled__Heading",
  componentId: "sc-yjfsrr-8"
})(["font-size:45px;color:#404366;margin-bottom:50px;@media (max-width:783px){font-size:36px;margin-bottom:13px;margin-top:0;}@media (max-width:404px){font-size:30px;}"]);
var Head = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.span.withConfig({
  displayName: "Herostyled__Head",
  componentId: "sc-yjfsrr-9"
})(["font-size:51px;font-weight:bold;@media (max-width:783px){font-size:44px;}@media (max-width:404px){font-size:36px;}"]);
var HeroSearch = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearch",
  componentId: "sc-yjfsrr-10"
})(["display:flex;margin-left:40px;margin-right:170px;margin-bottom:40px;@media (max-width:783px){margin-left:0px;margin-right:0px;}"]);
var HeroSearchLeft = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearchLeft",
  componentId: "sc-yjfsrr-11"
})(["background-color:#f9bfc2;padding:10px 9px;border-radius:50%;margin-right:60px;@media (max-width:783px){margin-right:0px;position:absolute;right:10px;top:50%;box-shadow:rgba(242,106,126,0.25) 0px 54px 55px,rgba(242,106,126,0.12) 0px -12px 30px,rgba(242,106,126,0.12) 0px 4px 6px,rgba(242,106,126,0.17) 0px 9px 13px,rgba(242,106,126,0.09) 0px -3px 5px;}"]);
var HeroSearchRight = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__HeroSearchRight",
  componentId: "sc-yjfsrr-12"
})(["border:1px solid #c9cbe2;border-radius:4px;height:45px;margin-top:5px;flex:1;"]);
var Search = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__Search",
  componentId: "sc-yjfsrr-13"
})(["display:flex;align-items:center;height:100%;justify-content:flex-start;background-color:#fff;border-radius:4px;@media (max-width:589px){max-width:1000px;min-width:780px;margin-left:15px;}"]);
var Img = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__Img",
  componentId: "sc-yjfsrr-14"
})(["width:34px;height:25px;"]);
var SearchImg = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Herostyled__SearchImg",
  componentId: "sc-yjfsrr-15"
})(["width:34px;height:25px;@media (max-width:783px){width:24px;height:16px;color:#f26a7e;}"]);
var SearchIcon = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchIcon",
  componentId: "sc-yjfsrr-16"
})(["margin-left:40px;margin-right:40px;background-color:#fff;@media (max-width:783px){margin-left:0;margin-right:5px;}"]);
var SearchField = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchField",
  componentId: "sc-yjfsrr-17"
})(["width:100%;"]);
var Input = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.input.withConfig({
  displayName: "Herostyled__Input",
  componentId: "sc-yjfsrr-18"
})(["border:none;outline:none;width:100%;padding:10px 0;color:#404366;font-size:16px;font-weight:400;&::placeholder{color:#c9cbe2;font-size:16px;font-weight:400;}@media (max-width:783px){&::placeholder{font-size:13px;}}"]);
var ButtonSearch = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Herostyled__ButtonSearch",
  componentId: "sc-yjfsrr-19"
})(["cursor:pointer;background-color:#404366;margin-right:20px;color:#fff;font-size:16px;width:100%;border:none;padding:13px 38px;border-radius:4px;&:hover{background-color:#404355;transition:all 0.3s ease;}@media (max-width:783px){margin-right:0;font-size:14px;padding:14px 30px;}"]);
var SearchButton = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Herostyled__SearchButton",
  componentId: "sc-yjfsrr-20"
})([""]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguZWJlZjU2YTc2NjI4N2Q5Zjg3YjYuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRU8sSUFBTUMsT0FBTyxHQUFHRCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxtR0FBYjtBQVFBLElBQU1HLGFBQWEsR0FBR0gscUVBQUg7QUFBQTtBQUFBO0FBQUEseUpBQW5CO0FBWUEsSUFBTUksUUFBUSxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSxzUUFDakI7QUFBRztBQURjLEVBT2pCO0FBQUc7QUFQYyxFQVFqQjtBQUFHO0FBUmMsQ0FBZDtBQXFCQSxJQUFNSyxTQUFTLEdBQUdMLHFFQUFIO0FBQUE7QUFBQTtBQUFBLHlIQUFmO0FBV0EsSUFBTU0sS0FBSyxHQUFHTixxRUFBSDtBQUFBO0FBQUE7QUFBQSxtTkFBWDtBQW1CQSxJQUFNUSxNQUFNLEdBQUdSLHdFQUFIO0FBQUE7QUFBQTtBQUFBLHVNQUFaO0FBZUEsSUFBTVUsSUFBSSxHQUFHVixtRUFBSDtBQUFBO0FBQUE7QUFBQSxzUUFBVjtBQXFCQSxJQUFNWSxNQUFNLEdBQUdaLHNFQUFIO0FBQUE7QUFBQTtBQUFBLHdCQUFaO0FBSUEsSUFBTWMsT0FBTyxHQUFHZCxvRUFBSDtBQUFBO0FBQUE7QUFBQSwwS0FBYjtBQWVBLElBQU1nQixJQUFJLEdBQUdoQixzRUFBSDtBQUFBO0FBQUE7QUFBQSwwSEFBVjtBQVlBLElBQU1pQixVQUFVLEdBQUdqQixxRUFBSDtBQUFBO0FBQUE7QUFBQSx1SUFBaEI7QUFXQSxJQUFNa0IsY0FBYyxHQUFHbEIscUVBQUg7QUFBQTtBQUFBO0FBQUEsdVdBQXBCO0FBa0JBLElBQU1tQixlQUFlLEdBQUduQixxRUFBSDtBQUFBO0FBQUE7QUFBQSxxRkFBckI7QUFRQSxJQUFNb0IsTUFBTSxHQUFHcEIscUVBQUg7QUFBQTtBQUFBO0FBQUEsbU1BQVo7QUFjQSxJQUFNcUIsR0FBRyxHQUFHckIscUVBQUg7QUFBQTtBQUFBO0FBQUEsK0JBQVQ7QUFLQSxJQUFNc0IsU0FBUyxHQUFHdEIscUVBQUg7QUFBQTtBQUFBO0FBQUEsOEZBQWY7QUFVQSxJQUFNdUIsVUFBVSxHQUFHdkIscUVBQUg7QUFBQTtBQUFBO0FBQUEsMEhBQWhCO0FBVUEsSUFBTXdCLFdBQVcsR0FBR3hCLHFFQUFIO0FBQUE7QUFBQTtBQUFBLG1CQUFqQjtBQUlBLElBQU15QixLQUFLLEdBQUd6Qix1RUFBSDtBQUFBO0FBQUE7QUFBQSw4TkFBWDtBQW9CQSxJQUFNMkIsWUFBWSxHQUFHM0Isd0VBQUg7QUFBQTtBQUFBO0FBQUEsNFJBQWxCO0FBcUJBLElBQU00QixZQUFZLEdBQUc1QixxRUFBSDtBQUFBO0FBQUE7QUFBQSxRQUFsQiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9wYWdlcy9jb21wb25lbnRzL2hvbWVwYWdlL3BhcnRzL3N0eWxlcy9IZXJvLnN0eWxlZC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJzdHlsZWQtY29tcG9uZW50c1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9EaXYgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA4NjZweCkge1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSGVyb0NvbnRhaW5lciA9IHN0eWxlZC5kaXZgXHJcbiAgcGFkZGluZy1sZWZ0OiA0MHB4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDQwcHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDIwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjVmNTtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDI1cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAyNXB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvTGVmdCA9IHN0eWxlZC5kaXZgXHJcbiAgJHtcIlwiIC8qIGhlaWdodDogNjV2aDsgKi99XHJcbiAgaGVpZ2h0OiA0NTBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgJHtcIlwiIC8qIGFsaWduLWl0ZW1zOiBjZW50ZXI7ICovfVxyXG4gICR7XCJcIiAvKiB0ZXh0LWFsaWduOiBjZW50ZXI7ICovfVxyXG4gICAgbWFyZ2luLWxlZnQ6IDEzMHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgaGVpZ2h0OiAzNTBweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExMjlweCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA5MDNweCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9SaWdodCA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA0MDBweDtcclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAtMzBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IC0zMHB4O1xyXG4gICAgaGVpZ2h0OiBtaW4tY29udGVudDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW1hZ2UgPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiA1MzhweDtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDExMjlweCkge1xyXG4gICAgd2lkdGg6IDQzOXB4O1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIHdpZHRoOiAzNjVweDtcclxuICAgIGhlaWdodDogMzU0cHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAzOTJweCkge1xyXG4gICAgd2lkdGg6IDI2NXB4O1xyXG4gICAgaGVpZ2h0OiAyNTRweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDk1NHB4KSB7XHJcbiAgICB3aWR0aDogMzkwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEJ1dHRvbiA9IHN0eWxlZC5idXR0b25gXHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmMjZhN2U7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgcGFkZGluZzogMTBweCAyNnB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAmOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmYzViNzM7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBQYXJhID0gc3R5bGVkLnBgXHJcbiAgd2lkdGg6IDQyMHB4O1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG4gIGxpbmUtaGVpZ2h0OiAyNXB4O1xyXG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIHBhZGRpbmc6IDE1cHggMDtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIHdpZHRoOiAzMzJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMjFweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDM5MnB4KSB7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiAzNDFweCkge1xyXG4gICAgd2lkdGg6IDI4MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBXcml0ZXIgPSBzdHlsZWQuc3BhbmBcclxuICBmb250LXdlaWdodDogNTAwO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlYWRpbmcgPSBzdHlsZWQuaDFgXHJcbiAgZm9udC1zaXplOiA0NXB4O1xyXG4gIGNvbG9yOiAjNDA0MzY2O1xyXG4gIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgZm9udC1zaXplOiAzNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTNweDtcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgfVxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA0MDRweCkge1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZWFkID0gc3R5bGVkLnNwYW5gXHJcbiAgZm9udC1zaXplOiA1MXB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG5cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIGZvbnQtc2l6ZTogNDRweDtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDQwNHB4KSB7XHJcbiAgICBmb250LXNpemU6IDM2cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9TZWFyY2ggPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgbWFyZ2luLWxlZnQ6IDQwcHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxNzBweDtcclxuICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICAgIG1hcmdpbi1yaWdodDogMHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBIZXJvU2VhcmNoTGVmdCA9IHN0eWxlZC5kaXZgXHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y5YmZjMjtcclxuICBwYWRkaW5nOiAxMHB4IDlweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA2MHB4O1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA3ODNweCkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogMTBweDtcclxuICAgIHRvcDogNTAlO1xyXG4gICAgYm94LXNoYWRvdzogcmdiYSgyNDIsIDEwNiwgMTI2LCAwLjI1KSAwcHggNTRweCA1NXB4LFxyXG4gICAgICByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuMTIpIDBweCAtMTJweCAzMHB4LFxyXG4gICAgICByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuMTIpIDBweCA0cHggNnB4LFxyXG4gICAgICByZ2JhKDI0MiwgMTA2LCAxMjYsIDAuMTcpIDBweCA5cHggMTNweCxcclxuICAgICAgcmdiYSgyNDIsIDEwNiwgMTI2LCAwLjA5KSAwcHggLTNweCA1cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEhlcm9TZWFyY2hSaWdodCA9IHN0eWxlZC5kaXZgXHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2M5Y2JlMjtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgaGVpZ2h0OiA0NXB4O1xyXG4gIG1hcmdpbi10b3A6IDVweDtcclxuICBmbGV4OiAxO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICBtYXgtd2lkdGg6IDEwMDBweDtcclxuICAgIG1pbi13aWR0aDogNzgwcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW1nID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzRweDtcclxuICBoZWlnaHQ6IDI1cHg7XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU2VhcmNoSW1nID0gc3R5bGVkLmltZ2BcclxuICB3aWR0aDogMzRweDtcclxuICBoZWlnaHQ6IDI1cHg7XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogMTZweDtcclxuICAgIGNvbG9yOiAjZjI2YTdlO1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBTZWFyY2hJY29uID0gc3R5bGVkLmRpdmBcclxuICBtYXJnaW4tbGVmdDogNDBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDQwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAwO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEZpZWxkID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMTAwJTtcclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBJbnB1dCA9IHN0eWxlZC5pbnB1dGBcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgb3V0bGluZTogbm9uZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiAxMHB4IDA7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgJjo6cGxhY2Vob2xkZXIge1xyXG4gICAgY29sb3I6ICNjOWNiZTI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gIH1cclxuICBAbWVkaWEgKG1heC13aWR0aDogNzgzcHgpIHtcclxuICAgICY6OnBsYWNlaG9sZGVyIHtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBCdXR0b25TZWFyY2ggPSBzdHlsZWQuYnV0dG9uYFxyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzY2O1xyXG4gIG1hcmdpbi1yaWdodDogMjBweDtcclxuICBjb2xvcjogI2ZmZjtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDEzcHggMzhweDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgJjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNDA0MzU1O1xyXG4gICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZTtcclxuICB9XHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDc4M3B4KSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBwYWRkaW5nOiAxNHB4IDMwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNlYXJjaEJ1dHRvbiA9IHN0eWxlZC5kaXZgYDtcclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIkhlcm9EaXYiLCJkaXYiLCJIZXJvQ29udGFpbmVyIiwiSGVyb0xlZnQiLCJIZXJvUmlnaHQiLCJJbWFnZSIsImltZyIsIkJ1dHRvbiIsImJ1dHRvbiIsIlBhcmEiLCJwIiwiV3JpdGVyIiwic3BhbiIsIkhlYWRpbmciLCJoMSIsIkhlYWQiLCJIZXJvU2VhcmNoIiwiSGVyb1NlYXJjaExlZnQiLCJIZXJvU2VhcmNoUmlnaHQiLCJTZWFyY2giLCJJbWciLCJTZWFyY2hJbWciLCJTZWFyY2hJY29uIiwiU2VhcmNoRmllbGQiLCJJbnB1dCIsImlucHV0IiwiQnV0dG9uU2VhcmNoIiwiU2VhcmNoQnV0dG9uIl0sInNvdXJjZVJvb3QiOiIifQ==