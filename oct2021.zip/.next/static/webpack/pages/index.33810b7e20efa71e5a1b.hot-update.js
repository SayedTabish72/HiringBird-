"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/components/homepage/parts/styles/Categories.styled.js":
/*!*********************************************************************!*\
  !*** ./pages/components/homepage/parts/styles/Categories.styled.js ***!
  \*********************************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Container": function() { return /* binding */ Container; },
/* harmony export */   "Divstart": function() { return /* binding */ Divstart; },
/* harmony export */   "Innerdiv1": function() { return /* binding */ Innerdiv1; },
/* harmony export */   "Innerdiv2": function() { return /* binding */ Innerdiv2; },
/* harmony export */   "Span50": function() { return /* binding */ Span50; },
/* harmony export */   "Span1": function() { return /* binding */ Span1; },
/* harmony export */   "Spanright": function() { return /* binding */ Spanright; },
/* harmony export */   "Spanright2": function() { return /* binding */ Spanright2; },
/* harmony export */   "Lowerdiv": function() { return /* binding */ Lowerdiv; },
/* harmony export */   "Categorycard": function() { return /* binding */ Categorycard; },
/* harmony export */   "Categorycard1": function() { return /* binding */ Categorycard1; },
/* harmony export */   "Logo": function() { return /* binding */ Logo; },
/* harmony export */   "Button": function() { return /* binding */ Button; }
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* module decorator */ module = __webpack_require__.hmd(module);

var Container = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Container",
  componentId: "sc-1tyy3ex-0"
})(["width:100%;padding:0;display:flex;align-items:center;justify-content:center;flex-direction:row;flex-wrap:wrap;@media (max-width:589px){max-width:1000px;min-width:780px;}"]);
var Divstart = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Divstart",
  componentId: "sc-1tyy3ex-1"
})(["display:flex;justify-content:space-between;flex-wrap:wrap;width:80%;@media (max-width:589px){flex-direction:column;}"]);
var Innerdiv1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv1",
  componentId: "sc-1tyy3ex-2"
})(["display:\"flex\";flex-wrap:wrap;"]);
var Innerdiv2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Innerdiv2",
  componentId: "sc-1tyy3ex-3"
})(["display:\"flex\";width:50%;flex-wrap:wrap;"]);
var Span50 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span50",
  componentId: "sc-1tyy3ex-4"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){display:none;}"]);
var Span1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Span1",
  componentId: "sc-1tyy3ex-5"
})(["font-family:Inter;font-style:normal;font-weight:800;font-size:72px;line-height:98px;font-feature-settings:\"salt\" on,\"liga\" off;color:#404366;@media (max-width:589px){font-weight:600;font-size:30px;line-height:36px;width:50%;}"]);
var Spanright = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright",
  componentId: "sc-1tyy3ex-6"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;@media (max-width:589px){font-size:14px;line-height:21px;width:370px;font-feature-settings:\"salt\" on,\"liga\" off;margin-top:5%;}"]);
var Spanright2 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Spanright2",
  componentId: "sc-1tyy3ex-7"
})(["font-family:Inter;font-style:normal;font-weight:500;font-size:20px;line-height:32px;font-feature-settings:\"salt\" on,\"liga\" off;color:#18191f;width:fit-content;margin-top:6%;border-bottom:1.76px solid #18191f;@media (max-width:589px){font-size:17px;line-height:24px;width:170px;}"]);
var Lowerdiv = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Lowerdiv",
  componentId: "sc-1tyy3ex-8"
})(["display:flex;height:70%;width:80%;flex-wrap:wrap;align-items:center;justify-content:center;margin-top:4%;@media (max-width:381px){width:100%;align-items:center;margin-left:35px;}"]);
var Categorycard = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard",
  componentId: "sc-1tyy3ex-9"
})(["width:174px;height:13em;border:1px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Categorycard1 = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div.withConfig({
  displayName: "Categoriesstyled__Categorycard1",
  componentId: "sc-1tyy3ex-10"
})(["width:174px;height:13em;border:0px solid rgba(75,75,75,0.3);border-radius:8px;flex:0 0 14em;margin-top:2%;box-sizing:border-box;margin-right:10px;margin-left:10px;display:flex;align-items:center;justify-content:space-evenly;flex-direction:column;&:hover{box-shadow:0px 8px 24px rgba(216,216,216,0.3);backdrop-filter:blur(40px);}@media (max-width:589px){width:140px;height:140px;flex:0 0 140px;}"]);
var Logo = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img.withConfig({
  displayName: "Categoriesstyled__Logo",
  componentId: "sc-1tyy3ex-11"
})(["width:30px;height:30px;"]);
var Button = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.button.withConfig({
  displayName: "Categoriesstyled__Button",
  componentId: "sc-1tyy3ex-12"
})(["border:1px solid #f26a7e;background:none;font-family:Inter;font-style:normal;font-weight:500;font-size:16px;line-height:19px;color:#404366;padding:10px;margin:0px 10px;border-radius:4px;&:hover{background:#f26a7e;}"]);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMzM4MTBiN2UyMGVmYTcxZTVhMWIuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUVPLElBQU1DLFNBQVMsR0FBR0QscUVBQUg7QUFBQTtBQUFBO0FBQUEsaUxBQWY7QUFjQSxJQUFNRyxRQUFRLEdBQUdILHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRIQUFkO0FBV0EsSUFBTUksU0FBUyxHQUFHSixxRUFBSDtBQUFBO0FBQUE7QUFBQSx3Q0FBZjtBQUlBLElBQU1LLFNBQVMsR0FBR0wscUVBQUg7QUFBQTtBQUFBO0FBQUEsa0RBQWY7QUFNQSxJQUFNTSxNQUFNLEdBQUdOLHFFQUFIO0FBQUE7QUFBQTtBQUFBLGdNQUFaO0FBYUEsSUFBTU8sS0FBSyxHQUFHUCxxRUFBSDtBQUFBO0FBQUE7QUFBQSw2T0FBWDtBQWlCQSxJQUFNUSxTQUFTLEdBQUdSLHFFQUFIO0FBQUE7QUFBQTtBQUFBLDRSQUFmO0FBbUJBLElBQU1TLFVBQVUsR0FBR1QscUVBQUg7QUFBQTtBQUFBO0FBQUEsa1NBQWhCO0FBcUJBLElBQU1VLFFBQVEsR0FBR1YscUVBQUg7QUFBQTtBQUFBO0FBQUEsMExBQWQ7QUFpQkEsSUFBTVcsWUFBWSxHQUFHWCxxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbEI7QUEyQkEsSUFBTVksYUFBYSxHQUFHWixxRUFBSDtBQUFBO0FBQUE7QUFBQSxrWkFBbkI7QUE2QkEsSUFBTWEsSUFBSSxHQUFHYixxRUFBSDtBQUFBO0FBQUE7QUFBQSwrQkFBVjtBQUtBLElBQU1lLE1BQU0sR0FBR2Ysd0VBQUg7QUFBQTtBQUFBO0FBQUEsOE5BQVoiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvY29tcG9uZW50cy9ob21lcGFnZS9wYXJ0cy9zdHlsZXMvQ2F0ZWdvcmllcy5zdHlsZWQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwic3R5bGVkLWNvbXBvbmVudHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBDb250YWluZXIgPSBzdHlsZWQuZGl2YFxyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgbWF4LXdpZHRoOiAxMDAwcHg7XHJcbiAgICBtaW4td2lkdGg6IDc4MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBEaXZzdGFydCA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuICAvLyBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgd2lkdGg6IDgwJTtcclxuICBAbWVkaWEgKG1heC13aWR0aDogNTg5cHgpIHtcclxuICAgIGZsZXgtZGlyZWN0aW9uOmNvbHVtbjtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgSW5uZXJkaXYxID0gc3R5bGVkLmRpdmBcclxuICBkaXNwbGF5OiBcImZsZXhcIjtcclxuICBmbGV4LXdyYXA6IHdyYXA7XHJcbmA7XHJcbmV4cG9ydCBjb25zdCBJbm5lcmRpdjIgPSBzdHlsZWQuZGl2YFxyXG4gIGRpc3BsYXk6IFwiZmxleFwiO1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgZmxleC13cmFwOiB3cmFwO1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNwYW41MCA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogODAwO1xyXG4gIGZvbnQtc2l6ZTogNzJweDtcclxuICBsaW5lLWhlaWdodDogOThweDtcclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbmA7XHJcbmV4cG9ydCBjb25zdCBTcGFuMSA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogODAwO1xyXG4gIGZvbnQtc2l6ZTogNzJweDtcclxuICBsaW5lLWhlaWdodDogOThweDtcclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcbiAgY29sb3I6ICM0MDQzNjY7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzNnB4O1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU3BhbnJpZ2h0ID0gc3R5bGVkLmRpdmBcclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xyXG5cclxuICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcblxyXG4gIGNvbG9yOiAjMTgxOTFmO1xyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIxcHg7XHJcbiAgICB3aWR0aDogMzcwcHg7XHJcbiAgICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IFwic2FsdFwiIG9uLCBcImxpZ2FcIiBvZmY7XHJcbiAgICBtYXJnaW4tdG9wOiA1JTtcclxuICB9XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgU3BhbnJpZ2h0MiA9IHN0eWxlZC5kaXZgXHJcbiAgZm9udC1mYW1pbHk6IEludGVyO1xyXG4gIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsaW5lLWhlaWdodDogMzJweDtcclxuXHJcbiAgZm9udC1mZWF0dXJlLXNldHRpbmdzOiBcInNhbHRcIiBvbiwgXCJsaWdhXCIgb2ZmO1xyXG5cclxuICBjb2xvcjogIzE4MTkxZjtcclxuICB3aWR0aDogZml0LWNvbnRlbnQ7XHJcbiAgbWFyZ2luLXRvcDogNiU7XHJcbiAgYm9yZGVyLWJvdHRvbTogMS43NnB4IHNvbGlkICMxODE5MWY7XHJcblxyXG4gIEBtZWRpYSAobWF4LXdpZHRoOiA1ODlweCkge1xyXG4gICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgICB3aWR0aDogMTcwcHg7XHJcbiAgfVxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IExvd2VyZGl2ID0gc3R5bGVkLmRpdmBcclxuZGlzcGxheTogZmxleDtcclxuaGVpZ2h0OiA3MCU7XHJcbndpZHRoOiA4MCU7XHJcbmZsZXgtd3JhcDogd3JhcDtcclxuYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuanVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbm1hcmdpbi10b3A6IDQlO1xyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDM4MXB4KSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBtYXJnaW4tbGVmdDogMzVweDtcclxufSAgXHJcblxyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IENhdGVnb3J5Y2FyZCA9IHN0eWxlZC5kaXZgXHJcbndpZHRoOiAxNzRweDtcclxuICBoZWlnaHQ6IDEzZW07XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSg3NSwgNzUsIDc1LCAwLjMpO1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICBmbGV4OiAwIDAgMTRlbTtcclxuICBtYXJnaW4tdG9wOiAyJTtcclxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBtYXJnaW4tbGVmdDogMTBweDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiAgJjpob3ZlciB7XHJcbiAgICBib3gtc2hhZG93OiAwcHggOHB4IDI0cHggcmdiYSgyMTYsIDIxNiwgMjE2LCAwLjMpO1xyXG4gICAgYmFja2Ryb3AtZmlsdGVyOiBibHVyKDQwcHgpO1xyXG4gIH1cclxuXHJcbiAgQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgICB3aWR0aDogMTQwcHg7XHJcbiAgICBoZWlnaHQ6IDE0MHB4O1xyXG4gICAgZmxleDogMCAwIDE0MHB4O1xyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBDYXRlZ29yeWNhcmQxID0gc3R5bGVkLmRpdmBcclxud2lkdGg6IDE3NHB4O1xyXG5cclxuaGVpZ2h0OiAxM2VtO1xyXG5ib3JkZXI6IDBweCBzb2xpZCByZ2JhKDc1LCA3NSwgNzUsIDAuMyk7XHJcbmJvcmRlci1yYWRpdXM6IDhweDtcclxuZmxleDogMCAwIDE0ZW07XHJcbm1hcmdpbi10b3A6IDIlO1xyXG5ib3gtc2l6aW5nOiBib3JkZXItYm94O1xyXG5tYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbm1hcmdpbi1sZWZ0OiAxMHB4O1xyXG5cclxuZGlzcGxheTogZmxleDtcclxuYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuanVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XHJcbmZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG4mOmhvdmVyIHtcclxuICBib3gtc2hhZG93OiAwcHggOHB4IDI0cHggcmdiYSgyMTYsIDIxNiwgMjE2LCAwLjMpO1xyXG4gIGJhY2tkcm9wLWZpbHRlcjogYmx1cig0MHB4KTtcclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDU4OXB4KSB7XHJcbiAgd2lkdGg6IDE0MHB4O1xyXG4gIGhlaWdodDogMTQwcHg7XHJcbiAgZmxleDogMCAwIDE0MHB4O1xyXG59XHJcbmA7XHJcblxyXG5leHBvcnQgY29uc3QgTG9nbyA9IHN0eWxlZC5pbWdgXHJcbiAgd2lkdGg6IDMwcHg7XHJcbiAgaGVpZ2h0OiAzMHB4O1xyXG5gO1xyXG5cclxuZXhwb3J0IGNvbnN0IEJ1dHRvbiA9IHN0eWxlZC5idXR0b25gXHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2YyNmE3ZTtcclxuICBiYWNrZ3JvdW5kOiBub25lO1xyXG5cclxuICBmb250LWZhbWlseTogSW50ZXI7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAxOXB4O1xyXG5cclxuICBjb2xvcjogIzQwNDM2NjtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG5cclxuICBtYXJnaW46IDBweCAxMHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuXHJcbiAgJjpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjI2YTdlO1xyXG4gIH1cclxuYDtcclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIkNvbnRhaW5lciIsImRpdiIsIkRpdnN0YXJ0IiwiSW5uZXJkaXYxIiwiSW5uZXJkaXYyIiwiU3BhbjUwIiwiU3BhbjEiLCJTcGFucmlnaHQiLCJTcGFucmlnaHQyIiwiTG93ZXJkaXYiLCJDYXRlZ29yeWNhcmQiLCJDYXRlZ29yeWNhcmQxIiwiTG9nbyIsImltZyIsIkJ1dHRvbiIsImJ1dHRvbiJdLCJzb3VyY2VSb290IjoiIn0=